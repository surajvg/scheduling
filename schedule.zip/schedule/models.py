# from pydantic import BaseModel
# from datetime import datetime
# class Data(BaseModel):
#     division:str
#     part_no: int 
#     item_no: int 
#     description: str
#     quantity: int 
#     po_number: int
#     name: str
#     staff_no: int
#     date: datetime
#     comments:str
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import pandas as pd
from typing import List, Optional, Dict, Any
# class POMetric(BaseModel):
#     productionOrder: str
#     total_units: int
#     reworked_units: int
#     rejected_units: int
#     first_time_pass_percent: float
#     yield_percent: float
# class QualityMetricsResponse(BaseModel):
#     overall: POMetric
#     production_orders: List[POMetric]

# class MonthMetric(BaseModel):
#     month: str  # e.g., "2023-10" or "October 2023"
#     total_units: int
#     reworked_units: int
#     rejected_units: int
#     first_time_pass_percent: float
#     yield_percent: float
#     all_serial_numbers: List[str] = []
#     reworked_serial_numbers: List[str] = []
#     rejected_serial_numbers: List[str] = []

# class MonthlyQualityMetricsResponse(BaseModel):
#     overall: MonthMetric
#     monthly_data: List[MonthMetric]

class BaseQualityMetric(BaseModel):
    total_units: int
    reworked_units: int
    rejected_units: int
    first_time_pass_percent: float
    yield_percent: float
    all_serial_numbers: List[str] = []
    reworked_serial_numbers: List[str] = []
    rejected_serial_numbers: List[str] = []

# 2. Metric specific to a Production Order
class POMetricNode(BaseQualityMetric):
    productionOrder: str

# 3. Metric specific to a Month, containing its own POs
class MonthMetricNode(BaseQualityMetric):
    month: str
    production_orders: List[POMetricNode]

# 4. Final Response Schema
class UnifiedQualityMetricsResponse(BaseModel):
    overall: BaseQualityMetric
    monthly_data: List[MonthMetricNode]
    
class OperatorActionRequest(BaseModel):
    PCBserialNoPartNumber : str
    current_step_id : int
    assignment_id:int
    Task_Status :str 
    Task_Name : str
    operator_staff_no :str
    log_Data : Dict[str,Any]
    userID : str
    userRole : str
    userName : str
    userSBU : str
    userSBUDiv : str
    start_time : Optional[datetime] = None
    end_time : Optional[datetime] = None
    file_name: Optional[str] = None
    file_path : Optional[str] = None
    file_url : Optional[str] = None

class QRRecord(BaseModel):
    Timestamp: Optional[datetime]
    SL_No: Optional[int]
    BEL_Part_Number: Optional[int]
    MPN: Optional[str]
    Batch_Lot_No: Optional[str]
    DateCode: Optional[int]
    Quantity: Optional[int]
    BEL_PO_No: Optional[str]
    Vendor_Name: Optional[str]
    OEM_Make: Optional[str]
    Manufacturing_Place: Optional[str]
    GR_No: Optional[str]
    GR_Date: Optional[datetime]
    Reference_No: Optional[str]
    Description : Optional[str]
    Vendor_Code : Optional[str]
    Invoice_No  : Optional[str]
    Invoice_Dt : Optional[datetime]
    Status : Optional[str]

    @classmethod
    def from_csv(cls, csv_file: str):
        import pandas as pd
        df = pd.read_csv(csv_file)
        records = []
        for _, row in df.iterrows():
            # Convert date strings to datetime
            row_dict = row.to_dict()
            if "Timestamp" in row_dict and row_dict["Timestamp"]:
                try:
                    row_dict["Timestamp"] = datetime.strptime(row_dict["Timestamp"], "%Y-%m-%d %H:%M:%S")
                except:
                    row_dict["Timestamp"] = None
            if "GR_Date" in row_dict and row_dict["GR_Date"]:
                try:
                    row_dict["GR_Date"] = datetime.strptime(row_dict["GR_Date"], "%Y-%m-%d")
                except:
                    row_dict["GR_Date"] = None
            records.append(cls(**row_dict))
        return records 

# class UserCreate(BaseModel):
#     username: str
#     email: str
#     password: str   # plaintext from user

# class UserOut(BaseModel):
#     id: int
#     username: str
#     email: str

#     class Config:
#         orm_mode = True
# class QRRecord(BaseModel):
#     Timestamp: Optional[datetime]
#     SL_No: Optional[int]
#     BEL_Part_Number: Optional[int]
#     MPN: Optional[str]
#     Batch_Lot_No: Optional[str]
#     DateCode: Optional[int]
#     Quantity: Optional[int]
#     BEL_PO_No: Optional[str]
#     Vendor_Name: Optional[str]
#     OEM_Make: Optional[str]
#     Manufacturing_Place: Optional[str]
#     GR_No: Optional[str] = None
#     GR_Date: Optional[datetime] = None
#     Reference_No: Optional[str] = None

#     @classmethod
#     def from_csv(cls, csv_file: str):
#         import pandas as pd
#         from datetime import datetime

#         df = pd.read_csv(csv_file)
#         df.columns = df.columns.str.strip()

#         # Replace NaN with None
#         df = df.where(pd.notnull(df), None)

#         # Convert numeric columns to int safely
#         for col in ["SL_No", "BEL_Part_Number", "DateCode", "Quantity"]:
#             if col in df.columns:
#                 df[col] = df[col].apply(lambda x: int(x) if x is not None else None)

#         # Convert date columns safely
#         for col in ["Timestamp", "GR_Date"]:
#             if col in df.columns:
#                 df[col] = pd.to_datetime(df[col], errors="coerce")

#         # Convert GR_No and Reference_No safely
#         for col in ["GR_No", "Reference_No"]:
#             if col in df.columns:
#                 df[col] = df[col].apply(lambda x: str(x) if x is not None else None)
#                 df[col] = df[col].apply(lambda x: None if x == 'nan' else x)

#         # Build Pydantic models
#         records = [cls(**row) for row in df.to_dict(orient="records")]
#         return records

class SubContract_Inspection_Report(BaseModel):
    Control_No: Optional[int]
    SAN_NO : Optional[int]
    Part_No : Optional[str]
    Description : Optional[str]
    PO_NO : Optional[str]
    Vendor_Name : Optional[str]
    Quantity : Optional[str]
    Sample: Optional[str]
    Sale_Order : Optional[str]
    Drg_Issue_Level : Optional[int]
    Reference_No :Optional[str]
    Date :Optional[datetime]
    Vendor_Dimension_Report : Optional[str]
    Visual_Inspection : Optional[str]
    Raw_Material_Supplied : Optional[str]
    Raw_Material_Test_Report : Optional[str]





from pydantic import BaseModel, ConfigDict
from datetime import date

class EquipmentSchema(BaseModel):
    # Enable ORM mode so it can read SQLAlchemy objects
    model_config = ConfigDict(from_attributes=True)

    id: int  # Added this so the GET response includes the ID
    stage_id: int
    eqpt_no: str
    eqpt_name: str
    eqpt_make: str
    eqpt_model: str
    eqpt_due_date: date

class ConsumableCreate(BaseModel):
    stage_id: int
    consumable_material_number: str
    consumable_material_name: str
    consumable_gr_number: str
    consumable_year: str
    consumable_shelf_life: str
    batch_number : Optional[str] = None
class ConsumableSchema(ConsumableCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
