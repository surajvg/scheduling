"""
schedule_server.py
==================
Stand-alone FastAPI server for the production schedule (no need to touch Data_Server.py).

    python schedule_server.py          ->  http://127.0.0.1:2000/schedule/data

Files that must be in the same folder:
    Database.py              - database connection (engine, session)
    Database_models.py       - SQLAlchemy models (with ProcessScheduleConfig added)
    production_scheduler.py  - the scheduling logic

Endpoints:
    GET    /schedule/data                 -> schedule JSON for the Gantt chart
    POST   /schedule/update               -> save manual changes (checked first)
    GET    /schedule/config               -> per-stage config (batch size, cooldown, ...)
    POST   /schedule/config               -> save one stage config
    DELETE /schedule/config/{stage_id}    -> stage back to defaults
"""
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from sqlalchemy import inspect

from Database import engine, session
from Database_models import (
    base, CalendarException, Equipments, OperatorLog, OperatorStepMapping, PartProcessTime, PcbData, Plant,
    ProcessFlowMaster, ProcessScheduleConfig, Processtype, ProductionOrderTracking, ProductTypeMaster,
    ProductWorkflowMapping, PublicHoliday, ScheduleOverride, StageCapacityDB, UserProfile,
)

HOST = "0.0.0.0"
PORT = 2000

app = FastAPI(title="Production Schedule")

# allow the React app (other port / other PC) to call this server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Tables the scheduler reads or writes. Missing ones are created empty at start-up
# (existing tables and their data are never changed). Parents first because of the foreign keys.
SCHEDULE_TABLES = [
    UserProfile, Plant, ProcessFlowMaster, ProductTypeMaster, ProductWorkflowMapping, PartProcessTime,
    StageCapacityDB, Processtype, Equipments, OperatorStepMapping, PcbData, ProductionOrderTracking,
    OperatorLog, PublicHoliday, CalendarException, ScheduleOverride, ProcessScheduleConfig,
]
existing = set(inspect(engine).get_table_names())
missing = [m.__table__ for m in SCHEDULE_TABLES if m.__tablename__ not in existing]
if missing:
    print("Creating missing tables:", ", ".join(t.name for t in missing))
    base.metadata.create_all(bind=engine, tables=missing)


def init_db():
    """One database session per request (same as Data_Server.py)."""
    db = session()
    try:
        yield db
    finally:
        db.close()


# ======================================================================================
# DATABASE -> SCHEDULE (same code as the block for Data_Server.py)
# ======================================================================================
from collections import Counter, defaultdict
from datetime import datetime
from typing import List, Optional

from fastapi import Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from Database_models import (
    CalendarException, Equipments, OperatorLog, OperatorStepMapping, PartProcessTime, PcbData,
    ProcessFlowMaster, ProcessScheduleConfig, Processtype, ProductionOrderTracking, ProductTypeMaster,
    ProductWorkflowMapping, PublicHoliday, ScheduleOverride, StageCapacityDB,
)
from production_scheduler import (
    DEFAULT_STAGE_CONFIG, Calendar, build_state, iso, make_schedule, validate_changes,
)

COMPLETED_STATUSES = {"COMPLETED", "COMPLETE", "DONE", "FINISHED"}       # OperatorLog.Task_Status
CLOSED_PO_STATUSES = {"completed", "closed", "cancelled", "canceled"}    # ProductionOrderTracking.status


def load_schedule_inputs(db: Session, time_source: str = "actual", history_days: int = 7,
                         plant: Optional[str] = None, now: Optional[datetime] = None):
    """Read every table the scheduler needs and return plain dicts (see production_scheduler.build_state)."""
    now = (now or datetime.now()).replace(second=0, microsecond=0)   # whole minutes look nicer in the chart
    warnings = []

    # ---------------- 1. working calendar (A2) ----------------
    caps = db.query(StageCapacityDB).all()
    hours_list = [float(c.hours_per_shift) for c in caps if c.hours_per_shift and c.hours_per_shift > 0]
    shifts_list = [int(c.shifts_per_day) for c in caps if c.shifts_per_day and c.shifts_per_day > 0]
    hours_per_shift = max(hours_list) if hours_list else 7.0       # default 7 h
    shifts_per_day = max(shifts_list) if shifts_list else 2         # default 2 shifts
    shift_start_hour = 6.0                                          # default 06:00
    for c in caps:   # stage_capacity has no start-hour column today; add `shift_start_hour` there to change it
        if getattr(c, "shift_start_hour", None) is not None:
            shift_start_hour = float(c.shift_start_hour)
            break
    work_hours = hours_per_shift * shifts_per_day
    if shift_start_hour + work_hours > 24:
        warnings.append("Shift window %g h x %d starting %02d:00 goes past midnight - cut at 24:00."
                        % (hours_per_shift, shifts_per_day, shift_start_hour))
        work_hours = 24 - shift_start_hour

    exceptions = {}
    for e in db.query(CalendarException).all():
        exceptions[e.exception_date] = ((e.exception_type or "").strip().lower(), e.note or "")
    cal = Calendar(
        public_holidays={h.holiday_date: h.name for h in db.query(PublicHoliday).all()},
        exceptions=exceptions,
        shift_start_hour=shift_start_hour,
        work_hours=work_hours,
        shifts_per_day=shifts_per_day,
    )

    # ---------------- 2. stages, batch flag, operators, stage config ----------------
    stages = {s.flow_step_id: s for s in db.query(ProcessFlowMaster).all()}
    stage_names = {sid: (s.step_name or "Step %s" % sid) for sid, s in stages.items()}
    stage_order = {sid: (s.step_order if s.step_order is not None else 9999) for sid, s in stages.items()}
    batch_stages = {p.stage_id for p in db.query(Processtype).all() if p.process_type_batch}

    operators_by_stage = defaultdict(list)          # stage_id -> [operator_name, ...]
    for o in db.query(OperatorStepMapping).order_by(OperatorStepMapping.step_map_id).all():
        if o.operator_name and o.operator_name not in operators_by_stage[o.flow_step_id]:
            operators_by_stage[o.flow_step_id].append(o.operator_name)

    stage_config = {}                               # stage_id -> values from process_schedule_config
    for r in db.query(ProcessScheduleConfig).all():
        stage_config[r.stage_id] = config_row_values(r)

    cap_by_name = {(c.name or "").strip().lower(): c for c in caps}

    # ---------------- 3. machines (Equipments) ----------------
    machines = []
    seen = set()
    for e in db.query(Equipments).order_by(Equipments.stage_id, Equipments.id).all():
        if e.stage_id is None:
            continue                                # not linked to a stage -> cannot be scheduled
        mid = e.machine_id or e.eqpt_no or "EQ-%s" % e.id
        if mid in seen:
            warnings.append("Machine id %s appears more than once in equipment_details - the extra row for "
                            "stage '%s' is ignored." % (mid, stage_names.get(e.stage_id, e.stage_id)))
            continue
        seen.add(mid)
        machines.append({
            "machine_id": mid,
            "machine_name": e.eqpt_name or mid,
            "work_centre": e.workcenter_name or stage_names.get(e.stage_id, ""),
            "stage_id": e.stage_id,
            "resource_type": "MACHINE",
        })

    # ---------------- 4. PCBs per production order (PcbData) ----------------
    pcb_rows = db.query(
        PcbData.PCBserialNoPartNumber, PcbData.productionOrder, PcbData.partNumber,
        PcbData.quantity, PcbData.createdAt, PcbData.description,
    ).filter(PcbData.productionOrder.isnot(None), PcbData.productionOrder != "").all()
    pcbs_by_po = defaultdict(list)
    pcb_po_and_qty = {}                             # serial -> (po, quantity of that row)
    no_qty = 0
    for r in pcb_rows:
        qty = r.quantity if (r.quantity and r.quantity > 0) else 1
        if not r.quantity:
            no_qty += 1
        pcbs_by_po[r.productionOrder].append(r)
        pcb_po_and_qty[r.PCBserialNoPartNumber] = (r.productionOrder, qty)
    if no_qty:
        warnings.append("%d PCB row(s) have no quantity - counted as 1 PCB each." % no_qty)
    tracking = {t.po_number: t for t in db.query(ProductionOrderTracking).all()}

    # ---------------- 5. real progress per (PO, step) from OperatorLog ----------------
    progress = {}   # (po, step_id) -> {"done", "started", "start", "end", "operators"}
    bad_times = 0
    for lg in db.query(OperatorLog.PCBserialNoPartNumber, OperatorLog.current_step_id, OperatorLog.Task_Status,
                       OperatorLog.start_time, OperatorLog.end_time, OperatorLog.operator_name).all():
        if lg.PCBserialNoPartNumber not in pcb_po_and_qty:
            continue
        po_no, qty = pcb_po_and_qty[lg.PCBserialNoPartNumber]
        p = progress.setdefault((po_no, lg.current_step_id),
                                {"done": 0, "started": False, "start": None, "end": None, "operators": Counter()})
        end_time = lg.end_time
        if end_time and lg.start_time and end_time < lg.start_time:
            bad_times += 1
            end_time = None                         # end before start -> ignore that end time
        status = (lg.Task_Status or "").strip().upper().replace("-", "_")
        if status in COMPLETED_STATUSES:
            p["done"] += qty
            if end_time and (p["end"] is None or end_time > p["end"]):
                p["end"] = end_time
        else:
            p["started"] = True
        if lg.start_time and (p["start"] is None or lg.start_time < p["start"]):
            p["start"] = lg.start_time
        if lg.operator_name:
            p["operators"][lg.operator_name] += 1
    if bad_times:
        warnings.append("%d operator_log row(s) have end_time before start_time - that end time was ignored."
                        % bad_times)

    # ---------------- 6. part number, routing and process times ----------------
    po_numbers = sorted(set(pcbs_by_po) | set(tracking))
    part_of_po = {}
    for po_no in po_numbers:
        parts = Counter(r.partNumber for r in pcbs_by_po.get(po_no, []) if r.partNumber)
        if parts:
            part_of_po[po_no] = parts.most_common(1)[0][0]
        elif po_no in tracking and tracking[po_no].part_number:
            part_of_po[po_no] = tracking[po_no].part_number
    part_numbers = set(part_of_po.values())

    products, routing, times = {}, defaultdict(list), defaultdict(list)
    if part_numbers:
        for p in db.query(ProductTypeMaster).filter(ProductTypeMaster.part_number.in_(part_numbers)).all():
            products[p.part_number] = p
        for r in db.query(ProductWorkflowMapping).filter(
                ProductWorkflowMapping.product_part_number.in_(part_numbers)
        ).order_by(ProductWorkflowMapping.product_part_number, ProductWorkflowMapping.step_sequence).all():
            routing[r.product_part_number].append(r)
        for t in db.query(PartProcessTime).filter(PartProcessTime.part_no.in_(part_numbers)).all():
            times[(t.part_no, t.process_id)].append(t)

    def minutes_for(part, step_id):
        """Process time in MINUTES for one PCB (SERIES step) or one batch run (BATCH step).
        part_process_time (hours, time_source first) -> stage_capacity.manufacturing_time_mins -> None."""
        rows = times.get((part, step_id), [])
        if rows:
            plant_code = products[part].plant_code if part in products else None
            row = next((r for r in rows if r.plant == plant_code), rows[0])
            first, second = (row.actual_time, row.sap_time) if time_source == "actual" else (row.sap_time, row.actual_time)
            for hours in (first, second):
                if hours and hours > 0:
                    return float(hours) * 60.0
        stage = stages.get(step_id)
        cap = cap_by_name.get((stage.step_name or "").strip().lower()) if stage else None
        if cap and cap.manufacturing_time_mins and cap.manufacturing_time_mins > 0:
            return float(cap.manufacturing_time_mins)
        return None

    # ---------------- 7. production orders + operations ----------------
    orders = {}
    hidden_old = 0
    missing_time = set()
    for po_no in po_numbers:
        part = part_of_po.get(po_no)
        trk = tracking.get(po_no)
        if not part:
            warnings.append("PO %s has no part number - not scheduled." % po_no)
            continue
        if plant and part in products and products[part].plant_code != plant:
            continue
        steps = routing.get(part, [])
        if not steps:
            warnings.append("PO %s: part %s has no routing in product_workflow_mapping - not scheduled." % (po_no, part))
            continue

        pcbs = pcbs_by_po.get(po_no, [])
        pcb_qty = sum((r.quantity if (r.quantity and r.quantity > 0) else 1) for r in pcbs)
        qty = max(pcb_qty, (trk.target_quantity or 0) if trk else 0)
        if qty <= 0:
            warnings.append("PO %s has quantity 0 - not scheduled." % po_no)
            continue

        # R7 release date: first PCB created, else PO started / created, else now
        created = [r.createdAt for r in pcbs if r.createdAt]
        release = min(created) if created else ((trk.started_at or trk.created_at) if trk else None)
        release = (release or now).replace(tzinfo=None, microsecond=0)
        description = ""
        if part in products and products[part].description:
            description = products[part].description
        else:
            description = next((r.description for r in pcbs if r.description), "") or ""

        ops = []
        used_seq = set()
        for idx, st in enumerate(steps, start=1):
            seq = st.step_sequence if (st.step_sequence and st.step_sequence not in used_seq) else max(used_seq | {0}) + 1
            used_seq.add(seq)
            mode = "BATCH" if st.flow_step_id in batch_stages else "SERIES"
            minutes = minutes_for(part, st.flow_step_id)
            if minutes is None:
                missing_time.add((part, stage_names.get(st.flow_step_id, st.flow_step_id)))
                minutes = 1.0
            p = progress.get((po_no, st.flow_step_id),
                             {"done": 0, "started": False, "start": None, "end": None, "operators": Counter()})
            ops.append({
                "op_id": "%s-%d" % (po_no, seq * 10),
                "production_order": po_no,
                "part_number": part,
                "operation_no": seq * 10,
                "flow_step_id": st.flow_step_id,
                "step_name": stage_names.get(st.flow_step_id, "Step %s" % st.flow_step_id),
                "process_mode": mode,
                "quantity": qty,
                # SERIES: part_process_time is per PCB. BATCH: part_process_time is per BATCH RUN.
                "minutes_per_pcb": minutes if mode == "SERIES" else None,
                "minutes_per_batch": minutes if mode == "BATCH" else None,
                "completed_qty": min(p["done"], qty),
                "started": p["started"],
                "actual_start": p["start"],
                "actual_end": p["end"],
                "actual_operator": p["operators"].most_common(1)[0][0] if p["operators"] else "",
            })

        # finished POs are shown only for `history_days` after they finished
        all_done = all(o["completed_qty"] >= qty for o in ops)
        closed = bool(trk and (trk.status or "").strip().lower() in CLOSED_PO_STATUSES)
        if all_done or closed:
            ends = [o["actual_end"] for o in ops if o["actual_end"]]
            if closed and trk and (trk.closed_at or trk.updated_at):
                ends.append(trk.closed_at or trk.updated_at)
            last_activity = (max(ends) if ends else release).replace(tzinfo=None)
            if (now - last_activity).days > history_days:
                hidden_old += 1
                continue
            if closed and not all_done:
                # closed in production_order_tracking -> nothing left to schedule, every step counts as finished
                for o in ops:
                    if o["completed_qty"] < qty:
                        o["completed_qty"] = qty
                        o["actual_end"] = o["actual_end"] or last_activity
                        o["actual_start"] = o["actual_start"] or o["actual_end"]

        orders[po_no] = {"production_order": po_no, "part_number": part, "description": description,
                         "quantity": qty, "release": release, "ops": ops}

    for part, stage_name in sorted(missing_time, key=str):
        warnings.append("No process time for part %s at stage '%s' (part_process_time / stage_capacity) - "
                        "1 minute used." % (part, stage_name))
    if hidden_old:
        warnings.append("%d finished production order(s) older than %d day(s) are hidden." % (hidden_old, history_days))

    # R7: priority order = release date, then PO number. Change this list to change the priority.
    sequence = sorted(orders, key=lambda k: (orders[k]["release"], k))

    # ---------------- 8. manual changes saved from the UI (oldest first) ----------------
    overrides = [{"op_id": o.op_id, "machine_id": o.machine_id, "start_time": o.start_time, "end_time": o.end_time}
                 for o in db.query(ScheduleOverride).order_by(ScheduleOverride.updated_at).all()]

    return {
        "now": now, "calendar": cal, "orders": orders, "sequence": sequence, "machines": machines,
        "operators_by_stage": dict(operators_by_stage), "stage_config": stage_config,
        "stage_names": stage_names, "stage_order": stage_order, "overrides": overrides, "warnings": warnings,
    }


def config_row_values(r):
    """One process_schedule_config row -> dict (empty columns fall back to the defaults)."""
    d = DEFAULT_STAGE_CONFIG
    return {
        "batch_size": r.batch_size if r.batch_size else d["batch_size"],
        "next_day_release": d["next_day_release"] if r.next_day_release is None else bool(r.next_day_release),
        "cooldown_minutes": float(r.cooldown_minutes or 0),
        "cooldown_working_time_only": bool(r.cooldown_working_time_only),
        "setup_minutes": float(r.setup_minutes or 0),
    }


def build_schedule(db: Session, time_source: str = "actual", history_days: int = 7,
                   plant: Optional[str] = None, now: Optional[datetime] = None):
    inputs = load_schedule_inputs(db, time_source=time_source, history_days=history_days, plant=plant, now=now)
    return make_schedule(inputs)


def check_schedule_params(time_source, history_days):
    if time_source not in ("actual", "sap"):
        raise HTTPException(status_code=400, detail="time_source must be 'actual' or 'sap'")
    if history_days < 0:
        raise HTTPException(status_code=400, detail="history_days cannot be negative")


# ======================================================================================
# A5. ENDPOINTS
# ======================================================================================
@app.get("/schedule/data")
def get_schedule_data(time_source: str = "actual", history_days: int = 7, plant: Optional[str] = None,
                      db: Session = Depends(init_db)):
    """
    Everything the Machine Schedule and Planned Schedule tabs need, in one call.
      time_source  : "actual" | "sap" - which part_process_time column is used first
      history_days : finished orders stay visible this many days
      plant        : optional plant_code filter
    """
    check_schedule_params(time_source, history_days)
    try:
        return build_schedule(db, time_source=time_source, history_days=history_days, plant=plant)
    except RuntimeError as e:          # e.g. no working day in the next 365 days
        raise HTTPException(status_code=500, detail=str(e))


class OpChange(BaseModel):
    op_id: str
    machine_id: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None


class UpdatePayload(BaseModel):
    changes: List[OpChange]


@app.post("/schedule/update")
def update_schedule(payload: UpdatePayload, time_source: str = "actual", history_days: int = 7,
                    plant: Optional[str] = None, db: Session = Depends(init_db)):
    """
    Manual changes from the Edit dialog. Every change is checked against the current schedule
    BEFORE it is saved in schedule_override. Response: {"updated": n, "rejected": [{"op_id", "reason"}]}
    """
    check_schedule_params(time_source, history_days)
    try:
        state = build_state(load_schedule_inputs(db, time_source=time_source, history_days=history_days, plant=plant))
        results = validate_changes(state, [ch.dict() for ch in payload.changes])
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))

    updated = 0
    rejected = []
    for res in results:
        if not res["ok"]:
            rejected.append({"op_id": res["op_id"], "reason": res["reason"]})
            continue
        row = db.query(ScheduleOverride).filter(ScheduleOverride.op_id == res["op_id"]).first()
        if not row:
            row = ScheduleOverride(op_id=res["op_id"])
            db.add(row)
        row.machine_id = res["machine_id"]
        row.start_time = res["start_time"]
        row.end_time = res["end_time"]      # None = end is calculated from the calendar every time
        row.updated_at = datetime.utcnow()
        updated += 1
    db.commit()
    return {"updated": updated, "rejected": rejected}


# ======================================================================================
# A4. PROCESS SCHEDULE CONFIG ENDPOINTS
# ======================================================================================
class StageConfigPayload(BaseModel):
    stage_id: int
    batch_size: int = 30
    next_day_release: bool = True
    cooldown_minutes: float = 0
    cooldown_working_time_only: bool = False
    setup_minutes: float = 0


@app.get("/schedule/config")
def get_schedule_config(db: Session = Depends(init_db)):
    """All stages with their schedule config. Stages without a row get the defaults (is_default = true)."""
    rows = {r.stage_id: r for r in db.query(ProcessScheduleConfig).all()}
    batch_stages = {p.stage_id for p in db.query(Processtype).all() if p.process_type_batch}
    result = []
    stages = db.query(ProcessFlowMaster).all()
    stages.sort(key=lambda s: (s.step_order if s.step_order is not None else 9999, s.flow_step_id))
    for s in stages:
        r = rows.get(s.flow_step_id)
        values = config_row_values(r) if r else dict(DEFAULT_STAGE_CONFIG)
        values.update({
            "stage_id": s.flow_step_id,
            "stage_name": s.step_name,
            "process_mode": "BATCH" if s.flow_step_id in batch_stages else "SERIES",
            "is_default": r is None,
            "updated_at": iso(r.updated_at) if r else None,
        })
        result.append(values)
    return result


@app.post("/schedule/config")
def save_schedule_config(payload: StageConfigPayload, db: Session = Depends(init_db)):
    """Create or update the config of one stage."""
    if not db.query(ProcessFlowMaster).filter(ProcessFlowMaster.flow_step_id == payload.stage_id).first():
        raise HTTPException(status_code=404, detail="Stage %s does not exist" % payload.stage_id)
    if payload.batch_size < 1:
        raise HTTPException(status_code=400, detail="batch_size must be 1 or more")
    if payload.cooldown_minutes < 0 or payload.setup_minutes < 0:
        raise HTTPException(status_code=400, detail="minutes cannot be negative")

    row = db.query(ProcessScheduleConfig).filter(ProcessScheduleConfig.stage_id == payload.stage_id).first()
    if not row:
        row = ProcessScheduleConfig(stage_id=payload.stage_id)
        db.add(row)
    row.batch_size = payload.batch_size
    row.next_day_release = payload.next_day_release
    row.cooldown_minutes = payload.cooldown_minutes
    row.cooldown_working_time_only = payload.cooldown_working_time_only
    row.setup_minutes = payload.setup_minutes
    row.updated_at = datetime.now()
    db.commit()
    return {"status": "success", "stage_id": payload.stage_id}


@app.delete("/schedule/config/{stage_id}")
def delete_schedule_config(stage_id: int, db: Session = Depends(init_db)):
    """Remove the config row of a stage -> the stage goes back to the defaults."""
    row = db.query(ProcessScheduleConfig).filter(ProcessScheduleConfig.stage_id == stage_id).first()
    if not row:
        return {"status": "success", "deleted": False}
    db.delete(row)
    db.commit()
    return {"status": "success", "deleted": True}


if __name__ == "__main__":
    uvicorn.run(app, host=HOST, port=PORT)