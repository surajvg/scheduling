import {
  BASE_DAY_WIDTH, LAYOUT, PO_PALETTE, MAX_CUSTOM_RANGE_DAYS, DEFAULT_CALENDAR,
} from "./scheduleConfig";

export const DAY = 24 * 3600 * 1000;
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const pad = (n) => String(n).padStart(2, "0");

/* ---------- date helpers ---------- */
// "2026-10-12T06:00:00" (no timezone) is parsed as LOCAL time by the browser, which is what we want.
export const parseTime = (s) => (s ? new Date(s).getTime() : NaN);
export const toLocalIso = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
};
export const toDateInput = (ts) => {
  if (!ts) return "";
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
export const fromDateInput = (s) => {
  if (!s) return null;
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d).getTime();
};
export const startOfDay = (ts) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
export const addDays = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime(); };
export const addMonths = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth() + n, 1).getTime(); };
const startOfWeekMon = (ts) => { const d = new Date(startOfDay(ts)); const back = (d.getDay() + 6) % 7; return addDays(d.getTime(), -back); };

export const fmtDateTime = (ts) => new Date(ts).toLocaleString("en-US");
export const fmtShortDate = (ts) => { const d = new Date(ts); return `${pad(d.getDate())} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
export const fmtHours = (h) => `${(Math.round(h * 10) / 10).toFixed(1)}h`;
const dayLabel = (ts) => { const d = new Date(ts); return `${WEEKDAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };

/* ---------- time range for a view ---------- */
// anchor = any timestamp inside the period being shown
export function getRange(view, anchor, customStart, customEnd) {
  if (customStart && customEnd) {
    const s = startOfDay(Math.min(customStart, customEnd));
    let e = addDays(startOfDay(Math.max(customStart, customEnd)), 1);
    if ((e - s) / DAY > MAX_CUSTOM_RANGE_DAYS) e = addDays(s, MAX_CUSTOM_RANGE_DAYS);
    return { start: s, end: e, custom: true };
  }
  switch (view) {
    case "daily": { const s = startOfDay(anchor); return { start: s, end: addDays(s, 1) }; }
    case "weekly": { const s = startOfWeekMon(anchor); return { start: s, end: addDays(s, 7) }; }
    case "monthly": { const s = addMonths(anchor, 0); return { start: s, end: addMonths(s, 1) }; }
    default: { const s = addMonths(anchor, -1); return { start: s, end: addMonths(s, 12) }; } // yearly
  }
}

export function shiftAnchor(view, anchor, dir, range) {
  if (range?.custom) return anchor;
  switch (view) {
    case "daily": return addDays(anchor, dir);
    case "weekly": return addDays(anchor, 7 * dir);
    case "monthly": return addMonths(anchor, dir);
    default: return addMonths(anchor, 12 * dir);
  }
}

/* ---------- the time axis ---------- */
/**
 * Daily / Weekly views only draw the working window of each day (e.g. 06:00-20:00) so the
 * night is not wasted space; Monthly / Yearly draw the full 24 h.
 * toX / toTime convert between a timestamp and a pixel x inside the timeline.
 */
export function buildScale({ view, range, zoom, calendar, availableWidth }) {
  const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
  const windowed = view === "daily" || view === "weekly";
  const wStart = windowed ? cal.shift_start : 0;
  const wEnd = windowed ? cal.shift_end : 24;
  const hours = wEnd - wStart;

  const days = [];
  for (let t = range.start; t < range.end; t = addDays(t, 1)) days.push(t);

  const baseDay = BASE_DAY_WIDTH[view] || 100;
  const fill = Math.max(0, availableWidth) / Math.max(days.length, 1);
  const dayW = Math.max(baseDay, fill) * zoom;
  const totalWidth = dayW * days.length;

  const winStart = (i) => days[i] + wStart * 3600e3;
  const winLen = hours * 3600e3;

  const dayIndexOf = (ts) => {
    if (ts <= days[0]) return -1;
    let lo = 0, hi = days.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (days[mid] <= ts) lo = mid; else hi = mid - 1; }
    return ts >= range.end ? days.length : lo;
  };

  const toX = (ts) => {
    const i = dayIndexOf(ts);
    if (i < 0) return 0;
    if (i >= days.length) return totalWidth;
    const frac = Math.min(1, Math.max(0, (ts - winStart(i)) / winLen));
    return i * dayW + frac * dayW;
  };
  const toTime = (x) => {
    const cx = Math.min(totalWidth - 0.001, Math.max(0, x));
    const i = Math.floor(cx / dayW);
    const frac = (cx - i * dayW) / dayW;
    return winStart(i) + frac * winLen;
  };

  /* header rows + grid */
  const row1 = [], row2 = [], grid = [];
  const groupBy = (keyFn, labelFn, target) => {
    let startIdx = 0;
    for (let i = 1; i <= days.length; i++) {
      if (i === days.length || keyFn(days[i]) !== keyFn(days[startIdx])) {
        target.push({ x: startIdx * dayW, w: (i - startIdx) * dayW, label: labelFn(days[startIdx], i - startIdx) });
        startIdx = i;
      }
    }
  };

  if (view === "daily" || view === "weekly") {
    days.forEach((d, i) => {
      row1.push({ x: i * dayW, w: dayW, label: dayLabel(d) });
      const step = view === "daily" ? Math.max(1, Math.ceil(46 / (dayW / hours))) : 6;
      const ticks = [wStart];
      for (let h = wStart + 1; h < wEnd; h++) if ((view === "daily" ? (h - wStart) % step === 0 : h % step === 0)) ticks.push(h);
      ticks.forEach((h, k) => {
        const next = k + 1 < ticks.length ? ticks[k + 1] : wEnd;
        row2.push({ x: i * dayW + ((h - wStart) / hours) * dayW, w: ((next - h) / hours) * dayW, label: `${pad(h)}:00` });
      });
    });
  } else if (view === "monthly") {
    groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
      (t) => `${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][new Date(t).getMonth()]} ${new Date(t).getFullYear()}`, row1);
    days.forEach((d, i) => row2.push({ x: i * dayW, w: dayW, label: String(new Date(d).getDate()), sub: WEEKDAYS[new Date(d).getDay()][0] }));
  } else {
    groupBy((t) => new Date(t).getFullYear(), (t) => String(new Date(t).getFullYear()), row1);
    groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
      (t, n) => (n * dayW < 30 ? MONTHS[new Date(t).getMonth()][0] : MONTHS[new Date(t).getMonth()]), row2);
  }
  row2.forEach((c) => grid.push({ x: c.x, strong: false }));
  row1.forEach((c) => grid.push({ x: c.x, strong: true }));

  /* non-working days + (daily / weekly) the hours between shifts.
     day_windows comes from the server and already contains weekends, holidays, half days and every runtime shift change. */
  const dw = cal.day_windows;
  const holidaySet = new Set((cal.holidays || []).map((h) => h.holiday_date));
  const offDays = [];
  const offHours = [];
  if (dayW >= 12) {
    days.forEach((d, i) => {
      const key = toDateInput(d);
      const wins = dw ? (dw[key] || []) : null;
      const isOff = dw ? wins.length === 0 : ((cal.week_off || []).includes(new Date(d).getDay()) || holidaySet.has(key));
      if (isOff) { offDays.push({ x: i * dayW, w: dayW }); return; }
      if (dw && windowed) {
        const px = (m) => i * dayW + ((m - wStart * 60) / (hours * 60)) * dayW;
        let cur = wStart * 60;
        wins.forEach(([s, e]) => {
          if (s > cur) offHours.push({ x: px(cur), w: px(Math.min(s, wEnd * 60)) - px(cur) });
          cur = Math.max(cur, e);
        });
        if (cur < wEnd * 60) offHours.push({ x: px(cur), w: px(wEnd * 60) - px(cur) });
      }
    });
  }

  return { days, dayW, totalWidth, toX, toTime, row1, row2, grid, offDays, offHours, windowed };
}

/* ---------- operations -> rows ---------- */
// Stack overlapping operations of one machine into lanes so nothing is hidden.
export function layoutRows(machines, ops, scale, barLines) {
  const laneH = barLines === 2 ? LAYOUT.laneHeight2Line : LAYOUT.laneHeight1Line;
  const byMachine = {};
  ops.forEach((o) => { (byMachine[o.machine_id] = byMachine[o.machine_id] || []).push(o); });

  let top = 0;
  return machines.map((m) => {
    const mine = (byMachine[m.machine_id] || []).slice().sort((a, b) => a.start - b.start);
    const laneEnds = []; // end TIME of the last bar in each lane (stack only genuinely overlapping operations)
    const bars = mine.map((o) => {
      const x = scale.toX(o.start);
      const w = Math.max(scale.toX(o.end) - x, 3);
      let lane = laneEnds.findIndex((end) => end <= o.start);
      if (lane < 0) { lane = laneEnds.length; laneEnds.push(0); }
      laneEnds[lane] = o.end;
      // working pieces (nothing is drawn over nights / breaks between shifts / holidays)
      const pieces = (o.segments || [[o.start, o.end]]).map(([a, b]) => {
        const px = scale.toX(a);
        return { x: px, w: Math.max(scale.toX(b) - px, 2) };
      }).filter((p) => p.x < scale.totalWidth);
      return { op: o, x, w, lane, pieces: pieces.length ? pieces : [{ x, w }] };
    });
    const lanes = Math.max(laneEnds.length, 1);
    const height = bars.length ? lanes * laneH + 2 * LAYOUT.barPad : LAYOUT.rowMin;
    const row = { machine: m, bars, top, height, laneH };
    top += height;
    return row;
  });
}

/* ---------- misc ---------- */
export const machineLabel = (m) => `${m.work_centre} - ${m.machine_name}`;

export function buildColorMap(ops) {
  const pos = Array.from(new Set(ops.map((o) => o.production_order))).sort();
  const map = {};
  pos.forEach((po, i) => { map[po] = PO_PALETTE[i % PO_PALETTE.length]; });
  return map;
}

// [["2026-10-12T06:00:00", "2026-10-12T14:00:00"], ...] -> [[startMs, endMs], ...]; one piece if the server sends none
const toSegments = (raw, start, end) => {
  const list = (raw || [])
    .map(([a, b]) => [parseTime(a), parseTime(b)])
    .filter(([a, b]) => Number.isFinite(a) && Number.isFinite(b) && b > a);
  return list.length ? list : [[start, end]];
};

// Convert raw API tasks (one per series operation / one per batch) into the shape the chart draws.
export function normaliseOps(rawOps, mode) {
  return rawOps
    .map((o) => {
      const planned = mode === "planned";
      const start = parseTime(planned ? o.planned_start : o.start_time);
      const end = parseTime(planned ? o.planned_end : o.end_time);
      return {
        ...o,
        machine_id: planned ? o.planned_machine_id : o.machine_id,
        start, end,
        segments: toSegments(planned ? o.planned_segments : o.segments, start, end),
        pdc: parseTime(o.planned_end),
      };
    })
    .filter((o) => Number.isFinite(o.start) && Number.isFinite(o.end));
}

export const overlapsRange = (o, range) => o.end > range.start && o.start < range.end;
