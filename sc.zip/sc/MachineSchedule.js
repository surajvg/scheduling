import React, { useCallback, useMemo, useState } from "react";
import { Alert, Box, Button, Snackbar, Stack } from "@mui/material";
import GanttTimeline from "./GanttTimeline";
import useGanttControls from "./useGanttControls";
import {
  ChartTools, DateRangeField, InfoPopover, MultiSelect, ProductionOrdersLegend, RefreshButton, UpdateButton, ViewSelect,
} from "./ScheduleControls";
import { buildColorMap, machineLabel, normaliseOps, overlapsRange, parseTime } from "./scheduleUtils";

/**
 * Current schedule, filterable; bars can be dragged and saved with Update.
 *  resourceType : null = every row, "MACHINE" = machines only, "MANUAL" = operators of manual steps only
 * A dragged task is pinned: the server keeps its slot and re-plans the other work around it.
 */
const MachineSchedule = ({ data, loading, onRefresh, saveChanges, clearOverrides, resourceType = null }) => {
  const ctl = useGanttControls("weekly");
  const [machineSel, setMachineSel] = useState([]);
  const [partSel, setPartSel] = useState([]);
  const [poSel, setPoSel] = useState([]);
  const [infoAnchor, setInfoAnchor] = useState(null);
  const [edits, setEdits] = useState({}); // task id -> { machine_id, start_time, end_time }
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const machines = useMemo(
    () => (data?.machines || []).filter((m) => !resourceType || m.resource_type === resourceType),
    [data, resourceType]
  );
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);
  const blocks = useMemo(() => (data?.interlocks || []).filter((i) => i.severity === "BLOCK" && i.start_time), [data]);

  // apply un-saved drag edits on top of the server data (the working pieces are recalculated by the server)
  const ops = useMemo(() => baseOps.map((o) => {
    const e = edits[o.op_id];
    if (!e) return o;
    const start = parseTime(e.start_time);
    const end = parseTime(e.end_time);
    return { ...o, machine_id: e.machine_id, start, end, segments: [[start, end]] };
  }), [baseOps, edits]);

  const filteredOps = useMemo(() => ops.filter((o) =>
    (!machineSel.length || machineSel.includes(o.machine_id)) &&
    (!partSel.length || partSel.includes(o.part_number)) &&
    (!poSel.length || poSel.includes(o.production_order)) &&
    overlapsRange(o, ctl.range)), [ops, machineSel, partSel, poSel, ctl.range]);

  const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);

  const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);
  const partOptions = useMemo(() => Array.from(new Set(baseOps.map((o) => o.part_number))).sort(), [baseOps]);
  const poOptions = useMemo(() => Object.keys(colorMap), [colorMap]);
  const pendingIds = useMemo(() => new Set(Object.keys(edits)), [edits]);
  const pinnedIds = useMemo(() => baseOps.filter((o) => o.pinned).map((o) => o.op_id), [baseOps]);
  const problems = useMemo(() => baseOps.filter((o) => (o.conflicts || []).length || o.interlock_blocked), [baseOps]);

  const onChangeOp = useCallback((op, patch) => setEdits((prev) => ({ ...prev, [op.op_id]: patch })), []);

  const handleUpdate = async () => {
    setSaving(true);
    try {
      await saveChanges(Object.entries(edits).map(([op_id, p]) => ({ op_id, ...p })));
      setEdits({});
      await onRefresh();
      setToast({ severity: "success", msg: "Schedule updated - the other operations were re-planned around your change." });
    } catch (e) {
      setToast({ severity: "error", msg: "Could not save the schedule changes." });
    } finally { setSaving(false); }
  };

  const handleClearMoves = async () => {
    try {
      await clearOverrides(pinnedIds);
      setEdits({});
      await onRefresh();
      setToast({ severity: "success", msg: "Manual moves removed." });
    } catch (e) {
      setToast({ severity: "error", msg: "Could not remove the manual moves." });
    }
  };

  const pickOrders = (list) => {
    setPoSel(list);
    const mine = baseOps.filter((o) => list.includes(o.production_order));
    if (mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start))); // jump to where the order is scheduled
  };

  const handleRefresh = async () => { setEdits({}); await onRefresh(); };

  return (
    <Box>
      <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 1.25 }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <MultiSelect placeholder={resourceType === "MANUAL" ? "Select Operators" : "Select Machines"}
          options={machines.map((m) => m.machine_id)} value={machineSel}
          onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
        <MultiSelect placeholder="Select Part Number" options={partOptions} value={partSel} onChange={setPartSel} width={210} />
        <MultiSelect placeholder="Select Production Orders" options={poOptions} value={poSel} onChange={pickOrders} width={230} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen}
          toggleFullscreen={ctl.toggleFullscreen} onInfo={(e) => setInfoAnchor(e.currentTarget)} />
      </Stack>
      <Stack direction="row" spacing={1.25} sx={{ mb: 2 }}>
        <UpdateButton onClick={handleUpdate} count={pendingIds.size} saving={saving} />
        <RefreshButton onClick={handleRefresh} dark loading={loading} />
        {pinnedIds.length > 0 && (
          <Button size="small" variant="outlined" onClick={handleClearMoves} sx={{ textTransform: "none" }}>
            Remove {pinnedIds.length} manual move{pinnedIds.length > 1 ? "s" : ""}
          </Button>
        )}
      </Stack>

      {problems.length > 0 && (
        <Alert severity="warning" sx={{ mb: 1.5 }}>
          {problems.length} task(s) need attention (red outline): they overlap another task, start before the previous
          operation has finished, run during an interlock, or are provisional because every machine of the step is interlocked.
          Hover a bar for details.
        </Alert>
      )}

      <GanttTimeline
        machines={rows} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
        calendar={data?.calendar} colorMap={colorMap} barLines={2} editable pendingIds={pendingIds} blocks={blocks}
        onChangeOp={onChangeOp} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
      />
      <ProductionOrdersLegend colorMap={colorMap} title="Production Orders" />
      <Box sx={{ fontSize: 12, color: "#6b7280", mt: 1 }}>
        Red hatched area = resource interlocked (breakdown, maintenance, spare / consumable out of stock). Grey bands = no shift running.
        Dashed line = the task pauses between shifts / days off. "B2/3" = batch 2 of 3 (max 30 PCBs per batch).
      </Box>

      <InfoPopover anchorEl={infoAnchor} onClose={() => setInfoAnchor(null)} editable />
      <Snackbar open={Boolean(toast)} autoHideDuration={3500} onClose={() => setToast(null)} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        {toast ? <Alert severity={toast.severity} variant="filled" onClose={() => setToast(null)}>{toast.msg}</Alert> : undefined}
      </Snackbar>
    </Box>
  );
};

export default MachineSchedule;
