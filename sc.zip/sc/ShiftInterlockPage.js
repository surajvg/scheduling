import React, { useCallback, useEffect, useState } from "react";
import axios from "axios";
import {
  Alert, Autocomplete, Box, Button, Chip, IconButton, MenuItem, Select, Switch, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TextField, Typography,
} from "@mui/material";
import { Delete as DeleteIcon } from "@mui/icons-material";
import { API_ROUTES, INTERLOCK_META, THEME } from "./scheduleConfig";
import { fmtDateTime, parseTime } from "./scheduleUtils";

const card = { border: `1px solid ${THEME.border}`, borderRadius: "8px", p: 2, mb: 2.5 };
const h = { fontSize: 15, fontWeight: 600, mb: 0.5 };
const note = { fontSize: 12.5, color: THEME.muted, mb: 1.5 };
const th = { "& th": { fontWeight: 600, bgcolor: "#f7f8fb" } };
const today = () => new Date().toISOString().slice(0, 10);

/**
 * "Shifts & Interlocks" tab.
 *  1. shift definitions            GET/POST/DELETE /schedule/shifts
 *  2. runtime working-time changes POST/DELETE     /schedule/shift-changes   (extra shift, overtime, shift off, operator absent)
 *  3. operator shifts              PUT             /schedule/operator-shifts/{staff_no}
 *  4. interlocks (read-only)       data.interlocks
 * Every change calls onChanged() so the schedule is re-planned immediately.
 */
const ShiftInterlockPage = ({ apiBase, data, onChanged }) => {
  const [shifts, setShifts] = useState([]);
  const [changes, setChanges] = useState([]);
  const [opShifts, setOpShifts] = useState({});
  const [derived, setDerived] = useState(false);
  const [msg, setMsg] = useState(null);
  const [form, setForm] = useState({ action: "add", date_from: today(), date_to: today(), shift_name: "", start_time: "06:00", end_time: "14:00", operator: "", note: "" });

  const call = (p) => p.catch((e) => { setMsg({ severity: "error", text: e.response?.data?.detail || e.message }); throw e; });

  const load = useCallback(() => {
    if (!apiBase) return;
    axios.get(apiBase + API_ROUTES.shifts).then((r) => {
      setShifts(r.data.shifts || []); setChanges(r.data.changes || []); setOpShifts(r.data.operator_shifts || {}); setDerived(Boolean(r.data.derived));
    }).catch((e) => setMsg({ severity: "error", text: "Could not load shifts: " + (e.response?.data?.detail || e.message) }));
  }, [apiBase]);
  useEffect(() => { load(); }, [load]);

  const done = (text) => { setMsg({ severity: "success", text }); load(); onChanged && onChanged(); };
  const edit = (i, f, v) => setShifts(shifts.map((s, k) => (k === i ? { ...s, [f]: v, changed: true } : s)));

  const saveShift = (s, i) => call(axios.post(apiBase + API_ROUTES.shifts, { ...s, sort_order: i }))
    .then(() => done(`${s.name} saved - schedule re-planned.`)).catch(() => {});
  const deleteShift = (s) => call(axios.delete(`${apiBase}${API_ROUTES.shifts}/${s.id}`)).then(() => done(`${s.name} deleted.`)).catch(() => {});
  const seed = () => call(axios.post(apiBase + API_ROUTES.shifts + "/seed")).then(() => done("Shifts stored.")).catch(() => {});
  const addShift = () => setShifts([...shifts, { id: null, name: `Shift ${shifts.length + 1}`, start_time: "22:00", end_time: "06:00", is_active: false, changed: true }]);

  const applyChange = () => {
    const body = {
      action: form.action, date_from: form.date_from, date_to: form.date_to || form.date_from,
      shift_name: form.shift_name || null, operator_staff_no: form.operator || null, note: form.note || null,
      ...(form.action === "add" ? { start_time: form.start_time, end_time: form.end_time } : {}),
    };
    call(axios.post(apiBase + API_ROUTES.shiftChanges, body)).then(() => done("Working time changed - schedule re-planned.")).catch(() => {});
  };
  const deleteChange = (c) => call(axios.delete(`${apiBase}${API_ROUTES.shiftChanges}/${c.id}`)).then(() => done("Change removed.")).catch(() => {});
  const saveOpShifts = (staff, list) => call(axios.put(`${apiBase}${API_ROUTES.operatorShifts}/${staff}`, { shifts: list }))
    .then(() => done("Operator shifts saved.")).catch(() => {});

  const shiftNames = shifts.map((s) => s.name);
  const operators = data?.operators || [];
  const interlocks = data?.interlocks || [];
  const describe = (c) => {
    const what = c.action === "add" ? `Extra hours ${c.start_time}-${c.end_time}`
      : c.action === "enable" ? `Shift on: ${c.shift_name}` : c.shift_name ? `Shift off: ${c.shift_name}` : "No work";
    const who = c.operator_staff_no ? (operators.find((o) => o.staff_no === c.operator_staff_no)?.name || c.operator_staff_no) : "Whole plant";
    return `${what} - ${who}`;
  };

  return (
    <Box>
      {msg && <Alert severity={msg.severity} sx={{ mb: 2 }} onClose={() => setMsg(null)}>{msg.text}</Alert>}

      {/* 1. shift definitions */}
      <Box sx={card}>
        <Typography sx={h}>Shifts</Typography>
        <Typography sx={note}>
          Working time of the plant. A shift that ends before it starts runs past midnight. A shift that is switched off here
          (for example a night shift) can still be turned on for a few days below.
        </Typography>
        {derived && (
          <Alert severity="info" sx={{ mb: 1.5 }} action={<Button size="small" color="inherit" onClick={seed}>Store shifts</Button>}>
            These shifts are derived from the stage capacity table. Store them to edit them here.
          </Alert>
        )}
        <TableContainer>
          <Table size="small">
            <TableHead><TableRow sx={th}>
              <TableCell>Name</TableCell><TableCell>Start</TableCell><TableCell>End</TableCell><TableCell>Normally running</TableCell><TableCell align="right">Actions</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {shifts.map((s, i) => (
                <TableRow key={s.id ?? `new-${i}`} sx={{ bgcolor: s.changed ? "#fffbeb" : "inherit" }}>
                  <TableCell><TextField size="small" value={s.name} sx={{ width: 150 }} onChange={(e) => edit(i, "name", e.target.value)} /></TableCell>
                  <TableCell><TextField size="small" type="time" value={s.start_time} onChange={(e) => edit(i, "start_time", e.target.value)} /></TableCell>
                  <TableCell><TextField size="small" type="time" value={s.end_time} onChange={(e) => edit(i, "end_time", e.target.value)} /></TableCell>
                  <TableCell><Switch size="small" checked={Boolean(s.is_active)} onChange={(e) => edit(i, "is_active", e.target.checked)} /></TableCell>
                  <TableCell align="right" sx={{ whiteSpace: "nowrap" }}>
                    <Button size="small" variant="contained" sx={{ textTransform: "none", mr: 1 }} disabled={derived} onClick={() => saveShift(s, i)}>Save</Button>
                    <IconButton size="small" disabled={!s.id} onClick={() => deleteShift(s)}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Button size="small" sx={{ textTransform: "none", mt: 1 }} disabled={derived} onClick={addShift}>+ Add shift</Button>
      </Box>

      {/* 2. runtime change */}
      <Box sx={card}>
        <Typography sx={h}>Change working time (takes effect immediately)</Typography>
        <Typography sx={note}>
          Extend or reduce the shifts for some days without touching the shift definitions. The Gantt re-plans every
          operation that has not started yet.
        </Typography>
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.25, alignItems: "center", mb: 1.5 }}>
          <Select size="small" value={form.action} sx={{ width: 215 }} onChange={(e) => setForm({ ...form, action: e.target.value })}>
            <MenuItem value="add">Add extra hours (overtime)</MenuItem>
            <MenuItem value="enable">Switch a shift on</MenuItem>
            <MenuItem value="disable">Switch a shift off / no work</MenuItem>
          </Select>
          <TextField size="small" type="date" label="From" InputLabelProps={{ shrink: true }} value={form.date_from} onChange={(e) => setForm({ ...form, date_from: e.target.value })} />
          <TextField size="small" type="date" label="To" InputLabelProps={{ shrink: true }} value={form.date_to} onChange={(e) => setForm({ ...form, date_to: e.target.value })} />
          {form.action === "add" ? (
            <>
              <TextField size="small" type="time" label="Start" InputLabelProps={{ shrink: true }} value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
              <TextField size="small" type="time" label="End" InputLabelProps={{ shrink: true }} value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
            </>
          ) : (
            <Select size="small" displayEmpty value={form.shift_name} sx={{ width: 160 }} onChange={(e) => setForm({ ...form, shift_name: e.target.value })}>
              <MenuItem value="">{form.action === "disable" ? "All shifts" : "Choose shift"}</MenuItem>
              {shiftNames.map((n) => <MenuItem key={n} value={n}>{n}</MenuItem>)}
            </Select>
          )}
          <Select size="small" displayEmpty value={form.operator} sx={{ width: 190 }} onChange={(e) => setForm({ ...form, operator: e.target.value })}>
            <MenuItem value="">Whole plant</MenuItem>
            {operators.map((o) => <MenuItem key={o.staff_no} value={o.staff_no}>{o.name} ({o.staff_no})</MenuItem>)}
          </Select>
          <TextField size="small" label="Note" value={form.note} sx={{ width: 170 }} onChange={(e) => setForm({ ...form, note: e.target.value })} />
          <Button variant="contained" size="small" sx={{ textTransform: "none" }} onClick={applyChange}
            disabled={!form.date_from || (form.action === "enable" && !form.shift_name)}>Apply</Button>
        </Box>
        {changes.length > 0 && (
          <TableContainer>
            <Table size="small">
              <TableHead><TableRow sx={th}><TableCell>Change</TableCell><TableCell>From</TableCell><TableCell>To</TableCell><TableCell>Note</TableCell><TableCell /></TableRow></TableHead>
              <TableBody>
                {changes.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>{describe(c)}</TableCell><TableCell>{c.date_from}</TableCell><TableCell>{c.date_to}</TableCell><TableCell>{c.note || "-"}</TableCell>
                    <TableCell align="right"><IconButton size="small" onClick={() => deleteChange(c)}><DeleteIcon fontSize="small" /></IconButton></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>

      {/* 3. operator shifts */}
      <Box sx={card}>
        <Typography sx={h}>Operator shifts</Typography>
        <Typography sx={note}>Manual operations are planned only inside the shifts of the operator doing them. No shift selected = every running shift.</Typography>
        <TableContainer>
          <Table size="small">
            <TableHead><TableRow sx={th}><TableCell>Operator</TableCell><TableCell>Staff no</TableCell><TableCell>Works</TableCell></TableRow></TableHead>
            <TableBody>
              {operators.length === 0 && <TableRow><TableCell colSpan={3} sx={{ color: THEME.muted }}>No operators found.</TableCell></TableRow>}
              {operators.map((o) => (
                <TableRow key={o.staff_no}>
                  <TableCell>{o.name}</TableCell><TableCell>{o.staff_no}</TableCell>
                  <TableCell>
                    <Autocomplete multiple size="small" sx={{ width: 320 }} options={shiftNames} value={opShifts[o.staff_no] || o.shifts || []}
                      onChange={(e, v) => { setOpShifts({ ...opShifts, [o.staff_no]: v }); saveOpShifts(o.staff_no, v); }}
                      renderInput={(p) => <TextField {...p} placeholder={(opShifts[o.staff_no] || o.shifts || []).length ? "" : "All shifts"} />} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      {/* 4. interlocks */}
      <Box sx={card}>
        <Typography sx={h}>Interlocks</Typography>
        <Typography sx={note}>
          A BLOCK keeps work off that machine / operator (the plan uses another one, or waits). A WARN is only information.
          Resolve them in Maintenance, Spares / Consumables and Operator MRL screens - the plan updates on the next refresh.
        </Typography>
        <TableContainer>
          <Table size="small">
            <TableHead><TableRow sx={th}><TableCell>Resource</TableCell><TableCell>Type</TableCell><TableCell>Level</TableCell><TableCell>Reason</TableCell><TableCell>From</TableCell><TableCell>Until</TableCell></TableRow></TableHead>
            <TableBody>
              {interlocks.length === 0 && <TableRow><TableCell colSpan={6} sx={{ color: THEME.muted }}>No active interlocks.</TableCell></TableRow>}
              {interlocks.map((i, k) => (
                <TableRow key={k}>
                  <TableCell>{i.resource_name}</TableCell>
                  <TableCell>{INTERLOCK_META[i.type]?.label || i.type}</TableCell>
                  <TableCell><Chip size="small" label={i.severity} color={i.severity === "BLOCK" ? "error" : "warning"} sx={{ height: 20, fontSize: 11 }} /></TableCell>
                  <TableCell>{i.message}</TableCell>
                  <TableCell>{i.start_time ? fmtDateTime(parseTime(i.start_time)) : "-"}</TableCell>
                  <TableCell>{i.end_time ? fmtDateTime(parseTime(i.end_time)) : i.severity === "BLOCK" ? "until resolved" : "-"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </Box>
  );
};

export default ShiftInterlockPage;
