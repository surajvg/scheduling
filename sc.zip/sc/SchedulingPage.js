import React, { useState } from "react";
import { Alert, Box, Button, Collapse, LinearProgress, Tab, Tabs, Typography } from "@mui/material";
import { EventNote as ScheduleIcon } from "@mui/icons-material";
import useScheduleData from "./useScheduleData";
import MachineSchedule from "./MachineSchedule";
import PlannedSchedule from "./PlannedSchedule";
import ScheduleConfigPage from "./ScheduleConfigPage";
import ShiftInterlockPage from "./ShiftInterlockPage";

const tabSx = { textTransform: "none", fontSize: 14, minHeight: 44 };

/** SMT production schedule: machines (printer, SPI, pick & place, reflow) and operators of manual steps. */
const SchedulingPage = () => {
  const { data, loading, error, refresh, saveChanges, clearOverrides, apiBase } = useScheduleData();
  const [tab, setTab] = useState(0);
  const [showWarnings, setShowWarnings] = useState(false);

  const warnings = data?.warnings || [];
  const blocked = (data?.interlocks || []).filter((i) => i.severity === "BLOCK").length;
  const isChart = tab <= 3;

  return (
    <Box sx={{ p: 3, bgcolor: "#f7f8fb", minHeight: "100%", fontFamily: (theme) => theme.typography.fontFamily }}>
      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", px: 2.5, py: 2, mb: 2.5, display: "flex", alignItems: "center", gap: 1.25, border: "1px solid #e3e7ee" }}>
        <ScheduleIcon />
        <Typography sx={{ fontSize: 19, fontWeight: 500 }}>Production Schedule</Typography>
        {data?.generated_at && (
          <Typography sx={{ fontSize: 12, color: "#6b7280", ml: "auto" }}>
            Calculated {new Date(data.generated_at).toLocaleString("en-IN")}
          </Typography>
        )}
      </Box>

      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", border: "1px solid #e3e7ee", px: 2.5, pt: 1, pb: 2.5 }}>
        <Tabs value={tab} onChange={(e, v) => setTab(v)} variant="scrollable" sx={{ borderBottom: "1px solid #e3e7ee", mb: 2 }}>
          <Tab label="Machine Schedule" sx={tabSx} />
          <Tab label="Planned Schedule" sx={tabSx} />
          <Tab label="Machine-Only" sx={tabSx} />
          <Tab label="Manual-Only" sx={tabSx} />
          <Tab label={blocked ? `Shifts & Interlocks (${blocked})` : "Shifts & Interlocks"} sx={tabSx} />
          <Tab label="Process Config" sx={tabSx} />
        </Tabs>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {loading && <LinearProgress sx={{ mb: 1 }} />}

        {isChart && warnings.length > 0 && (
          <Alert severity="warning" sx={{ mb: 2 }}
            action={<Button color="inherit" size="small" onClick={() => setShowWarnings(!showWarnings)}>{showWarnings ? "Hide" : "Show"}</Button>}>
            {warnings.length} scheduling warning(s)
            <Collapse in={showWarnings}>
              <Box component="ul" sx={{ m: 0, mt: 1, pl: 2.5, maxHeight: 200, overflow: "auto" }}>
                {warnings.map((w, i) => <li key={i}>{w}</li>)}
              </Box>
            </Collapse>
          </Alert>
        )}

        {tab === 0 && <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} clearOverrides={clearOverrides} />}
        {tab === 1 && <PlannedSchedule data={data} loading={loading} onRefresh={refresh} />}
        {tab === 2 && <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} clearOverrides={clearOverrides} resourceType="MACHINE" />}
        {tab === 3 && <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} clearOverrides={clearOverrides} resourceType="MANUAL" />}
        {tab === 4 && <ShiftInterlockPage apiBase={apiBase} data={data} onChanged={refresh} />}
        {tab === 5 && <ScheduleConfigPage apiBase={apiBase} onChanged={refresh} />}
      </Box>
    </Box>
  );
};

export default SchedulingPage;
