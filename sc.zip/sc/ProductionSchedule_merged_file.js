// // import React, { useEffect, useState, useMemo, useCallback } from "react";
// // import axios from "axios";
// // import {
// //   Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle,
// //   IconButton, MenuItem, Select, Stack, Tab, Tabs, TextField, Tooltip, Typography,
// //   Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
// //   LinearProgress
// // } from "@mui/material";
// // import {
// //   EventNote as ScheduleIcon, Refresh as RefreshIcon, ZoomIn as ZoomInIcon, ZoomOut as ZoomOutIcon,
// //   ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon
// // } from "@mui/icons-material";

// // // --- CONSTANTS & PALETTE ---
// // const DEFAULT_API_BASE = "http://127.0.0.1:2000";
// // const PO_COLORS = ["#1e88e5", "#f59e0b", "#10b981", "#e11d48", "#8b5cf6", "#14b8a6", "#f97316"];
// // const EMPTY_DATA = { machines: [], operations: [], production_orders: [], calendar: { holidays: [], half_days: [] }, warnings: [] };

// // // --- UTILITIES ---
// // const fmt = (text) => text ? new Date(text).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: false }) : "-";
// // const machineLabel = (m) => m.machine_name && m.machine_name !== m.machine_id ? `${m.machine_id} - ${m.machine_name}` : m.machine_id;

// // /**
// //  * Edit Operation Dialog Component
// //  */
// // const EditOperationDialog = ({ open, op, machines, apiBase, onClose, onSaved }) => {
// //   const [machineId, setMachineId] = useState("");
// //   const [start, setStart] = useState("");
// //   const [saving, setSaving] = useState(false);
// //   const [error, setError] = useState("");

// //   useEffect(() => {
// //     if (op) {
// //       setMachineId(op.machine_id);
// //       setStart((op.start_time || "").slice(0, 16));
// //       setError("");
// //     }
// //   }, [op]);

// //   if (!op) return null;
// //   const stageMachines = machines.filter((m) => m.stage_id === op.flow_step_id);
// //   const completed = op.status === "COMPLETED";

// //   const handleUpdate = () => {
// //     setSaving(true);
// //     setError("");
// //     axios.post(`${apiBase}/schedule/update`, { changes: [{ op_id: op.op_id, machine_id: machineId, start_time: start + ":00" }] })
// //       .then((res) => { if (res.data.updated > 0) onSaved(); else setError("Update rejected by server."); })
// //       .catch((err) => setError("Could not save: " + (err.response?.data?.detail || err.message)))
// //       .finally(() => setSaving(false));
// //   };

// //   return (
// //     <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
// //       <DialogTitle sx={{ fontSize: 17 }}>{op.production_order} · {op.operation_no} - {op.step_name}</DialogTitle>
// //       <DialogContent>
// //         <Box sx={{ fontSize: 13, color: "#4b5563", mb: 2, lineHeight: 1.7 }}>
// //           <div>Part: <b>{op.part_number}</b> · {op.process_mode} · {op.completed_qty}/{op.quantity} pcs</div>
// //           <div>Scheduled: <b>{fmt(op.start_time)}</b> → <b>{fmt(op.end_time)}</b> on <b>{op.machine_id}</b></div>
// //         </Box>
// //         {completed && <Alert severity="info" sx={{ mb: 2 }}>This operation is completed and cannot be moved.</Alert>}
// //         <Stack spacing={2}>
// //           <TextField select size="small" label="Machine" value={machineId} disabled={completed} onChange={(e) => setMachineId(e.target.value)}>
// //             {stageMachines.map((m) => <MenuItem key={m.machine_id} value={m.machine_id}>{machineLabel(m)}</MenuItem>)}
// //           </TextField>
// //           <TextField size="small" type="datetime-local" label="Start" value={start} disabled={completed} InputLabelProps={{ shrink: true }} onChange={(e) => setStart(e.target.value)} />
// //         </Stack>
// //         {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
// //       </DialogContent>
// //       <DialogActions>
// //         <Button onClick={onClose}>Cancel</Button>
// //         <Button variant="contained" onClick={handleUpdate} disabled={completed || saving || !machineId || !start}>Update</Button>
// //       </DialogActions>
// //     </Dialog>
// //   );
// // };

// // /**
// //  * Main Consolidated Production Schedule Page Component
// //  */
// // export default function ProductionSchedulePage() {
// //   const [apiBase] = useState(DEFAULT_API_BASE);
// //   const [data, setData] = useState(EMPTY_DATA);
// //   const [loading, setLoading] = useState(false);
// //   const [error, setError] = useState("");
// //   const [tab, setTab] = useState(0); // 0: Gantt View, 1: Operator View, 2: Table/List View
// //   const [viewMode, setViewMode] = useState("weekly");
// //   const [zoom, setZoom] = useState(1);
// //   const [selectedPo, setSelectedPo] = useState("");
// //   const [selectedOperator, setSelectedOperator] = useState("");
// //   const [editOp, setEditOp] = useState(null);

// //   // Load Schedule Data
// //   const loadSchedule = useCallback(() => {
// //     setLoading(true);
// //     setError("");
// //     axios.get(`${apiBase}/schedule/data`)
// //       .then((res) => setData({ ...EMPTY_DATA, ...res.data }))
// //       .catch((err) => setError("Could not load schedule data: " + (err.message || "Network error")))
// //       .finally(() => setLoading(false));
// //   }, [apiBase]);

// //   useEffect(() => { loadSchedule(); }, [loadSchedule]);

// //   const poColor = useMemo(() => {
// //     const map = {};
// //     data.production_orders.forEach((po, i) => { map[po.production_order] = PO_COLORS[i % PO_COLORS.length]; });
// //     return map;
// //   }, [data.production_orders]);

// //   const operators = useMemo(() => Array.from(new Set(data.operations.map((o) => o.operator_name))).filter(Boolean).sort(), [data.operations]);
// //   const filteredOps = useMemo(() => data.operations.filter((o) => !selectedPo || o.production_order === selectedPo), [data.operations, selectedPo]);

// //   return (
// //     <Box sx={{ p: 3, bgcolor: "#f7f8fb", minHeight: "100vh", fontFamily: "Roboto, sans-serif" }}>
// //       {/* Header */}
// //       <Box sx={{ bgcolor: "#fff", borderRadius: "10px", px: 2.5, py: 2, mb: 2.5, display: "flex", alignItems: "center", gap: 1.25, border: "1px solid #e3e7ee" }}>
// //         <ScheduleIcon color="primary" />
// //         <Typography sx={{ fontSize: 19, fontWeight: 600 }}>Production Schedule Dashboard</Typography>
// //         {data.generated_at && (
// //           <Typography sx={{ fontSize: 12, color: "#6b7280", ml: "auto" }}>
// //             Last Calculated: {new Date(data.generated_at).toLocaleString("en-IN")}
// //           </Typography>
// //         )}
// //       </Box>

// //       {/* Main Card */}
// //       <Box sx={{ bgcolor: "#fff", borderRadius: "10px", border: "1px solid #e3e7ee", px: 2.5, pt: 1, pb: 2.5 }}>
// //         <Tabs value={tab} onChange={(e, v) => setTab(v)} sx={{ borderBottom: "1px solid #e3e7ee", mb: 2 }}>
// //           <Tab label="Interactive Gantt View" sx={{ textTransform: "none", fontWeight: 600 }} />
// //           <Tab label="Operator Schedule View" sx={{ textTransform: "none", fontWeight: 600 }} />
// //           <Tab label="Operations List View" sx={{ textTransform: "none", fontWeight: 600 }} />
// //         </Tabs>

// //         {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
// //         {loading && <LinearProgress sx={{ mb: 2 }} />}

// //         {/* TOOLBAR */}
// //         <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 2, flexWrap: "wrap", gap: 1.5 }}>
// //           <Select size="small" value={viewMode} onChange={(e) => setViewMode(e.target.value)} sx={{ width: 120 }}>
// //             <MenuItem value="daily">Daily</MenuItem>
// //             <MenuItem value="weekly">Weekly</MenuItem>
// //             <MenuItem value="monthly">Monthly</MenuItem>
// //           </Select>

// //           <Select size="small" displayEmpty value={selectedPo} onChange={(e) => setSelectedPo(e.target.value)} sx={{ width: 220 }}>
// //             <MenuItem value=""><em>All Production Orders</em></MenuItem>
// //             {data.production_orders.map((po) => <MenuItem key={po.production_order} value={po.production_order}>{po.production_order}</MenuItem>)}
// //           </Select>

// //           <Tooltip title="Zoom In"><IconButton onClick={() => setZoom((z) => Math.min(z + 0.5, 4))}><ZoomInIcon /></IconButton></Tooltip>
// //           <Tooltip title="Zoom Out"><IconButton onClick={() => setZoom((z) => Math.max(z - 0.5, 0.5))}><ZoomOutIcon /></IconButton></Tooltip>

// //           <Button variant="contained" startIcon={<RefreshIcon />} onClick={loadSchedule} sx={{ ml: "auto", textTransform: "none" }}>
// //             Refresh
// //           </Button>
// //         </Stack>

// //         {/* TAB 0: GANTT / MACHINE VIEW */}
// //         {tab === 0 && (
// //           <Box>
// //             <Typography variant="subtitle2" sx={{ mb: 1, color: "#6b7280" }}>
// //               Machine Schedules (Click any operation bar to edit time/machine)
// //             </Typography>
// //             <Box sx={{ overflowX: "auto", border: "1px solid #e3e7ee", borderRadius: 2, p: 2, minHeight: 300 }}>
// //               {data.machines.map((m) => {
// //                 const machineOps = filteredOps.filter((o) => o.machine_id === m.machine_id);
// //                 return (
// //                   <Box key={m.machine_id} sx={{ display: "flex", alignItems: "center", py: 1, borderBottom: "1px solid #f0f2f5" }}>
// //                     <Box sx={{ width: 220, fontWeight: 600, fontSize: 13, flexShrink: 0 }}>
// //                       {machineLabel(m)}
// //                     </Box>
// //                     <Box sx={{ display: "flex", gap: 1, flexGrow: 1, overflowX: "auto", py: 0.5 }}>
// //                       {machineOps.map((op) => (
// //                         <Box
// //                           key={op.op_id}
// //                           onClick={() => setEditOp(op)}
// //                           sx={{
// //                             bgcolor: poColor[op.production_order] || "#1f6fe5",
// //                             color: "#fff", px: 1.5, py: 0.75, borderRadius: 1, fontSize: 11.5,
// //                             cursor: "pointer", whiteSpace: "nowrap", opacity: op.status === "COMPLETED" ? 0.6 : 1,
// //                             boxShadow: op.status === "IN_PROGRESS" ? "0 0 0 2px #fff, 0 0 0 4px #2563eb" : "none",
// //                             "&:hover": { filter: "brightness(1.1)" }
// //                           }}
// //                         >
// //                           <b>{op.production_order}</b> ({op.operation_no} - {op.step_name})
// //                         </Box>
// //                       ))}
// //                       {!machineOps.length && <Typography sx={{ fontSize: 12, color: "#9ca3af", fontStyle: "italic" }}>No operations scheduled</Typography>}
// //                     </Box>
// //                   </Box>
// //                 );
// //               })}
// //             </Box>
// //           </Box>
// //         )}

// //         {/* TAB 1: OPERATOR VIEW */}
// //         {tab === 1 && (
// //           <Box>
// //             <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
// //               <Typography sx={{ fontWeight: 600, fontSize: 14 }}>Select Operator:</Typography>
// //               <Select size="small" displayEmpty value={selectedOperator} onChange={(e) => setSelectedOperator(e.target.value)} sx={{ width: 220 }}>
// //                 <MenuItem value=""><em>Select Operator</em></MenuItem>
// //                 {operators.map((opName) => <MenuItem key={opName} value={opName}>{opName}</MenuItem>)}
// //               </Select>
// //             </Stack>
// //             <TableContainer component={Paper} sx={{ border: "1px solid #e3e7ee", boxShadow: "none", borderRadius: 2 }}>
// //               <Table size="small">
// //                 <TableHead sx={{ bgcolor: "#f9fafb" }}>
// //                   <TableRow>
// //                     <TableCell sx={{ fontWeight: 600 }}>Production Order</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>Part Number</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>Operation</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>Machine</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>Start Time</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>End Time</TableCell>
// //                     <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
// //                   </TableRow>
// //                 </TableHead>
// //                 <TableBody>
// //                   {data.operations.filter((o) => !selectedOperator || o.operator_name === selectedOperator).map((op) => (
// //                     <TableRow key={op.op_id}>
// //                       <TableCell>{op.production_order}</TableCell>
// //                       <TableCell>{op.part_number}</TableCell>
// //                       <TableCell>{op.operation_no} - {op.step_name}</TableCell>
// //                       <TableCell>{op.machine_id}</TableCell>
// //                       <TableCell>{fmt(op.start_time)}</TableCell>
// //                       <TableCell>{fmt(op.end_time)}</TableCell>
// //                       <TableCell sx={{ fontWeight: 600, color: op.status === "COMPLETED" ? "#16a34a" : "#2563eb" }}>{op.status}</TableCell>
// //                     </TableRow>
// //                   ))}
// //                 </TableBody>
// //               </Table>
// //             </TableContainer>
// //           </Box>
// //         )}

// //         {/* TAB 2: OPERATIONS LIST VIEW */}
// //         {tab === 2 && (
// //           <TableContainer component={Paper} sx={{ border: "1px solid #e3e7ee", boxShadow: "none", borderRadius: 2 }}>
// //             <Table size="small">
// //               <TableHead sx={{ bgcolor: "#f9fafb" }}>
// //                 <TableRow>
// //                   <TableCell sx={{ fontWeight: 600 }}>Order</TableCell>
// //                   <TableCell sx={{ fontWeight: 600 }}>Part</TableCell>
// //                   <TableCell sx={{ fontWeight: 600 }}>Step</TableCell>
// //                   <TableCell sx={{ fontWeight: 600 }}>Machine</TableCell>
// //                   <TableCell sx={{ fontWeight: 600 }}>Qty</TableCell>
// //                   <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
// //                 </TableRow>
// //               </TableHead>
// //               <TableBody>
// //                 {filteredOps.map((op) => (
// //                   <TableRow key={op.op_id} hover onClick={() => setEditOp(op)} sx={{ cursor: "pointer" }}>
// //                     <TableCell><b>{op.production_order}</b></TableCell>
// //                     <TableCell>{op.part_number}</TableCell>
// //                     <TableCell>{op.operation_no} - {op.step_name}</TableCell>
// //                     <TableCell>{op.machine_id}</TableCell>
// //                     <TableCell>{op.completed_qty}/{op.quantity}</TableCell>
// //                     <TableCell>{op.status}</TableCell>
// //                   </TableRow>
// //                 ))}
// //               </TableBody>
// //             </Table>
// //           </TableContainer>
// //         )}
// //       </Box>

// //       {/* Edit Dialog Integration */}
// //       <EditOperationDialog
// //         open={Boolean(editOp)}
// //         op={editOp}
// //         machines={data.machines}
// //         apiBase={apiBase}
// //         onClose={() => setEditOp(null)}
// //         onSaved={() => { setEditOp(null); loadSchedule(); }}
// //       />
// //     </Box>
// //   );
// // }




// import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
// import axios from "axios";
// import { useSelector } from "react-redux";
// import {
//   Alert, Autocomplete, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions,
//   DialogContent, DialogTitle, IconButton, LinearProgress, MenuItem, Paper, Popover, Select,
//   Snackbar, Stack, Switch, Tab, Table, TableBody, TableCell, TableContainer, TableHead,
//   TableRow, Tabs, TextField, Tooltip, Typography
// } from "@mui/material";
// import {
//   CalendarMonth as CalendarIcon, ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon,
//   EventNote as ScheduleIcon, FullscreenExit as FullscreenExitIcon, InfoOutlined as InfoIcon,
//   OpenInFull as FullscreenIcon, Refresh as RefreshIcon, Autorenew as UpdateIcon,
//   ZoomIn as ZoomInIcon, ZoomOut as ZoomOutIcon
// } from "@mui/icons-material";

// // ==========================================
// // 1. CONFIG & CONSTANTS[cite: 1]
// // ==========================================
// export const DEFAULT_API_BASE = "http://127.0.0.1:2000";
// export const API_ROUTES = {
//   data: "/schedule/data",
//   update: "/schedule/update",
//   config: "/schedule/config",
// };

// export const VIEW_MODES = [
//   { value: "daily", label: "Daily" },
//   { value: "weekly", label: "Weekly" },
//   { value: "monthly", label: "Monthly" },
//   { value: "yearly", label: "Yearly" },
// ];

// export const PO_PALETTE = [
//   "#1e88e5", "#f59e0b", "#10b981", "#e11d48", "#8b5cf6", "#14b8a6",
//   "#f97316", "#84cc16", "#ec4899", "#0ea5e9", "#a16207", "#6366f1",
// ];

// export const STATUS_META = {
//   COMPLETED: { label: "Completed", note: "faded bar" },
//   IN_PROGRESS: { label: "In progress", note: "bar with white outline" },
//   SCHEDULED: { label: "Scheduled", note: "solid bar" },
// };

// export const THEME = {
//   primary: "#1f6fe5",
//   info: "#1b9ae1",
//   dark: "#5b6573",
//   border: "#e3e7ee",
//   gridStrong: "#c9d0da",
//   gridSoft: "#eceff4",
//   text: "#1f2937",
//   muted: "#6b7280",
//   nowLine: "#ef4444",
//   offDay: "rgba(100,116,139,0.08)",
// };

// export const LAYOUT = {
//   labelWidth: 270,
//   headerRow1: 30,
//   headerRow2: 28,
//   rowMin: 26,
//   barPad: 4,
//   laneHeight2Line: 34,
//   laneHeight1Line: 26,
// };

// export const BASE_DAY_WIDTH = { daily: 900, weekly: 156, monthly: 46, yearly: 3.2 };
// export const ZOOM = { min: 0.5, max: 6, step: 0.5 };
// export const MAX_CUSTOM_RANGE_DAYS = 400;
// export const SNAP_MINUTES = 15;

// export const DEFAULT_CALENDAR = {
//   shift_start: 6,
//   shift_end: 20,
//   shifts: [],
//   week_off: [0],
//   holidays: [],
// };

// // ==========================================
// // 2. UTILS[cite: 1]
// // ==========================================
// export const DAY = 24 * 3600 * 1000;
// const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
// const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// const pad = (n) => String(n).padStart(2, "0");

// export const parseTime = (s) => (s ? new Date(s).getTime() : NaN);
// export const toLocalIso = (ts) => {
//   const d = new Date(ts);
//   return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
// };
// export const toDateInput = (ts) => {
//   if (!ts) return "";
//   const d = new Date(ts);
//   return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
// };
// export const fromDateInput = (s) => {
//   if (!s) return null;
//   const [y, m, d] = s.split("-").map(Number);
//   return new Date(y, m - 1, d).getTime();
// };
// export const startOfDay = (ts) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
// export const addDays = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime(); };
// export const addMonths = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth() + n, 1).getTime(); };
// const startOfWeekMon = (ts) => { const d = new Date(startOfDay(ts)); const back = (d.getDay() + 6) % 7; return addDays(d.getTime(), -back); };

// export const fmtDateTime = (ts) => new Date(ts).toLocaleString("en-US");
// export const fmtShortDate = (ts) => { const d = new Date(ts); return `${pad(d.getDate())} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
// export const fmtHours = (h) => `${(Math.round(h * 10) / 10).toFixed(1)}h`;
// const dayLabel = (ts) => { const d = new Date(ts); return `${WEEKDAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };

// export function getRange(view, anchor, customStart, customEnd) {
//   if (customStart && customEnd) {
//     const s = startOfDay(Math.min(customStart, customEnd));
//     let e = addDays(startOfDay(Math.max(customStart, customEnd)), 1);
//     if ((e - s) / DAY > MAX_CUSTOM_RANGE_DAYS) e = addDays(s, MAX_CUSTOM_RANGE_DAYS);
//     return { start: s, end: e, custom: true };
//   }
//   switch (view) {
//     case "daily": { const s = startOfDay(anchor); return { start: s, end: addDays(s, 1) }; }
//     case "weekly": { const s = startOfWeekMon(anchor); return { start: s, end: addDays(s, 7) }; }
//     case "monthly": { const s = addMonths(anchor, 0); return { start: s, end: addMonths(s, 1) }; }
//     default: { const s = addMonths(anchor, -1); return { start: s, end: addMonths(s, 12) }; }
//   }
// }

// export function shiftAnchor(view, anchor, dir, range) {
//   if (range?.custom) return anchor;
//   switch (view) {
//     case "daily": return addDays(anchor, dir);
//     case "weekly": return addDays(anchor, 7 * dir);
//     case "monthly": return addMonths(anchor, dir);
//     default: return addMonths(anchor, 12 * dir);
//   }
// }

// export function buildScale({ view, range, zoom, calendar, availableWidth }) {
//   const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
//   const windowed = view === "daily" || view === "weekly";
//   const wStart = windowed ? cal.shift_start : 0;
//   const wEnd = windowed ? cal.shift_end : 24;
//   const hours = wEnd - wStart;

//   const days = [];
//   for (let t = range.start; t < range.end; t = addDays(t, 1)) days.push(t);

//   const baseDay = BASE_DAY_WIDTH[view] || 100;
//   const fill = Math.max(0, availableWidth) / Math.max(days.length, 1);
//   const dayW = Math.max(baseDay, fill) * zoom;
//   const totalWidth = dayW * days.length;

//   const winStart = (i) => days[i] + wStart * 3600e3;
//   const winLen = hours * 3600e3;

//   const dayIndexOf = (ts) => {
//     if (ts <= days[0]) return -1;
//     let lo = 0, hi = days.length - 1;
//     while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (days[mid] <= ts) lo = mid; else hi = mid - 1; }
//     return ts >= range.end ? days.length : lo;
//   };

//   const toX = (ts) => {
//     const i = dayIndexOf(ts);
//     if (i < 0) return 0;
//     if (i >= days.length) return totalWidth;
//     const frac = Math.min(1, Math.max(0, (ts - winStart(i)) / winLen));
//     return i * dayW + frac * dayW;
//   };
//   const toTime = (x) => {
//     const cx = Math.min(totalWidth - 0.001, Math.max(0, x));
//     const i = Math.floor(cx / dayW);
//     const frac = (cx - i * dayW) / dayW;
//     return winStart(i) + frac * winLen;
//   };

//   const row1 = [], row2 = [], grid = [];
//   const groupBy = (keyFn, labelFn, target) => {
//     let startIdx = 0;
//     for (let i = 1; i <= days.length; i++) {
//       if (i === days.length || keyFn(days[i]) !== keyFn(days[startIdx])) {
//         target.push({ x: startIdx * dayW, w: (i - startIdx) * dayW, label: labelFn(days[startIdx], i - startIdx) });
//         startIdx = i;
//       }
//     }
//   };

//   if (view === "daily" || view === "weekly") {
//     days.forEach((d, i) => {
//       row1.push({ x: i * dayW, w: dayW, label: dayLabel(d) });
//       const step = view === "daily" ? Math.max(1, Math.ceil(46 / (dayW / hours))) : 6;
//       const ticks = [wStart];
//       for (let h = wStart + 1; h < wEnd; h++) if ((view === "daily" ? (h - wStart) % step === 0 : h % step === 0)) ticks.push(h);
//       ticks.forEach((h, k) => {
//         const next = k + 1 < ticks.length ? ticks[k + 1] : wEnd;
//         row2.push({ x: i * dayW + ((h - wStart) / hours) * dayW, w: ((next - h) / hours) * dayW, label: `${pad(h)}:00` });
//       });
//     });
//   } else if (view === "monthly") {
//     groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
//       (t) => `${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][new Date(t).getMonth()]} ${new Date(t).getFullYear()}`, row1);
//     days.forEach((d, i) => row2.push({ x: i * dayW, w: dayW, label: String(new Date(d).getDate()), sub: WEEKDAYS[new Date(d).getDay()][0] }));
//   } else {
//     groupBy((t) => new Date(t).getFullYear(), (t) => String(new Date(t).getFullYear()), row1);
//     groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
//       (t, n) => (n * dayW < 30 ? MONTHS[new Date(t).getMonth()][0] : MONTHS[new Date(t).getMonth()]), row2);
//   }
//   row2.forEach((c) => grid.push({ x: c.x, strong: false }));
//   row1.forEach((c) => grid.push({ x: c.x, strong: true }));

//   const holidaySet = new Set((cal.holidays || []).map((h) => h.holiday_date));
//   const offDays = [];
//   if (dayW >= 12) {
//     days.forEach((d, i) => {
//       const dt = new Date(d);
//       const key = `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`;
//       if ((cal.week_off || []).includes(dt.getDay()) || holidaySet.has(key)) offDays.push({ x: i * dayW, w: dayW });
//     });
//   }

//   return { days, dayW, totalWidth, toX, toTime, row1, row2, grid, offDays, windowed };
// }

// export function layoutRows(machines, ops, scale, barLines) {
//   const laneH = barLines === 2 ? LAYOUT.laneHeight2Line : LAYOUT.laneHeight1Line;
//   const byMachine = {};
//   ops.forEach((o) => { (byMachine[o.machine_id] = byMachine[o.machine_id] || []).push(o); });

//   let top = 0;
//   return machines.map((m) => {
//     const mine = (byMachine[m.machine_id] || []).slice().sort((a, b) => a.start - b.start);
//     const laneEnds = [];
//     const bars = mine.map((o) => {
//       const x = scale.toX(o.start);
//       const w = Math.max(scale.toX(o.end) - x, 3);
//       let lane = laneEnds.findIndex((end) => end <= o.start);
//       if (lane < 0) { lane = laneEnds.length; laneEnds.push(0); }
//       laneEnds[lane] = o.end;
//       return { op: o, x, w, lane };
//     });
//     const lanes = Math.max(laneEnds.length, 1);
//     const height = bars.length ? lanes * laneH + 2 * LAYOUT.barPad : LAYOUT.rowMin;
//     const row = { machine: m, bars, top, height, laneH };
//     top += height;
//     return row;
//   });
// }

// export const machineLabel = (m) => (m.machine_name && m.machine_name !== m.machine_id ? `${m.machine_id} - ${m.machine_name}` : m.machine_id);

// export function buildColorMap(ops) {
//   const pos = Array.from(new Set(ops.map((o) => o.production_order))).sort();
//   const map = {};
//   pos.forEach((po, i) => { map[po] = PO_PALETTE[i % PO_PALETTE.length]; });
//   return map;
// }

// export function normaliseOps(rawOps, mode) {
//   return rawOps
//     .map((o) => {
//       const planned = mode === "planned";
//       const start = parseTime(planned ? o.planned_start : o.start_time);
//       const end = parseTime(planned ? o.planned_end : o.end_time);
//       return {
//         ...o,
//         machine_id: planned ? o.planned_machine_id : o.machine_id,
//         start, end,
//         pdc: parseTime(o.planned_end),
//       };
//     })
//     .filter((o) => Number.isFinite(o.start) && Number.isFinite(o.end));
// }

// export const overlapsRange = (o, range) => o.end > range.start && o.start < range.end;

// // ==========================================
// // 3. HOOKS[cite: 1]
// // ==========================================
// export function useGanttControls(initialView = "weekly") {
//   const [view, setView] = useState(initialView);
//   const [anchor, setAnchor] = useState(() => Date.now());
//   const [customStart, setCustomStart] = useState(null);
//   const [customEnd, setCustomEnd] = useState(null);
//   const [zoom, setZoom] = useState(1);
//   const [isFullscreen, setIsFullscreen] = useState(false);
//   const fsRef = useRef(null);

//   const range = useMemo(() => getRange(view, anchor, customStart, customEnd), [view, anchor, customStart, customEnd]);

//   const changeView = useCallback((v) => { setView(v); setCustomStart(null); setCustomEnd(null); setZoom(1); }, []);
//   const navigate = useCallback((dir) => setAnchor((a) => shiftAnchor(view, a, dir, range)), [view, range]);
//   const setDateRange = useCallback((s, e) => { setCustomStart(s); setCustomEnd(e); }, []);
//   const goTo = useCallback((ts) => setAnchor(ts), []);
//   const zoomIn = useCallback(() => setZoom((z) => Math.min(ZOOM.max, z + ZOOM.step)), []);
//   const zoomOut = useCallback(() => setZoom((z) => Math.max(ZOOM.min, z - ZOOM.step)), []);
//   const resetControls = useCallback(() => { setCustomStart(null); setCustomEnd(null); setZoom(1); setAnchor(Date.now()); }, []);

//   useEffect(() => {
//     const onChange = () => setIsFullscreen(document.fullscreenElement === fsRef.current);
//     document.addEventListener("fullscreenchange", onChange);
//     return () => document.removeEventListener("fullscreenchange", onChange);
//   }, []);

//   const toggleFullscreen = useCallback(() => {
//     const el = fsRef.current;
//     if (!el) return;
//     if (document.fullscreenElement) document.exitFullscreen?.();
//     else if (el.requestFullscreen) el.requestFullscreen().catch(() => setIsFullscreen((f) => !f));
//     else setIsFullscreen((f) => !f);
//   }, []);

//   return {
//     view, changeView, range, navigate, goTo, customStart, customEnd, setDateRange,
//     zoom, zoomIn, zoomOut, resetControls, fsRef, isFullscreen, toggleFullscreen,
//   };
// }

// export function useScheduleData() {
//   const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);
//   const apiBase = useMemo(
//     () => configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP || DEFAULT_API_BASE,
//     [configDetails]
//   );

//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   const load = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const res = await axios.get(apiBase + API_ROUTES.data);
//       setData(res.data);
//     } catch (e) {
//       setError("Unable to load the production schedule. Check the server connection.");
//     } finally {
//       setLoading(false);
//     }
//   }, [apiBase]);

//   useEffect(() => { load(); }, [load]);

//   const saveChanges = useCallback(
//     async (changes) => { await axios.post(apiBase + API_ROUTES.update, { changes }); },
//     [apiBase]
//   );

//   return { data, loading, error, refresh: load, saveChanges, apiBase };
// }

// // ==========================================
// // 4. COMPONENTS & CONTROLS[cite: 1]
// // ==========================================
// const fieldSx = {
//   "& .MuiOutlinedInput-root": { borderRadius: "6px", fontSize: 13.5, bgcolor: "#fff", minHeight: 36 },
//   "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border },
// };

// export const ViewSelect = ({ value, onChange }) => (
//   <Select size="small" value={value} onChange={(e) => onChange(e.target.value)}
//     sx={{ width: 118, height: 36, fontSize: 13.5, borderRadius: "6px", bgcolor: "#fff", "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border } }}>
//     {VIEW_MODES.map((v) => <MenuItem key={v.value} value={v.value} sx={{ fontSize: 13.5 }}>{v.label}</MenuItem>)}
//   </Select>
// );

// export const DateRangeField = ({ start, end, onChange }) => {
//   const [anchorEl, setAnchorEl] = useState(null);
//   const [s, setS] = useState("");
//   const [e, setE] = useState("");
//   const open = (ev) => { setS(toDateInput(start)); setE(toDateInput(end)); setAnchorEl(ev.currentTarget.closest("[data-daterange]")); };
//   const text = start && end ? `${fmtShortDate(start)} – ${fmtShortDate(end)}` : "";

//   return (
//     <>
//       <Box data-daterange sx={{ display: "flex", width: 262 }}>
//         <TextField size="small" placeholder="Start Date – End Date" value={text} onClick={open} fullWidth
//           InputProps={{ readOnly: true, sx: { cursor: "pointer", borderTopRightRadius: 0, borderBottomRightRadius: 0 } }}
//           sx={{ ...fieldSx, "& input": { cursor: "pointer" } }} />
//         <IconButton aria-label="Pick dates" onClick={open}
//           sx={{ width: 38, height: 36, borderRadius: "0 6px 6px 0", bgcolor: THEME.primary, color: "#fff", "&:hover": { bgcolor: "#1a5fc7" } }}>
//           <CalendarIcon fontSize="small" />
//         </IconButton>
//       </Box>
//       <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}
//         anchorOrigin={{ vertical: "bottom", horizontal: "left" }}>
//         <Stack spacing={1.5} sx={{ p: 2, width: 260 }}>
//           <TextField size="small" type="date" label="Start Date" value={s} onChange={(ev) => setS(ev.target.value)} InputLabelProps={{ shrink: true }} />
//           <TextField size="small" type="date" label="End Date" value={e} onChange={(ev) => setE(ev.target.value)} InputLabelProps={{ shrink: true }} />
//           <Stack direction="row" spacing={1} justifyContent="flex-end">
//             <Button size="small" onClick={() => { onChange(null, null); setAnchorEl(null); }}>Clear</Button>
//             <Button size="small" variant="contained" disabled={!s || !e}
//               onClick={() => { onChange(fromDateInput(s), fromDateInput(e)); setAnchorEl(null); }}>Apply</Button>
//           </Stack>
//         </Stack>
//       </Popover>
//     </>
//   );
// };

// export const MultiSelect = ({ placeholder, options, value, onChange, width = 200, getLabel = (o) => o }) => (
//   <Autocomplete multiple size="small" limitTags={1} disableCloseOnSelect options={options} value={value}
//     getOptionLabel={getLabel} onChange={(_, v) => onChange(v)} sx={{ width, ...fieldSx }}
//     ChipProps={{ size: "small", sx: { maxWidth: 96, fontSize: 12 } }}
//     renderInput={(params) => <TextField {...params} placeholder={value.length ? "" : placeholder} />} />
// );

// export const SingleSelect = ({ placeholder, options, value, onChange, width = 200 }) => (
//   <Autocomplete size="small" options={options} value={value} onChange={(_, v) => onChange(v)}
//     sx={{ width, ...fieldSx }} renderInput={(params) => <TextField {...params} placeholder={placeholder} />} />
// );

// const toolSx = { width: 34, height: 34, color: THEME.primary, "&:hover": { bgcolor: "#eef3fb" } };

// export const ChartTools = ({ zoomIn, zoomOut, isFullscreen, toggleFullscreen, onInfo }) => (
//   <Stack direction="row" spacing={0.5} alignItems="center">
//     <Tooltip title="Zoom in"><IconButton aria-label="Zoom in" onClick={zoomIn} sx={toolSx}><ZoomInIcon fontSize="small" /></IconButton></Tooltip>
//     <Tooltip title="Zoom out"><IconButton aria-label="Zoom out" onClick={zoomOut} sx={toolSx}><ZoomOutIcon fontSize="small" /></IconButton></Tooltip>
//     <Tooltip title={isFullscreen ? "Exit full screen" : "Full screen"}>
//       <IconButton aria-label="Full screen" onClick={toggleFullscreen} sx={toolSx}>
//         {isFullscreen ? <FullscreenExitIcon fontSize="small" /> : <FullscreenIcon fontSize="small" />}
//       </IconButton>
//     </Tooltip>
//     {onInfo && (
//       <Tooltip title="How to use">
//         <IconButton aria-label="Info" onClick={onInfo} sx={{ width: 36, height: 36, borderRadius: "6px", bgcolor: THEME.info, color: "#fff", "&:hover": { bgcolor: "#1488c9" } }}>
//           <InfoIcon fontSize="small" />
//         </IconButton>
//       </Tooltip>
//     )}
//   </Stack>
// );

// export const InfoPopover = ({ anchorEl, onClose, editable }) => (
//   <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onClose} anchorOrigin={{ vertical: "bottom", horizontal: "right" }} transformOrigin={{ vertical: "top", horizontal: "right" }}>
//     <Box sx={{ p: 2, width: 330, fontSize: 13, color: THEME.text }}>
//       <Typography fontWeight={700} fontSize={14} mb={1}>How to read this chart</Typography>
//       <Box component="ul" sx={{ m: 0, pl: 2.25, "& li": { mb: 0.5 } }}>
//         <li>Each row is a machine / manual work centre; each bar is one operation of a production order.</li>
//         <li>Hover a bar for part number, quantity, start, end and the PDC (planned date of completion).</li>
//         <li>The red line is the current time. Shaded columns are Sundays / public holidays.</li>
//         <li>Daily &amp; Weekly views show only the working hours of each shift; Monthly &amp; Yearly show full days.</li>
//         <li>Use the &lt; &gt; arrows to move period, and the zoom buttons to stretch the timeline.</li>
//         {editable && <li><b>Drag a bar</b> to a new time or machine row to re-schedule it, then press <b>Update</b> to save.</li>}
//       </Box>
//       <Typography fontWeight={700} fontSize={13} mt={1.5} mb={0.75}>Bar status</Typography>
//       {Object.entries(STATUS_META).map(([k, v]) => (
//         <Box key={k} sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
//           <Box sx={{ width: 26, height: 12, borderRadius: "2px", bgcolor: THEME.primary, opacity: k === "COMPLETED" ? 0.55 : 1, boxShadow: k === "IN_PROGRESS" ? "inset 0 0 0 1.5px #fff, 0 0 0 1px " + THEME.primary : "none" }} />
//           <span>{v.label} <Box component="span" sx={{ color: THEME.muted }}>({v.note})</Box></span>
//         </Box>
//       ))}
//     </Box>
//   </Popover>
// );

// export const RefreshButton = ({ onClick, dark, loading }) => (
//   <Button variant="contained" startIcon={<RefreshIcon />} onClick={onClick} disabled={loading}
//     sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: dark ? THEME.dark : THEME.primary, "&:hover": { bgcolor: dark ? "#4a5361" : "#1a5fc7", boxShadow: "none" } }}>
//     Refresh
//   </Button>
// );

// export const UpdateButton = ({ onClick, count, saving }) => (
//   <Button variant="contained" startIcon={<UpdateIcon />} onClick={onClick} disabled={saving || !count}
//     sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.primary }}>
//     Update{count ? ` (${count})` : ""}
//   </Button>
// );

// export const ClearFiltersButton = ({ onClick }) => (
//   <Button variant="contained" onClick={onClick}
//     sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.dark, "&:hover": { bgcolor: "#4a5361", boxShadow: "none" } }}>
//     Clear Filters
//   </Button>
// );

// export const ProductionOrdersLegend = ({ colorMap, title = "Production Orders" }) => (
//   <Box sx={{ mt: 2.5, pt: 1.5, borderTop: `1px solid ${THEME.border}` }}>
//     <Typography sx={{ fontSize: 13, fontWeight: 600, mb: 1, color: THEME.text }}>{title}</Typography>
//     <Box sx={{ display: "flex", flexWrap: "wrap", gap: "6px 18px" }}>
//       {Object.entries(colorMap).map(([po, color]) => (
//         <Box key={po} sx={{ display: "flex", alignItems: "center", gap: 0.75, fontSize: 12, color: THEME.muted }}>
//           <Box sx={{ width: 13, height: 13, borderRadius: "3px", bgcolor: color }} />{po}
//         </Box>
//       ))}
//     </Box>
//   </Box>
// );

// // ==========================================
// // 5. DIALOG & TIMELINE COMPONENTS[cite: 1]
// // ==========================================
// export const EditOperationDialog = ({ open, op, machines, apiBase, onClose, onSaved }) => {
//   const [machineId, setMachineId] = useState("");
//   const [start, setStart] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [rejected, setRejected] = useState([]);
//   const [error, setError] = useState("");

//   useEffect(() => {
//     if (op) {
//       setMachineId(op.machine_id);
//       setStart((op.start_time || "").slice(0, 16));
//       setRejected([]);
//       setError("");
//     }
//   }, [op]);

//   if (!op) return null;

//   const stageMachines = machines.filter((m) => m.stage_id === op.flow_step_id);
//   const completed = op.status === "COMPLETED";

//   const handleUpdate = () => {
//     setSaving(true);
//     setRejected([]);
//     setError("");
//     const change = { op_id: op.op_id, machine_id: machineId, start_time: start + ":00" };
//     axios.post(apiBase + "/schedule/update", { changes: [change] })
//       .then((res) => {
//         if (res.data.updated > 0) onSaved();
//         else setRejected(res.data.rejected || []);
//       })
//       .catch((err) => setError("Could not save: " + (err.response?.data?.detail || err.message)))
//       .finally(() => setSaving(false));
//   };

//   return (
//     <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
//       <DialogTitle sx={{ fontSize: 17 }}>
//         {op.production_order} · {op.operation_no} - {op.step_name}
//       </DialogTitle>
//       <DialogContent>
//         <Box sx={{ fontSize: 13, color: "#4b5563", mb: 2, lineHeight: 1.7, fontFamily: (theme) => theme.typography.fontFamily }}>
//           <div>Part: <b>{op.part_number}</b> · {op.process_mode} · {op.completed_qty}/{op.quantity} pcs · {op.status}</div>
//           <div>Scheduled: <b>{fmtDateTime(op.start)}</b> → <b>{fmtDateTime(op.end)}</b> on <b>{op.machine_id}</b></div>
//           <div>PDC (planned end): <b>{fmtDateTime(op.pdc)}</b></div>
//           {op.waiting_reason && <div>Waiting for: <b>{op.waiting_reason}</b></div>}
//         </Box>

//         {completed && <Alert severity="info" sx={{ mb: 2 }}>This operation is completed and cannot be moved.</Alert>}

//         <Stack spacing={2}>
//           <TextField select size="small" label="Machine" value={machineId} disabled={completed}
//             onChange={(e) => setMachineId(e.target.value)}>
//             {stageMachines.map((m) => (
//               <MenuItem key={m.machine_id} value={m.machine_id}>
//                 {m.machine_id}{m.machine_name && m.machine_name !== m.machine_id ? ` - ${m.machine_name}` : ""}
//               </MenuItem>
//             ))}
//           </TextField>
//           <TextField size="small" type="datetime-local" label="Start" value={start} disabled={completed}
//             InputLabelProps={{ shrink: true }} onChange={(e) => setStart(e.target.value)} />
//         </Stack>

//         {rejected.map((r, i) => (
//           <Alert key={i} severity="warning" sx={{ mt: 2 }}>Not saved: {r.reason}</Alert>
//         ))}
//         {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
//       </DialogContent>
//       <DialogActions>
//         <Button onClick={onClose}>Cancel</Button>
//         <Button variant="contained" onClick={handleUpdate} disabled={completed || saving || !machineId || !start}
//           startIcon={saving ? <CircularProgress size={16} color="inherit" /> : null}>
//           Update
//         </Button>
//       </DialogActions>
//     </Dialog>
//   );
// };

// const navBtnSx = {
//   position: "absolute", top: 4, zIndex: 8, width: 26, height: 26, bgcolor: "#fff",
//   border: `1px solid ${THEME.border}`, borderRadius: "6px", color: THEME.primary,
//   "&:hover": { bgcolor: "#f3f7ff" },
// };

// const TooltipRow = ({ k, v }) => (
//   <Box sx={{ display: "flex", gap: 0.5, lineHeight: 1.45 }}>
//     <Box component="span" sx={{ color: THEME.muted, whiteSpace: "nowrap" }}>{k}:</Box>
//     <Box component="span" sx={{ color: THEME.text, fontWeight: 500 }}>{v}</Box>
//   </Box>
// );

// export const GanttTimeline = ({
//   machines, ops, view, range, zoom, calendar, colorMap, barLines = 2,
//   emptySuffix = "", editable = false, showStatus = true, pendingIds, onChangeOp, onNavigate, fsRef, isFullscreen,
// }) => {
//   const scrollRef = useRef(null);
//   const bodyRef = useRef(null);
//   const [width, setWidth] = useState(0);
//   const [tip, setTip] = useState(null);
//   const [drag, setDrag] = useState(null);
//   const [now, setNow] = useState(Date.now());

//   useEffect(() => {
//     const el = scrollRef.current;
//     if (!el) return undefined;
//     const measure = () => setWidth(Math.max(0, el.clientWidth - LAYOUT.labelWidth));
//     measure();
//     const ro = new ResizeObserver(measure);
//     ro.observe(el);
//     return () => ro.disconnect();
//   }, []);

//   useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);

//   const scale = useMemo(
//     () => buildScale({ view, range, zoom, calendar, availableWidth: width }),
//     [view, range, zoom, calendar, width]
//   );

//   const visibleOps = useMemo(() => (drag ? ops.filter((o) => o.op_id !== drag.op.op_id) : ops), [ops, drag]);
//   const rows = useMemo(() => layoutRows(machines, visibleOps, scale, barLines), [machines, visibleOps, scale, barLines]);
//   const rowsRef = useRef(rows); rowsRef.current = rows;
//   const scaleRef = useRef(scale); scaleRef.current = scale;

//   const bodyHeight = rows.reduce((s, r) => s + r.height, 0);
//   const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
//   const nowD = new Date(now);
//   const nowHour = nowD.getHours() + nowD.getMinutes() / 60;
//   const nowVisible = now >= range.start && now < range.end && (!scale.windowed || (nowHour >= cal.shift_start && nowHour < cal.shift_end));
//   const nowX = nowVisible ? scale.toX(now) : null;
//   const headerH = LAYOUT.headerRow1 + LAYOUT.headerRow2;

//   const startDrag = useCallback((e, bar) => {
//     if (!editable || e.button !== 0) return;
//     e.preventDefault();
//     setTip(null);
//     const startX = e.clientX;
//     const op = bar.op;
//     const duration = op.end - op.start;
//     const snap = SNAP_MINUTES * 60000;
//     let moved = false;
//     let last = null;

//     const compute = (ev) => {
//       const sc = scaleRef.current;
//       const dx = ev.clientX - startX;
//       const yRel = ev.clientY - bodyRef.current.getBoundingClientRect().top;
//       const target = rowsRef.current.find((r) => yRel >= r.top && yRel < r.top + r.height)
//         || rowsRef.current.find((r) => r.machine.machine_id === op.machine_id);
//       const start = Math.round(sc.toTime(bar.x + dx) / snap) * snap;
//       const end = start + duration;
//       const x = sc.toX(start);
//       return {
//         op, start, end, machine_id: target.machine.machine_id,
//         ghost: { x, w: Math.max(sc.toX(end) - x, 3), top: target.top + LAYOUT.barPad, h: bar.h },
//       };
//     };
//     const onMove = (ev) => {
//       if (Math.abs(ev.clientX - startX) > 3 || moved) moved = true;
//       if (!moved) return;
//       last = compute(ev);
//       setDrag(last);
//     };
//     const onUp = () => {
//       window.removeEventListener("pointermove", onMove);
//       window.removeEventListener("pointerup", onUp);
//       setDrag(null);
//       if (moved && last && (last.start !== op.start || last.machine_id !== op.machine_id)) {
//         onChangeOp?.(op, { machine_id: last.machine_id, start_time: toLocalIso(last.start), end_time: toLocalIso(last.end) });
//       }
//     };
//     window.addEventListener("pointermove", onMove);
//     window.addEventListener("pointerup", onUp);
//   }, [editable, onChangeOp]);

//   const showTip = (e, op) => { if (!drag) setTip({ x: e.clientX, y: e.clientY, op }); };
//   const machineById = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, m])), [machines]);

//   const renderTip = () => {
//     if (!tip) return null;
//     const { op } = tip;
//     const m = machineById[op.machine_id];
//     const qtyWord = op.status === "COMPLETED" ? "Completed" : op.status === "IN_PROGRESS" ? "Process" : "Scheduled";
//     const vw = typeof window !== "undefined" ? window.innerWidth : 1400;
//     const left = tip.x + 300 > vw ? tip.x - 290 : tip.x + 14;
//     return (
//       <Box sx={{
//         position: "fixed", left, top: tip.y + 14, zIndex: 3000, bgcolor: "#fff", border: `1px solid ${THEME.border}`,
//         borderRadius: "6px", boxShadow: "0 4px 18px rgba(15,23,42,0.18)", px: 1.25, py: 0.75, fontSize: 12.5,
//         pointerEvents: "none", minWidth: 250,
//       }}>
//         <TooltipRow k="Part Number" v={op.part_number} />
//         <TooltipRow k="Machine" v={m ? machineLabel(m) : op.machine_id} />
//         <TooltipRow k="Production Order" v={op.production_order} />
//         <TooltipRow k="Operation" v={`${op.operation_no} - ${op.operation_name}`} />
//         <TooltipRow k="Quantity" v={`${qtyWord}(${op.completed_qty}/${op.quantity}pcs)`} />
//         <TooltipRow k="Mode" v={`${op.process_mode === "BATCH" ? "Batch" : "Series"}${m?.resource_type === "MANUAL" ? " (Manual)" : ""}`} />
//         <TooltipRow k="Operator" v={op.operator_name} />
//         <TooltipRow k="Start" v={fmtDateTime(op.start)} />
//         <TooltipRow k="End" v={fmtDateTime(op.end)} />
//         <TooltipRow k="PDC of Operation" v={fmtDateTime(op.pdc)} />
//         {pendingIds?.has(op.op_id) && <Box sx={{ mt: 0.5, color: "#b45309", fontWeight: 600 }}>Modified - press Update to save</Box>}
//       </Box>
//     );
//   };

//   const renderBar = (bar, row) => {
//     const { op, x, w, lane } = bar;
//     const color = colorMap[op.production_order] || THEME.primary;
//     const h = row.laneH - 4;
//     const pending = pendingIds?.has(op.op_id);
//     const fadedOut = showStatus && op.status === "COMPLETED";
//     return (
//       <Box
//         key={op.op_id}
//         onPointerDown={(e) => startDrag(e, { ...bar, h })}
//         onMouseEnter={(e) => showTip(e, op)}
//         onMouseMove={(e) => showTip(e, op)}
//         onMouseLeave={() => setTip(null)}
//         sx={{
//           position: "absolute", left: x, top: LAYOUT.barPad + lane * row.laneH, width: w, height: h, zIndex: 1,
//           bgcolor: color, color: "#fff", borderRadius: "3px", px: w > 14 ? 0.5 : 0, overflow: "hidden",
//           fontSize: 11, lineHeight: 1.25, display: "flex", flexDirection: "column", justifyContent: "center",
//           opacity: fadedOut ? 0.55 : 1, cursor: editable ? "grab" : "default", userSelect: "none",
//           boxShadow: showStatus && op.status === "IN_PROGRESS" ? `inset 0 0 0 1.5px #fff, 0 0 0 1px ${color}` : "none",
//           outline: pending ? "2px dashed #f59e0b" : "none", outlineOffset: 1,
//           borderRight: "1px solid rgba(255,255,255,0.55)",
//           "&:hover": { filter: "brightness(1.08)" },
//         }}
//       >
//         {w > 18 && (
//           <>
//             <Box sx={{ fontWeight: 600, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>{op.production_order}</Box>
//             {barLines === 2 && (
//               <Box sx={{ whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden", opacity: 0.95 }}>
//                 {op.part_number} - {op.operation_name}
//               </Box>
//             )}
//           </>
//         )}
//       </Box>
//     );
//   };

//   const cssFullscreen = isFullscreen && typeof document !== "undefined" && !document.fullscreenElement;

//   return (
//     <Box
//       ref={fsRef}
//       sx={{
//         position: cssFullscreen ? "fixed" : "relative", inset: cssFullscreen ? 0 : "auto", zIndex: cssFullscreen ? 1400 : "auto",
//         bgcolor: "#fff", border: `1px solid ${THEME.border}`, borderRadius: "10px", p: isFullscreen ? 1.5 : 0.5,
//         boxSizing: "border-box", height: isFullscreen ? "100%" : "auto",
//       }}
//     >
//       <Box sx={{ position: "relative" }}>
//         <IconButton aria-label="Previous period" onClick={() => onNavigate(-1)} sx={{ ...navBtnSx, left: 8 }}><ChevronLeftIcon fontSize="small" /></IconButton>
//         <IconButton aria-label="Next period" onClick={() => onNavigate(1)} sx={{ ...navBtnSx, right: 10 }}><ChevronRightIcon fontSize="small" /></IconButton>

//         <Box ref={scrollRef} sx={{ overflow: "auto", maxHeight: isFullscreen ? "calc(100vh - 36px)" : 560 }}>
//           <Box sx={{ width: LAYOUT.labelWidth + scale.totalWidth, minWidth: "100%", position: "relative", isolation: "isolate" }}>
//             <Box sx={{ position: "sticky", top: 0, zIndex: 6, display: "flex", bgcolor: "#fff", height: headerH, borderBottom: `1px solid ${THEME.gridStrong}` }}>
//               <Box sx={{ position: "sticky", left: 0, zIndex: 7, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff", borderRight: `1px solid ${THEME.gridStrong}` }} />
//               <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
//                 {scale.row1.map((c, i) => (
//                   <Box key={`r1-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: 0, height: LAYOUT.headerRow1, borderLeft: `1px solid ${THEME.gridStrong}`, px: 0.5, display: "flex", alignItems: "center", fontSize: 13, fontWeight: 500, color: THEME.text, whiteSpace: "nowrap", overflow: "hidden" }}>
//                     {c.label}
//                   </Box>
//                 ))}
//                 {scale.row2.map((c, i) => (
//                   <Box key={`r2-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: LAYOUT.headerRow1, height: LAYOUT.headerRow2, borderLeft: `1px solid ${THEME.gridSoft}`, px: 0.5, display: "flex", alignItems: "center", gap: 0.4, fontSize: 12, color: THEME.muted, whiteSpace: "nowrap", overflow: "hidden" }}>
//                     {c.label}{c.sub && c.w > 30 ? <Box component="span" sx={{ fontSize: 9, opacity: 0.7 }}>{c.sub}</Box> : null}
//                   </Box>
//                 ))}
//               </Box>
//             </Box>

//             <Box ref={bodyRef} sx={{ position: "relative", minHeight: 160 }}>
//               <Box sx={{ position: "absolute", left: LAYOUT.labelWidth, top: 0, width: scale.totalWidth, height: Math.max(bodyHeight, 160), zIndex: 0, pointerEvents: "none" }}>
//                 {scale.offDays.map((d, i) => <Box key={`off-${i}`} sx={{ position: "absolute", left: d.x, width: d.w, top: 0, bottom: 0, bgcolor: THEME.offDay }} />)}
//                 {scale.grid.map((g, i) => <Box key={`g-${i}`} sx={{ position: "absolute", left: g.x, top: 0, bottom: 0, width: "1px", bgcolor: g.strong ? THEME.gridStrong : THEME.gridSoft }} />)}
//               </Box>
//               {nowX !== null && (
//                 <Box sx={{ position: "absolute", left: LAYOUT.labelWidth + nowX, top: 0, height: Math.max(bodyHeight, 160), width: "2px", bgcolor: THEME.nowLine, zIndex: 2, pointerEvents: "none" }} />
//               )}

//               {rows.length === 0 && (
//                 <Typography sx={{ position: "sticky", left: LAYOUT.labelWidth, p: 3, color: THEME.muted, fontSize: 13 }}>No machines to display.</Typography>
//               )}

//               {rows.map((row) => (
//                 <Box key={row.machine.machine_id} sx={{ display: "flex", height: row.height, borderBottom: `1px solid ${THEME.gridSoft}` }}>
//                   <Box title={machineLabel(row.machine)} sx={{
//                     position: "sticky", left: 0, zIndex: 3, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff",
//                     borderRight: `1px solid ${THEME.gridStrong}`, px: 1, pt: row.bars.length ? 0.6 : 0, display: "flex",
//                     alignItems: row.bars.length ? "flex-start" : "center", fontSize: 11.5, color: THEME.text,
//                     fontWeight: row.bars.length ? 600 : 400, fontStyle: row.machine.resource_type === "MANUAL" ? "italic" : "normal",
//                     whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
//                   }}>
//                     {machineLabel(row.machine)}{!row.bars.length && emptySuffix ? ` ${emptySuffix}` : ""}
//                   </Box>
//                   <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
//                     {row.bars.map((bar) => renderBar(bar, row))}
//                   </Box>
//                 </Box>
//               ))}

//               {drag && (
//                 <Box sx={{
//                   position: "absolute", left: LAYOUT.labelWidth + drag.ghost.x, top: drag.ghost.top, width: drag.ghost.w, height: drag.ghost.h,
//                   bgcolor: colorMap[drag.op.production_order] || THEME.primary, opacity: 0.85, borderRadius: "3px", zIndex: 5,
//                   outline: "2px dashed #f59e0b", pointerEvents: "none", color: "#fff", fontSize: 11, px: 0.5, display: "flex", alignItems: "center",
//                   whiteSpace: "nowrap", overflow: "hidden",
//                 }}>
//                   {drag.op.production_order} · {new Date(drag.start).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
//                 </Box>
//               )}
//             </Box>
//           </Box>
//         </Box>
//       </Box>
//       {renderTip()}
//     </Box>
//   );
// };

// // ==========================================
// // 6. TABS / SCREENS[cite: 1]
// // ==========================================
// export const MachineSchedule = ({ data, loading, onRefresh, saveChanges }) => {
//   const ctl = useGanttControls("weekly");
//   const [machineSel, setMachineSel] = useState([]);
//   const [partSel, setPartSel] = useState([]);
//   const [poSel, setPoSel] = useState([]);
//   const [infoAnchor, setInfoAnchor] = useState(null);
//   const [edits, setEdits] = useState({});
//   const [saving, setSaving] = useState(false);
//   const [toast, setToast] = useState(null);

//   const machines = data?.machines || [];
//   const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
//   const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);

//   const ops = useMemo(() => baseOps.map((o) => {
//     const e = edits[o.op_id];
//     return e ? { ...o, machine_id: e.machine_id, start: parseTime(e.start_time), end: parseTime(e.end_time) } : o;
//   }), [baseOps, edits]);

//   const filteredOps = useMemo(() => ops.filter((o) =>
//     (!machineSel.length || machineSel.includes(o.machine_id)) &&
//     (!partSel.length || partSel.includes(o.part_number)) &&
//     (!poSel.length || poSel.includes(o.production_order)) &&
//     overlapsRange(o, ctl.range)), [ops, machineSel, partSel, poSel, ctl.range]);

//   const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);
//   const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);
//   const partOptions = useMemo(() => Array.from(new Set(baseOps.map((o) => o.part_number))).sort(), [baseOps]);
//   const poOptions = useMemo(() => Object.keys(colorMap), [colorMap]);
//   const pendingIds = useMemo(() => new Set(Object.keys(edits)), [edits]);

//   const onChangeOp = useCallback((op, patch) => setEdits((prev) => ({ ...prev, [op.op_id]: patch })), []);

//   const handleUpdate = async () => {
//     setSaving(true);
//     try {
//       await saveChanges(Object.entries(edits).map(([op_id, p]) => ({ op_id, ...p })));
//       setEdits({});
//       await onRefresh();
//       setToast({ severity: "success", msg: "Schedule updated." });
//     } catch (e) {
//       setToast({ severity: "error", msg: "Could not save the schedule changes." });
//     } finally { setSaving(false); }
//   };

//   const pickOrders = (list) => {
//     setPoSel(list);
//     const mine = baseOps.filter((o) => list.includes(o.production_order));
//     if (mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start)));
//   };

//   const handleRefresh = async () => { setEdits({}); await onRefresh(); };

//   return (
//     <Box>
//       <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 1.25 }}>
//         <ViewSelect value={ctl.view} onChange={ctl.changeView} />
//         <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
//         <MultiSelect placeholder="Select Machines" options={machines.map((m) => m.machine_id)} value={machineSel}
//           onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
//         <MultiSelect placeholder="Select Part Number" options={partOptions} value={partSel} onChange={setPartSel} width={210} />
//         <MultiSelect placeholder="Select Production Orders" options={poOptions} value={poSel} onChange={pickOrders} width={230} />
//         <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen}
//           toggleFullscreen={ctl.toggleFullscreen} onInfo={(e) => setInfoAnchor(e.currentTarget)} />
//       </Stack>
//       <Stack direction="row" spacing={1.25} sx={{ mb: 2 }}>
//         <UpdateButton onClick={handleUpdate} count={pendingIds.size} saving={saving} />
//         <RefreshButton onClick={handleRefresh} dark loading={loading} />
//       </Stack>

//       <GanttTimeline
//         machines={rows} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
//         calendar={data?.calendar} colorMap={colorMap} barLines={2} editable pendingIds={pendingIds}
//         onChangeOp={onChangeOp} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
//       />
//       <ProductionOrdersLegend colorMap={colorMap} title="Production Orders" />

//       <InfoPopover anchorEl={infoAnchor} onClose={() => setInfoAnchor(null)} editable />
//       <Snackbar open={Boolean(toast)} autoHideDuration={3500} onClose={() => setToast(null)} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
//         {toast ? <Alert severity={toast.severity} variant="filled" onClose={() => setToast(null)}>{toast.msg}</Alert> : undefined}
//       </Snackbar>
//     </Box>
//   );
// };

// const Stat = ({ value, label, color }) => (
//   <Box sx={{ mr: 5 }}>
//     <Typography sx={{ fontSize: 26, lineHeight: 1.1, fontWeight: 400, color }}>{value}</Typography>
//     <Typography sx={{ fontSize: 12, color: "#6b7280", mt: 0.25 }}>{label}</Typography>
//   </Box>
// );

// export const PlannedSchedule = ({ data, loading, onRefresh }) => {
//   const ctl = useGanttControls("weekly");
//   const [machineSel, setMachineSel] = useState([]);
//   const [poSel, setPoSel] = useState(null);

//   const machines = useMemo(
//     () => (data?.machines || []).slice().sort((a, b) => a.work_centre.localeCompare(b.work_centre) || a.machine_name.localeCompare(b.machine_name)),
//     [data]
//   );
//   const baseOps = useMemo(() => normaliseOps(data?.operations || [], "planned"), [data]);
//   const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);

//   const selectedOps = useMemo(() => baseOps.filter((o) =>
//     (!machineSel.length || machineSel.includes(o.machine_id)) && (!poSel || o.production_order === poSel)), [baseOps, machineSel, poSel]);
//   const shownOps = useMemo(() => selectedOps.filter((o) => overlapsRange(o, ctl.range)), [selectedOps, ctl.range]);

//   const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);
//   const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);

//   const stats = useMemo(() => ({
//     operations: selectedOps.length,
//     machines: new Set(selectedOps.map((o) => o.machine_id)).size,
//     orders: new Set(selectedOps.map((o) => o.production_order)).size,
//     hours: selectedOps.reduce((s, o) => s + (o.duration_hours ?? (o.end - o.start) / 3600e3), 0),
//   }), [selectedOps]);

//   const pickOrder = (po) => {
//     setPoSel(po);
//     const mine = baseOps.filter((o) => o.production_order === po);
//     if (po && mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start)));
//   };
//   const clearFilters = () => { setMachineSel([]); setPoSel(null); ctl.resetControls(); };

//   return (
//     <Box>
//       <Box sx={{ display: "flex", bgcolor: "#f6f8fb", borderRadius: "8px", px: 2, py: 1.5, mb: 2 }}>
//         <Stat value={stats.operations} label="Operations" color="#1f6fe5" />
//         <Stat value={stats.machines} label="Machines" color="#16a34a" />
//         <Stat value={stats.orders} label="Production Orders" color="#f59e0b" />
//         <Stat value={fmtHours(stats.hours)} label="Total Duration" color="#7c3aed" />
//       </Box>

//       <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 2 }}>
//         <ViewSelect value={ctl.view} onChange={ctl.changeView} />
//         <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
//         <MultiSelect placeholder="Select Machines" options={machines.map((m) => m.machine_id)} value={machineSel}
//           onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
//         <SingleSelect placeholder="Select Production Order" options={Object.keys(colorMap)} value={poSel} onChange={pickOrder} width={210} />
//         <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
//         <ClearFiltersButton onClick={clearFilters} />
//         <RefreshButton onClick={onRefresh} loading={loading} />
//       </Stack>

//       <GanttTimeline
//         machines={rows} ops={shownOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
//         calendar={data?.calendar} colorMap={colorMap} barLines={1} showStatus={false} emptySuffix="(No Operations)"
//         onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
//       />
//       <ProductionOrdersLegend colorMap={poSel ? { [poSel]: colorMap[poSel] } : colorMap} title="Production Orders Legend" />
//     </Box>
//   );
// };

// export const MachineOnlySchedule = ({ data, loading, onRefresh }) => {
//   const ctl = useGanttControls("weekly");
//   const machines = useMemo(() => (data?.machines || []).filter((m) => m.resource_type !== "MANUAL"), [data]);
//   const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
//   const machineIds = useMemo(() => new Set(machines.map((m) => m.machine_id)), [machines]);
//   const filteredOps = useMemo(() => baseOps.filter((o) => machineIds.has(o.machine_id) && overlapsRange(o, ctl.range)), [baseOps, machineIds, ctl.range]);
//   const colorMap = useMemo(() => buildColorMap(filteredOps), [filteredOps]);

//   return (
//     <Box>
//       <Box sx={{ display: "flex", gap: 1.25, mb: 2, flexWrap: "wrap", alignItems: "center" }}>
//         <ViewSelect value={ctl.view} onChange={ctl.changeView} />
//         <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
//         <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
//         <RefreshButton onClick={onRefresh} loading={loading} />
//       </Box>
//       <GanttTimeline machines={machines} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom} calendar={data?.calendar} colorMap={colorMap} barLines={2} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen} />
//       <ProductionOrdersLegend colorMap={colorMap} title="Production Orders (Machine Work Only)" />
//     </Box>
//   );
// };

// export const ManualOnlySchedule = ({ data, loading, onRefresh }) => {
//   const ctl = useGanttControls("weekly");
//   const machines = useMemo(() => (data?.machines || []).filter((m) => m.resource_type === "MANUAL"), [data]);
//   const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
//   const machineIds = useMemo(() => new Set(machines.map((m) => m.machine_id)), [machines]);
//   const filteredOps = useMemo(() => baseOps.filter((o) => machineIds.has(o.machine_id) && overlapsRange(o, ctl.range)), [baseOps, machineIds, ctl.range]);
//   const colorMap = useMemo(() => buildColorMap(filteredOps), [filteredOps]);

//   return (
//     <Box>
//       <Box sx={{ display: "flex", gap: 1.25, mb: 2, flexWrap: "wrap", alignItems: "center" }}>
//         <ViewSelect value={ctl.view} onChange={ctl.changeView} />
//         <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
//         <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
//         <RefreshButton onClick={onRefresh} loading={loading} />
//       </Box>
//       <GanttTimeline machines={machines} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom} calendar={data?.calendar} colorMap={colorMap} barLines={2} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen} />
//       <ProductionOrdersLegend colorMap={colorMap} title="Production Orders (Manual Work Only)" />
//     </Box>
//   );
// };

// export const OperatorSchedule = ({ data }) => {
//   const ops = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
//   const operators = useMemo(() => Array.from(new Set(ops.map((o) => o.operator_name))).sort(), [ops]);
//   const [selectedOp, setSelectedOp] = useState(operators[0] || "");

//   const myOps = useMemo(() => {
//     return ops
//       .filter((o) => o.operator_name === selectedOp)
//       .sort((a, b) => a.start - b.start);
//   }, [ops, selectedOp]);

//   return (
//     <Box>
//       <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 2 }}>
//         <Typography sx={{ fontWeight: 600, fontSize: 14 }}>Select Operator:</Typography>
//         <SingleSelect placeholder="Select Operator" options={operators} value={selectedOp} onChange={setSelectedOp} width={240} />
//       </Box>

//       <TableContainer component={Paper} sx={{ border: `1px solid ${THEME.border}`, boxShadow: "none", borderRadius: "8px" }}>
//         <Table size="small">
//           <TableHead sx={{ bgcolor: "#f6f8fb" }}>
//             <TableRow>
//               <TableCell sx={{ fontWeight: 600 }}>Sequence / Job</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Production Order</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Part Number</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Operation</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Machine / Work Centre</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Start Time</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>End Time</TableCell>
//               <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {myOps.map((op, idx) => (
//               <TableRow key={op.op_id} sx={{ bgcolor: idx === 0 ? "#eff6ff" : "inherit" }}>
//                 <TableCell sx={{ fontWeight: idx === 0 ? 700 : 400 }}>#{idx + 1} {idx === 0 ? "(First Job)" : ""}</TableCell>
//                 <TableCell>{op.production_order}</TableCell>
//                 <TableCell>{op.part_number}</TableCell>
//                 <TableCell>{op.operation_no} - {op.operation_name}</TableCell>
//                 <TableCell>{op.machine_id}</TableCell>
//                 <TableCell>{fmtDateTime(op.start)}</TableCell>
//                 <TableCell>{fmtDateTime(op.end)}</TableCell>
//                 <TableCell sx={{ fontWeight: 600, color: op.status === "IN_PROGRESS" ? "#2563eb" : op.status === "COMPLETED" ? "#16a34a" : "#d97706" }}>
//                   {op.status}
//                 </TableCell>
//               </TableRow>
//             ))}
//             {!myOps.length && (
//               <TableRow>
//                 <TableCell colSpan={8} align="center" sx={{ py: 4, color: THEME.muted }}>No operations assigned to this operator.</TableCell>
//               </TableRow>
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };

// export const ScheduleConfigPage = ({ apiBase, onChanged }) => {
//   const [rows, setRows] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [message, setMessage] = useState(null);

//   const loadConfig = () => {
//     if (!apiBase) return;
//     setLoading(true);
//     axios.get(apiBase + API_ROUTES.config)
//       .then((res) => setRows(res.data || []))
//       .catch((err) => {
//         setRows([]);
//         setMessage({ severity: "error", text: "Could not load the config: " + (err.response?.data?.detail || err.message) });
//       })
//       .finally(() => setLoading(false));
//   };

//   useEffect(() => { loadConfig(); }, [apiBase]);

//   const setField = (stageId, field, value) => {
//     setRows(rows.map((r) => (r.stage_id === stageId ? { ...r, [field]: value, changed: true } : r)));
//   };

//   const saveRow = (row) => {
//     const body = {
//       stage_id: row.stage_id,
//       batch_size: Number(row.batch_size),
//       next_day_release: Boolean(row.next_day_release),
//       cooldown_minutes: Number(row.cooldown_minutes),
//       cooldown_working_time_only: Boolean(row.cooldown_working_time_only),
//       setup_minutes: Number(row.setup_minutes),
//     };
//     if (!Number.isInteger(body.batch_size) || body.batch_size < 1) {
//       setMessage({ severity: "warning", text: `${row.stage_name}: batch size must be a whole number of 1 or more.` });
//       return;
//     }
//     if (!(body.cooldown_minutes >= 0) || !(body.setup_minutes >= 0)) {
//       setMessage({ severity: "warning", text: `${row.stage_name}: minutes cannot be negative.` });
//       return;
//     }
//     axios.post(apiBase + API_ROUTES.config, body)
//       .then(() => {
//         setMessage({ severity: "success", text: `${row.stage_name} saved. The schedule is recalculated.` });
//         loadConfig();
//         if (onChanged) onChanged();
//       })
//       .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
//   };

//   const resetRow = (row) => {
//     axios.delete(`${apiBase}${API_ROUTES.config}/${row.stage_id}`)
//       .then(() => {
//         setMessage({ severity: "success", text: `${row.stage_name} is back to the default values.` });
//         loadConfig();
//         if (onChanged) onChanged();
//       })
//       .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
//   };

//   const numberField = (row, field, disabled) => (
//     <TextField size="small" type="number" value={row[field]} disabled={disabled} sx={{ width: 95 }}
//       inputProps={{ min: field === "batch_size" ? 1 : 0, step: field === "batch_size" ? 1 : "any" }}
//       onChange={(e) => setField(row.stage_id, field, e.target.value)} />
//   );

//   return (
//     <Box>
//       <Typography sx={{ fontSize: 13, color: "#6b7280", mb: 1.5 }}>
//         Batch size and next-day release are used only for BATCH stages (process_type). Cooldown is the wait after
//         a step before the next step of the same order can start; the machine is free for other orders meanwhile.
//       </Typography>

//       {message && (
//         <Alert severity={message.severity} sx={{ mb: 1.5 }} onClose={() => setMessage(null)}>{message.text}</Alert>
//       )}
//       {loading && <LinearProgress sx={{ mb: 1 }} />}

//       <TableContainer sx={{ border: "1px solid #e3e7ee", borderRadius: "8px" }}>
//         <Table size="small">
//           <TableHead>
//             <TableRow sx={{ "& th": { fontWeight: 600, bgcolor: "#f7f8fb" } }}>
//               <TableCell>Stage</TableCell>
//               <TableCell>Mode</TableCell>
//               <TableCell>Batch size</TableCell>
//               <TableCell>Next-day release</TableCell>
//               <TableCell>Cooldown (min)</TableCell>
//               <TableCell>Cooldown in working time only</TableCell>
//               <TableCell>Setup (min)</TableCell>
//               <TableCell align="right">Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {rows.length === 0 && !loading && (
//               <TableRow><TableCell colSpan={8} sx={{ color: "#6b7280" }}>No stages found.</TableCell></TableRow>
//             )}
//             {rows.map((row) => {
//               const isBatch = row.process_mode === "BATCH";
//               return (
//                 <TableRow key={row.stage_id} sx={{ bgcolor: row.changed ? "#fffbeb" : "inherit" }}>
//                   <TableCell>
//                     {row.stage_name}
//                     {row.is_default && <Chip label="default" size="small" sx={{ ml: 1, height: 20, fontSize: 11 }} />}
//                   </TableCell>
//                   <TableCell>{row.process_mode}</TableCell>
//                   <TableCell>{numberField(row, "batch_size", !isBatch)}</TableCell>
//                   <TableCell>
//                     <Switch size="small" checked={Boolean(row.next_day_release)} disabled={!isBatch}
//                       onChange={(e) => setField(row.stage_id, "next_day_release", e.target.checked)} />
//                   </TableCell>
//                   <TableCell>{numberField(row, "cooldown_minutes", false)}</TableCell>
//                   <TableCell>
//                     <Switch size="small" checked={Boolean(row.cooldown_working_time_only)}
//                       onChange={(e) => setField(row.stage_id, "cooldown_working_time_only", e.target.checked)} />
//                   </TableCell>
//                   <TableCell>{numberField(row, "setup_minutes", false)}</TableCell>
//                   <TableCell align="right" sx={{ whiteSpace: "nowrap" }}>
//                     <Button size="small" variant="contained" onClick={() => saveRow(row)} sx={{ textTransform: "none", mr: 1 }}>
//                       Save
//                     </Button>
//                     <Button size="small" onClick={() => resetRow(row)} disabled={row.is_default} sx={{ textTransform: "none" }}>
//                       Reset
//                     </Button>
//                   </TableCell>
//                 </TableRow>
//               );
//             })}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };

// // ==========================================
// // 7. MAIN CONTAINER PAGE[cite: 1]
// // ==========================================
// export default function SchedulingPage() {
//   const { data, loading, error, refresh, saveChanges, apiBase } = useScheduleData();
//   const [tab, setTab] = useState(0);
//   const [showWarnings, setShowWarnings] = useState(false);

//   return (
//     <Box sx={{ p: 3, bgcolor: "#f7f8fb", minHeight: "100%", fontFamily: (theme) => theme.typography.fontFamily }}>
//       <Box sx={{ bgcolor: "#fff", borderRadius: "10px", px: 2.5, py: 2, mb: 2.5, display: "flex", alignItems: "center", gap: 1.25, border: `1px solid ${THEME.border}` }}>
//         <ScheduleIcon />
//         <Typography sx={{ fontSize: 19, fontWeight: 500 }}>Production Schedule</Typography>
//         {data?.generated_at && (
//           <Typography sx={{ fontSize: 12, color: THEME.muted, ml: "auto" }}>
//             Calculated {new Date(data.generated_at).toLocaleString("en-IN")}
//           </Typography>
//         )}
//       </Box>

//       <Box sx={{ bgcolor: "#fff", borderRadius: "10px", border: `1px solid ${THEME.border}`, px: 2.5, pt: 1, pb: 2.5 }}>
//         <Tabs value={tab} onChange={(e, v) => setTab(v)} sx={{ borderBottom: `1px solid ${THEME.border}`, mb: 2, "& .MuiTab-root": { textTransform: "none", fontSize: 14, minHeight: 44 } }}>
//           <Tab label="Machine Schedule" />
//           <Tab label="Planned Schedule" />
//           <Tab label="Operator Login View" />
//           <Tab label="Machine-Only" />
//           <Tab label="Manual-Only" />
//           <Tab label="Process Config" />
//         </Tabs>

//         {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

//         {data?.warnings?.length > 0 && (
//           <Alert severity="warning" sx={{ mb: 2 }}
//             action={<Button color="inherit" size="small" onClick={() => setShowWarnings(!showWarnings)}>{showWarnings ? "Hide" : "Show"}</Button>}>
//             {data.warnings.length} scheduling warning(s)
//             <Collapse in={showWarnings}>
//               <Box component="ul" sx={{ m: 0, mt: 1, pl: 2.5, maxHeight: 200, overflow: "auto" }}>
//                 {data.warnings.map((w, i) => <li key={i}>{w}</li>)}
//               </Box>
//             </Collapse>
//           </Alert>
//         )}

//         {loading && <LinearProgress sx={{ mb: 2 }} />}

//         {tab === 0 && <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} />}
//         {tab === 1 && <PlannedSchedule data={data} loading={loading} onRefresh={refresh} />}
//         {tab === 2 && <OperatorSchedule data={data} />}
//         {tab === 3 && <MachineOnlySchedule data={data} loading={loading} onRefresh={refresh} />}
//         {tab === 4 && <ManualOnlySchedule data={data} loading={loading} onRefresh={refresh} />}
//         {tab === 5 && <ScheduleConfigPage apiBase={apiBase} onChanged={refresh} />}
//       </Box>
//     </Box>
//   );
// }



















import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import {
  Alert, Autocomplete, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions,
  DialogContent, DialogTitle, IconButton, LinearProgress, MenuItem, Paper, Popover, Select,
  Snackbar, Stack, Switch, Tab, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Tabs, TextField, Tooltip, Typography
} from "@mui/material";
import {
  CalendarMonth as CalendarIcon, ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon,
  EventNote as ScheduleIcon, FullscreenExit as FullscreenExitIcon, InfoOutlined as InfoIcon,
  OpenInFull as FullscreenIcon, Refresh as RefreshIcon, Autorenew as UpdateIcon,
  ZoomIn as ZoomInIcon, ZoomOut as ZoomOutIcon
} from "@mui/icons-material";

// ==========================================
// 1. CONFIG & CONSTANTS
// ==========================================
export const DEFAULT_API_BASE = "http://127.0.0.1:2000";
export const API_ROUTES = {
  data: "/schedule/data",
  update: "/schedule/update",
  config: "/schedule/config",
};

export const VIEW_MODES = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "yearly", label: "Yearly" },
];

export const PO_PALETTE = [
  "#1e88e5", "#f59e0b", "#10b981", "#e11d48", "#8b5cf6", "#14b8a6",
  "#f97316", "#84cc16", "#ec4899", "#0ea5e9", "#a16207", "#6366f1",
];

export const STATUS_META = {
  COMPLETED: { label: "Completed", note: "faded bar" },
  IN_PROGRESS: { label: "In progress", note: "bar with white outline" },
  SCHEDULED: { label: "Scheduled", note: "solid bar" },
};

export const THEME = {
  primary: "#1f6fe5",
  info: "#1b9ae1",
  dark: "#5b6573",
  border: "#e3e7ee",
  gridStrong: "#c9d0da",
  gridSoft: "#eceff4",
  text: "#1f2937",
  muted: "#6b7280",
  nowLine: "#ef4444",
  offDay: "rgba(100,116,139,0.08)",
};

export const LAYOUT = {
  labelWidth: 270,
  headerRow1: 30,
  headerRow2: 28,
  rowMin: 26,
  barPad: 4,
  laneHeight2Line: 34,
  laneHeight1Line: 26,
};

export const BASE_DAY_WIDTH = { daily: 900, weekly: 156, monthly: 46, yearly: 3.2 };
export const ZOOM = { min: 0.5, max: 6, step: 0.5 };
export const MAX_CUSTOM_RANGE_DAYS = 400;
export const SNAP_MINUTES = 15;

export const DEFAULT_CALENDAR = {
  shift_start: 6,
  shift_end: 20,
  shifts: [],
  week_off: [0],
  holidays: [],
};

// ==========================================
// CENTRAL AUTH HEADER BUILDER
// ==========================================
const getAuthHeaders = () => {
  const token = localStorage.getItem("token") || sessionStorage.getItem("token") || "";
  return token ? { "x-access-token": token } : {};
};

// ==========================================
// 2. UTILS
// ==========================================
export const DAY = 24 * 3600 * 1000;
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const pad = (n) => String(n).padStart(2, "0");

export const parseTime = (s) => (s ? new Date(s).getTime() : NaN);
export const toLocalIso = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
};
export const toDateInput = (ts) => {
  if (!ts) return "";
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
export const fromDateInput = (s) => {
  if (!s) return null;
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d).getTime();
};
export const startOfDay = (ts) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
export const addDays = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime(); };
export const addMonths = (ts, n) => { const d = new Date(ts); return new Date(d.getFullYear(), d.getMonth() + n, 1).getTime(); };
const startOfWeekMon = (ts) => { const d = new Date(startOfDay(ts)); const back = (d.getDay() + 6) % 7; return addDays(d.getTime(), -back); };

export const fmtDateTime = (ts) => new Date(ts).toLocaleString("en-US");
export const fmtShortDate = (ts) => { const d = new Date(ts); return `${pad(d.getDate())} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
export const fmtHours = (h) => `${(Math.round(h * 10) / 10).toFixed(1)}h`;
const dayLabel = (ts) => { const d = new Date(ts); return `${WEEKDAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };

export function getRange(view, anchor, customStart, customEnd) {
  if (customStart && customEnd) {
    const s = startOfDay(Math.min(customStart, customEnd));
    let e = addDays(startOfDay(Math.max(customStart, customEnd)), 1);
    if ((e - s) / DAY > MAX_CUSTOM_RANGE_DAYS) e = addDays(s, MAX_CUSTOM_RANGE_DAYS);
    return { start: s, end: e, custom: true };
  }
  switch (view) {
    case "daily": { const s = startOfDay(anchor); return { start: s, end: addDays(s, 1) }; }
    case "weekly": { const s = startOfWeekMon(anchor); return { start: s, end: addDays(s, 7) }; }
    case "monthly": { const s = addMonths(anchor, 0); return { start: s, end: addMonths(s, 1) }; }
    default: { const s = addMonths(anchor, -1); return { start: s, end: addMonths(s, 12) }; }
  }
}

export function shiftAnchor(view, anchor, dir, range) {
  if (range?.custom) return anchor;
  switch (view) {
    case "daily": return addDays(anchor, dir);
    case "weekly": return addDays(anchor, 7 * dir);
    case "monthly": return addMonths(anchor, dir);
    default: return addMonths(anchor, 12 * dir);
  }
}

export function buildScale({ view, range, zoom, calendar, availableWidth }) {
  const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
  const windowed = view === "daily" || view === "weekly";
  const wStart = windowed ? cal.shift_start : 0;
  const wEnd = windowed ? cal.shift_end : 24;
  const hours = wEnd - wStart;

  const days = [];
  for (let t = range.start; t < range.end; t = addDays(t, 1)) days.push(t);

  const baseDay = BASE_DAY_WIDTH[view] || 100;
  const fill = Math.max(0, availableWidth) / Math.max(days.length, 1);
  const dayW = Math.max(baseDay, fill) * zoom;
  const totalWidth = dayW * days.length;

  const winStart = (i) => days[i] + wStart * 3600e3;
  const winLen = hours * 3600e3;

  const dayIndexOf = (ts) => {
    if (ts <= days[0]) return -1;
    let lo = 0, hi = days.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (days[mid] <= ts) lo = mid; else hi = mid - 1; }
    return ts >= range.end ? days.length : lo;
  };

  const toX = (ts) => {
    const i = dayIndexOf(ts);
    if (i < 0) return 0;
    if (i >= days.length) return totalWidth;
    const frac = Math.min(1, Math.max(0, (ts - winStart(i)) / winLen));
    return i * dayW + frac * dayW;
  };
  const toTime = (x) => {
    const cx = Math.min(totalWidth - 0.001, Math.max(0, x));
    const i = Math.floor(cx / dayW);
    const frac = (cx - i * dayW) / dayW;
    return winStart(i) + frac * winLen;
  };

  const row1 = [], row2 = [], grid = [];
  const groupBy = (keyFn, labelFn, target) => {
    let startIdx = 0;
    for (let i = 1; i <= days.length; i++) {
      if (i === days.length || keyFn(days[i]) !== keyFn(days[startIdx])) {
        target.push({ x: startIdx * dayW, w: (i - startIdx) * dayW, label: labelFn(days[startIdx], i - startIdx) });
        startIdx = i;
      }
    }
  };

  if (view === "daily" || view === "weekly") {
    days.forEach((d, i) => {
      row1.push({ x: i * dayW, w: dayW, label: dayLabel(d) });
      const step = view === "daily" ? Math.max(1, Math.ceil(46 / (dayW / hours))) : 6;
      const ticks = [wStart];
      for (let h = wStart + 1; h < wEnd; h++) if ((view === "daily" ? (h - wStart) % step === 0 : h % step === 0)) ticks.push(h);
      ticks.forEach((h, k) => {
        const next = k + 1 < ticks.length ? ticks[k + 1] : wEnd;
        row2.push({ x: i * dayW + ((h - wStart) / hours) * dayW, w: ((next - h) / hours) * dayW, label: `${pad(h)}:00` });
      });
    });
  } else if (view === "monthly") {
    groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
      (t) => `${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][new Date(t).getMonth()]} ${new Date(t).getFullYear()}`, row1);
    days.forEach((d, i) => row2.push({ x: i * dayW, w: dayW, label: String(new Date(d).getDate()), sub: WEEKDAYS[new Date(d).getDay()][0] }));
  } else {
    groupBy((t) => new Date(t).getFullYear(), (t) => String(new Date(t).getFullYear()), row1);
    groupBy((t) => `${new Date(t).getFullYear()}-${new Date(t).getMonth()}`,
      (t, n) => (n * dayW < 30 ? MONTHS[new Date(t).getMonth()][0] : MONTHS[new Date(t).getMonth()]), row2);
  }
  row2.forEach((c) => grid.push({ x: c.x, strong: false }));
  row1.forEach((c) => grid.push({ x: c.x, strong: true }));

  const holidaySet = new Set((cal.holidays || []).map((h) => h.holiday_date));
  const offDays = [];
  if (dayW >= 12) {
    days.forEach((d, i) => {
      const dt = new Date(d);
      const key = `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`;
      if ((cal.week_off || []).includes(dt.getDay()) || holidaySet.has(key)) offDays.push({ x: i * dayW, w: dayW });
    });
  }

  return { days, dayW, totalWidth, toX, toTime, row1, row2, grid, offDays, windowed };
}

export function layoutRows(machines, ops, scale, barLines) {
  const laneH = barLines === 2 ? LAYOUT.laneHeight2Line : LAYOUT.laneHeight1Line;
  const byMachine = {};
  ops.forEach((o) => { (byMachine[o.machine_id] = byMachine[o.machine_id] || []).push(o); });

  let top = 0;
  return machines.map((m) => {
    const mine = (byMachine[m.machine_id] || []).slice().sort((a, b) => a.start - b.start);
    const laneEnds = [];
    const bars = mine.map((o) => {
      const x = scale.toX(o.start);
      const w = Math.max(scale.toX(o.end) - x, 3);
      let lane = laneEnds.findIndex((end) => end <= o.start);
      if (lane < 0) { lane = laneEnds.length; laneEnds.push(0); }
      laneEnds[lane] = o.end;
      return { op: o, x, w, lane };
    });
    const lanes = Math.max(laneEnds.length, 1);
    const height = bars.length ? lanes * laneH + 2 * LAYOUT.barPad : LAYOUT.rowMin;
    const row = { machine: m, bars, top, height, laneH };
    top += height;
    return row;
  });
}

export const machineLabel = (m) => (m.machine_name && m.machine_name !== m.machine_id ? `${m.machine_id} - ${m.machine_name}` : m.machine_id);

export function buildColorMap(ops) {
  const pos = Array.from(new Set(ops.map((o) => o.production_order))).sort();
  const map = {};
  pos.forEach((po, i) => { map[po] = PO_PALETTE[i % PO_PALETTE.length]; });
  return map;
}

export function normaliseOps(rawOps, mode) {
  return rawOps
    .map((o) => {
      const planned = mode === "planned";
      const start = parseTime(planned ? o.planned_start : o.start_time);
      const end = parseTime(planned ? o.planned_end : o.end_time);
      return {
        ...o,
        machine_id: planned ? o.planned_machine_id : o.machine_id,
        start, end,
        pdc: parseTime(o.planned_end),
      };
    })
    .filter((o) => Number.isFinite(o.start) && Number.isFinite(o.end));
}

export const overlapsRange = (o, range) => o.end > range.start && o.start < range.end;

// ==========================================
// 3. HOOKS
// ==========================================
export function useGanttControls(initialView = "weekly") {
  const [view, setView] = useState(initialView);
  const [anchor, setAnchor] = useState(() => Date.now());
  const [customStart, setCustomStart] = useState(null);
  const [customEnd, setCustomEnd] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const fsRef = useRef(null);

  const range = useMemo(() => getRange(view, anchor, customStart, customEnd), [view, anchor, customStart, customEnd]);

  const changeView = useCallback((v) => { setView(v); setCustomStart(null); setCustomEnd(null); setZoom(1); }, []);
  const navigate = useCallback((dir) => setAnchor((a) => shiftAnchor(view, a, dir, range)), [view, range]);
  const setDateRange = useCallback((s, e) => { setCustomStart(s); setCustomEnd(e); }, []);
  const goTo = useCallback((ts) => setAnchor(ts), []);
  const zoomIn = useCallback(() => setZoom((z) => Math.min(ZOOM.max, z + ZOOM.step)), []);
  const zoomOut = useCallback(() => setZoom((z) => Math.max(ZOOM.min, z - ZOOM.step)), []);
  const resetControls = useCallback(() => { setCustomStart(null); setCustomEnd(null); setZoom(1); setAnchor(Date.now()); }, []);

  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === fsRef.current);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = fsRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen?.();
    else if (el.requestFullscreen) el.requestFullscreen().catch(() => setIsFullscreen((f) => !f));
    else setIsFullscreen((f) => !f);
  }, []);

  return {
    view, changeView, range, navigate, goTo, customStart, customEnd, setDateRange,
    zoom, zoomIn, zoomOut, resetControls, fsRef, isFullscreen, toggleFullscreen,
  };
}

export function useScheduleData() {
  const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);
  const apiBase = useMemo(
    () => configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP || DEFAULT_API_BASE,
    [configDetails]
  );

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get(apiBase + API_ROUTES.data, { headers: getAuthHeaders() });
      setData(res.data);
    } catch (e) {
      setError("Unable to load the production schedule. Check the server connection.");
    } finally {
      setLoading(false);
    }
  }, [apiBase]);

  useEffect(() => { load(); }, [load]);

  const saveChanges = useCallback(
    async (changes) => { await axios.post(apiBase + API_ROUTES.update, { changes }, { headers: getAuthHeaders() }); },
    [apiBase]
  );

  return { data, loading, error, refresh: load, saveChanges, apiBase };
}

// ==========================================
// 4. COMPONENTS & CONTROLS
// ==========================================
const fieldSx = {
  "& .MuiOutlinedInput-root": { borderRadius: "6px", fontSize: 13.5, bgcolor: "#fff", minHeight: 36 },
  "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border },
};

export const ViewSelect = ({ value, onChange }) => (
  <Select size="small" value={value} onChange={(e) => onChange(e.target.value)}
    sx={{ width: 118, height: 36, fontSize: 13.5, borderRadius: "6px", bgcolor: "#fff", "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border } }}>
    {VIEW_MODES.map((v) => <MenuItem key={v.value} value={v.value} sx={{ fontSize: 13.5 }}>{v.label}</MenuItem>)}
  </Select>
);

export const DateRangeField = ({ start, end, onChange }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [s, setS] = useState("");
  const [e, setE] = useState("");
  const open = (ev) => { setS(toDateInput(start)); setE(toDateInput(end)); setAnchorEl(ev.currentTarget.closest("[data-daterange]")); };
  const text = start && end ? `${fmtShortDate(start)} – ${fmtShortDate(end)}` : "";

  return (
    <>
      <Box data-daterange sx={{ display: "flex", width: 262 }}>
        <TextField size="small" placeholder="Start Date – End Date" value={text} onClick={open} fullWidth
          InputProps={{ readOnly: true, sx: { cursor: "pointer", borderTopRightRadius: 0, borderBottomRightRadius: 0 } }}
          sx={{ ...fieldSx, "& input": { cursor: "pointer" } }} />
        <IconButton aria-label="Pick dates" onClick={open}
          sx={{ width: 38, height: 36, borderRadius: "0 6px 6px 0", bgcolor: THEME.primary, color: "#fff", "&:hover": { bgcolor: "#1a5fc7" } }}>
          <CalendarIcon fontSize="small" />
        </IconButton>
      </Box>
      <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}>
        <Stack spacing={1.5} sx={{ p: 2, width: 260 }}>
          <TextField size="small" type="date" label="Start Date" value={s} onChange={(ev) => setS(ev.target.value)} InputLabelProps={{ shrink: true }} />
          <TextField size="small" type="date" label="End Date" value={e} onChange={(ev) => setE(ev.target.value)} InputLabelProps={{ shrink: true }} />
          <Stack direction="row" spacing={1} justifyContent="flex-end">
            <Button size="small" onClick={() => { onChange(null, null); setAnchorEl(null); }}>Clear</Button>
            <Button size="small" variant="contained" disabled={!s || !e}
              onClick={() => { onChange(fromDateInput(s), fromDateInput(e)); setAnchorEl(null); }}>Apply</Button>
          </Stack>
        </Stack>
      </Popover>
    </>
  );
};

export const MultiSelect = ({ placeholder, options, value, onChange, width = 200, getLabel = (o) => o }) => (
  <Autocomplete multiple size="small" limitTags={1} disableCloseOnSelect options={options} value={value}
    getOptionLabel={getLabel} onChange={(_, v) => onChange(v)} sx={{ width, ...fieldSx }}
    ChipProps={{ size: "small", sx: { maxWidth: 96, fontSize: 12 } }}
    renderInput={(params) => <TextField {...params} placeholder={value.length ? "" : placeholder} />} />
);

export const SingleSelect = ({ placeholder, options, value, onChange, width = 200 }) => (
  <Autocomplete size="small" options={options} value={value} onChange={(_, v) => onChange(v)}
    sx={{ width, ...fieldSx }} renderInput={(params) => <TextField {...params} placeholder={placeholder} />} />
);

const toolSx = { width: 34, height: 34, color: THEME.primary, "&:hover": { bgcolor: "#eef3fb" } };

export const ChartTools = ({ zoomIn, zoomOut, isFullscreen, toggleFullscreen, onInfo }) => (
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Tooltip title="Zoom in"><IconButton aria-label="Zoom in" onClick={zoomIn} sx={toolSx}><ZoomInIcon fontSize="small" /></IconButton></Tooltip>
    <Tooltip title="Zoom out"><IconButton aria-label="Zoom out" onClick={zoomOut} sx={toolSx}><ZoomOutIcon fontSize="small" /></IconButton></Tooltip>
    <Tooltip title={isFullscreen ? "Exit full screen" : "Full screen"}>
      <IconButton aria-label="Full screen" onClick={toggleFullscreen} sx={toolSx}>
        {isFullscreen ? <FullscreenExitIcon fontSize="small" /> : <FullscreenIcon fontSize="small" />}
      </IconButton>
    </Tooltip>
    {onInfo && (
      <Tooltip title="How to use">
        <IconButton aria-label="Info" onClick={onInfo} sx={{ width: 36, height: 36, borderRadius: "6px", bgcolor: THEME.info, color: "#fff", "&:hover": { bgcolor: "#1488c9" } }}>
          <InfoIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    )}
  </Stack>
);

export const InfoPopover = ({ anchorEl, onClose, editable }) => (
  <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onClose} anchorOrigin={{ vertical: "bottom", horizontal: "right" }} transformOrigin={{ vertical: "top", horizontal: "right" }}>
    <Box sx={{ p: 2, width: 330, fontSize: 13, color: THEME.text }}>
      <Typography fontWeight={700} fontSize={14} mb={1}>How to read this chart</Typography>
      <Box component="ul" sx={{ m: 0, pl: 2.25, "& li": { mb: 0.5 } }}>
        <li>Each row is a machine / manual work centre; each bar is one operation of a production order.</li>
        <li>Hover a bar for part number, quantity, start, end and the PDC (planned date of completion).</li>
        <li>The red line is the current time. Shaded columns are Sundays / public holidays.</li>
        <li>Daily &amp; Weekly views show only the working hours of each shift; Monthly &amp; Yearly show full days.</li>
        <li>Use the &lt; &gt; arrows to move period, and the zoom buttons to stretch the timeline.</li>
        {editable && <li><b>Drag a bar</b> to a new time or machine row to re-schedule it, then press <b>Update</b> to save.</li>}
      </Box>
      <Typography fontWeight={700} fontSize={13} mt={1.5} mb={0.75}>Bar status</Typography>
      {Object.entries(STATUS_META).map(([k, v]) => (
        <Box key={k} sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
          <Box sx={{ width: 26, height: 12, borderRadius: "2px", bgcolor: THEME.primary, opacity: k === "COMPLETED" ? 0.55 : 1, boxShadow: k === "IN_PROGRESS" ? "inset 0 0 0 1.5px #fff, 0 0 0 1px " + THEME.primary : "none" }} />
          <span>{v.label} <Box component="span" sx={{ color: THEME.muted }}>({v.note})</Box></span>
        </Box>
      ))}
    </Box>
  </Popover>
);

export const RefreshButton = ({ onClick, dark, loading }) => (
  <Button variant="contained" startIcon={<RefreshIcon />} onClick={onClick} disabled={loading}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: dark ? THEME.dark : THEME.primary, "&:hover": { bgcolor: dark ? "#4a5361" : "#1a5fc7", boxShadow: "none" } }}>
    Refresh
  </Button>
);

export const UpdateButton = ({ onClick, count, saving }) => (
  <Button variant="contained" startIcon={<UpdateIcon />} onClick={onClick} disabled={saving || !count}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.primary }}>
    Update{count ? ` (${count})` : ""}
  </Button>
);

export const ClearFiltersButton = ({ onClick }) => (
  <Button variant="contained" onClick={onClick}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.dark, "&:hover": { bgcolor: "#4a5361", boxShadow: "none" } }}>
    Clear Filters
  </Button>
);

export const ProductionOrdersLegend = ({ colorMap, title = "Production Orders" }) => (
  <Box sx={{ mt: 2.5, pt: 1.5, borderTop: `1px solid ${THEME.border}` }}>
    <Typography sx={{ fontSize: 13, fontWeight: 600, mb: 1, color: THEME.text }}>{title}</Typography>
    <Box sx={{ display: "flex", flexWrap: "wrap", gap: "6px 18px" }}>
      {Object.entries(colorMap).map(([po, color]) => (
        <Box key={po} sx={{ display: "flex", alignItems: "center", gap: 0.75, fontSize: 12, color: THEME.muted }}>
          <Box sx={{ width: 13, height: 13, borderRadius: "3px", bgcolor: color }} />{po}
        </Box>
      ))}
    </Box>
  </Box>
);

// ==========================================
// 5. DIALOG & TIMELINE COMPONENTS
// ==========================================
export const EditOperationDialog = ({ open, op, machines, apiBase, onClose, onSaved }) => {
  const [machineId, setMachineId] = useState("");
  const [start, setStart] = useState("");
  const [saving, setSaving] = useState(false);
  const [rejected, setRejected] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (op) {
      setMachineId(op.machine_id);
      setStart((op.start_time || "").slice(0, 16));
      setRejected([]);
      setError("");
    }
  }, [op]);

  if (!op) return null;

  const stageMachines = machines.filter((m) => m.stage_id === op.flow_step_id);
  const completed = op.status === "COMPLETED";

  const handleUpdate = () => {
    setSaving(true);
    setRejected([]);
    setError("");
    const change = { op_id: op.op_id, machine_id: machineId, start_time: start + ":00" };
    axios.post(apiBase + "/schedule/update", { changes: [change] }, { headers: getAuthHeaders() })
      .then((res) => {
        if (res.data.updated > 0) onSaved();
        else setRejected(res.data.rejected || []);
      })
      .catch((err) => setError("Could not save: " + (err.response?.data?.detail || err.message)))
      .finally(() => setSaving(false));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontSize: 17 }}>
        {op.production_order} · {op.operation_no} - {op.step_name}
      </DialogTitle>
      <DialogContent>
        <Box sx={{ fontSize: 13, color: "#4b5563", mb: 2, lineHeight: 1.7, fontFamily: (theme) => theme.typography.fontFamily }}>
          <div>Part: <b>{op.part_number}</b> · {op.process_mode} · {op.completed_qty}/{op.quantity} pcs · {op.status}</div>
          <div>Scheduled: <b>{fmtDateTime(op.start)}</b> → <b>{fmtDateTime(op.end)}</b> on <b>{op.machine_id}</b></div>
          <div>PDC (planned end): <b>{fmtDateTime(op.pdc)}</b></div>
          {op.waiting_reason && <div>Waiting for: <b>{op.waiting_reason}</b></div>}
        </Box>

        {completed && <Alert severity="info" sx={{ mb: 2 }}>This operation is completed and cannot be moved.</Alert>}

        <Stack spacing={2}>
          <TextField select size="small" label="Machine" value={machineId} disabled={completed}
            onChange={(e) => setMachineId(e.target.value)}>
            {stageMachines.map((m) => (
              <MenuItem key={m.machine_id} value={m.machine_id}>
                {m.machine_id}{m.machine_name && m.machine_name !== m.machine_id ? ` - ${m.machine_name}` : ""}
              </MenuItem>
            ))}
          </TextField>
          <TextField size="small" type="datetime-local" label="Start" value={start} disabled={completed}
            InputLabelProps={{ shrink: true }} onChange={(e) => setStart(e.target.value)} />
        </Stack>

        {rejected.map((r, i) => (
          <Alert key={i} severity="warning" sx={{ mt: 2 }}>Not saved: {r.reason}</Alert>
        ))}
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleUpdate} disabled={completed || saving || !machineId || !start}
          startIcon={saving ? <CircularProgress size={16} color="inherit" /> : null}>
          Update
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const navBtnSx = {
  position: "absolute", top: 4, zIndex: 8, width: 26, height: 26, bgcolor: "#fff",
  border: `1px solid ${THEME.border}`, borderRadius: "6px", color: THEME.primary,
  "&:hover": { bgcolor: "#f3f7ff" },
};

const TooltipRow = ({ k, v }) => (
  <Box sx={{ display: "flex", gap: 0.5, lineHeight: 1.45 }}>
    <Box component="span" sx={{ color: THEME.muted, whiteSpace: "nowrap" }}>{k}:</Box>
    <Box component="span" sx={{ color: THEME.text, fontWeight: 500 }}>{v}</Box>
  </Box>
);

export const GanttTimeline = ({
  machines, ops, view, range, zoom, calendar, colorMap, barLines = 2,
  emptySuffix = "", editable = false, showStatus = true, pendingIds, onChangeOp, onNavigate, fsRef, isFullscreen,
}) => {
  const scrollRef = useRef(null);
  const bodyRef = useRef(null);
  const [width, setWidth] = useState(0);
  const [tip, setTip] = useState(null);
  const [drag, setDrag] = useState(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return undefined;
    const measure = () => setWidth(Math.max(0, el.clientWidth - LAYOUT.labelWidth));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);

  const scale = useMemo(
    () => buildScale({ view, range, zoom, calendar, availableWidth: width }),
    [view, range, zoom, calendar, width]
  );

  const visibleOps = useMemo(() => (drag ? ops.filter((o) => o.op_id !== drag.op.op_id) : ops), [ops, drag]);
  const rows = useMemo(() => layoutRows(machines, visibleOps, scale, barLines), [machines, visibleOps, scale, barLines]);
  const rowsRef = useRef(rows); rowsRef.current = rows;
  const scaleRef = useRef(scale); scaleRef.current = scale;

  const bodyHeight = rows.reduce((s, r) => s + r.height, 0);
  const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
  const nowD = new Date(now);
  const nowHour = nowD.getHours() + nowD.getMinutes() / 60;
  const nowVisible = now >= range.start && now < range.end && (!scale.windowed || (nowHour >= cal.shift_start && nowHour < cal.shift_end));
  const nowX = nowVisible ? scale.toX(now) : null;
  const headerH = LAYOUT.headerRow1 + LAYOUT.headerRow2;

  const startDrag = useCallback((e, bar) => {
    if (!editable || e.button !== 0) return;
    e.preventDefault();
    setTip(null);
    const startX = e.clientX;
    const op = bar.op;
    const duration = op.end - op.start;
    const snap = SNAP_MINUTES * 60000;
    let moved = false;
    let last = null;

    const compute = (ev) => {
      const sc = scaleRef.current;
      const dx = ev.clientX - startX;
      const yRel = ev.clientY - bodyRef.current.getBoundingClientRect().top;
      const target = rowsRef.current.find((r) => yRel >= r.top && yRel < r.top + r.height)
        || rowsRef.current.find((r) => r.machine.machine_id === op.machine_id);
      const start = Math.round(sc.toTime(bar.x + dx) / snap) * snap;
      const end = start + duration;
      const x = sc.toX(start);
      return {
        op, start, end, machine_id: target.machine.machine_id,
        ghost: { x, w: Math.max(sc.toX(end) - x, 3), top: target.top + LAYOUT.barPad, h: bar.h },
      };
    };
    const onMove = (ev) => {
      if (Math.abs(ev.clientX - startX) > 3 || moved) moved = true;
      if (!moved) return;
      last = compute(ev);
      setDrag(last);
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      setDrag(null);
      if (moved && last && (last.start !== op.start || last.machine_id !== op.machine_id)) {
        onChangeOp?.(op, { machine_id: last.machine_id, start_time: toLocalIso(last.start), end_time: toLocalIso(last.end) });
      }
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }, [editable, onChangeOp]);

  const showTip = (e, op) => { if (!drag) setTip({ x: e.clientX, y: e.clientY, op }); };
  const machineById = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, m])), [machines]);

  const renderTip = () => {
    if (!tip) return null;
    const { op } = tip;
    const m = machineById[op.machine_id];
    const qtyWord = op.status === "COMPLETED" ? "Completed" : op.status === "IN_PROGRESS" ? "Process" : "Scheduled";
    const vw = typeof window !== "undefined" ? window.innerWidth : 1400;
    const left = tip.x + 300 > vw ? tip.x - 290 : tip.x + 14;
    return (
      <Box sx={{
        position: "fixed", left, top: tip.y + 14, zIndex: 3000, bgcolor: "#fff", border: `1px solid ${THEME.border}`,
        borderRadius: "6px", boxShadow: "0 4px 18px rgba(15,23,42,0.18)", px: 1.25, py: 0.75, fontSize: 12.5,
        pointerEvents: "none", minWidth: 250,
      }}>
        <TooltipRow k="Part Number" v={op.part_number} />
        <TooltipRow k="Machine" v={m ? machineLabel(m) : op.machine_id} />
        <TooltipRow k="Production Order" v={op.production_order} />
        <TooltipRow k="Operation" v={`${op.operation_no} - ${op.operation_name}`} />
        <TooltipRow k="Quantity" v={`${qtyWord}(${op.completed_qty}/${op.quantity}pcs)`} />
        <TooltipRow k="Mode" v={`${op.process_mode === "BATCH" ? "Batch" : "Series"}${m?.resource_type === "MANUAL" ? " (Manual)" : ""}`} />
        <TooltipRow k="Operator" v={op.operator_name} />
        <TooltipRow k="Start" v={fmtDateTime(op.start)} />
        <TooltipRow k="End" v={fmtDateTime(op.end)} />
        <TooltipRow k="PDC of Operation" v={fmtDateTime(op.pdc)} />
        {pendingIds?.has(op.op_id) && <Box sx={{ mt: 0.5, color: "#b45309", fontWeight: 600 }}>Modified - press Update to save</Box>}
      </Box>
    );
  };

  const renderBar = (bar, row) => {
    const { op, x, w, lane } = bar;
    const color = colorMap[op.production_order] || THEME.primary;
    const h = row.laneH - 4;
    const pending = pendingIds?.has(op.op_id);
    const fadedOut = showStatus && op.status === "COMPLETED";
    return (
      <Box
        key={op.op_id}
        onPointerDown={(e) => startDrag(e, { ...bar, h })}
        onMouseEnter={(e) => showTip(e, op)}
        onMouseMove={(e) => showTip(e, op)}
        onMouseLeave={() => setTip(null)}
        sx={{
          position: "absolute", left: x, top: LAYOUT.barPad + lane * row.laneH, width: w, height: h, zIndex: 1,
          bgcolor: color, color: "#fff", borderRadius: "3px", px: w > 14 ? 0.5 : 0, overflow: "hidden",
          fontSize: 11, lineHeight: 1.25, display: "flex", flexDirection: "column", justifyContent: "center",
          opacity: fadedOut ? 0.55 : 1, cursor: editable ? "grab" : "default", userSelect: "none",
          boxShadow: showStatus && op.status === "IN_PROGRESS" ? `inset 0 0 0 1.5px #fff, 0 0 0 1px ${color}` : "none",
          outline: pending ? "2px dashed #f59e0b" : "none", outlineOffset: 1,
          borderRight: "1px solid rgba(255,255,255,0.55)",
          "&:hover": { filter: "brightness(1.08)" },
        }}
      >
        {w > 18 && (
          <>
            <Box sx={{ fontWeight: 600, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>{op.production_order}</Box>
            {barLines === 2 && (
              <Box sx={{ whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden", opacity: 0.95 }}>
                {op.part_number} - {op.operation_name}
              </Box>
            )}
          </>
        )}
      </Box>
    );
  };

  const cssFullscreen = isFullscreen && typeof document !== "undefined" && !document.fullscreenElement;

  return (
    <Box
      ref={fsRef}
      sx={{
        position: cssFullscreen ? "fixed" : "relative", inset: cssFullscreen ? 0 : "auto", zIndex: cssFullscreen ? 1400 : "auto",
        bgcolor: "#fff", border: `1px solid ${THEME.border}`, borderRadius: "10px", p: isFullscreen ? 1.5 : 0.5,
        boxSizing: "border-box", height: isFullscreen ? "100%" : "auto",
      }}
    >
      <Box sx={{ position: "relative" }}>
        <IconButton aria-label="Previous period" onClick={() => onNavigate(-1)} sx={{ ...navBtnSx, left: 8 }}><ChevronLeftIcon fontSize="small" /></IconButton>
        <IconButton aria-label="Next period" onClick={() => onNavigate(1)} sx={{ ...navBtnSx, right: 10 }}><ChevronRightIcon fontSize="small" /></IconButton>

        <Box ref={scrollRef} sx={{ overflow: "auto", maxHeight: isFullscreen ? "calc(100vh - 36px)" : 560 }}>
          <Box sx={{ width: LAYOUT.labelWidth + scale.totalWidth, minWidth: "100%", position: "relative", isolation: "isolate" }}>
            <Box sx={{ position: "sticky", top: 0, zIndex: 6, display: "flex", bgcolor: "#fff", height: headerH, borderBottom: `1px solid ${THEME.gridStrong}` }}>
              <Box sx={{ position: "sticky", left: 0, zIndex: 7, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff", borderRight: `1px solid ${THEME.gridStrong}` }} />
              <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                {scale.row1.map((c, i) => (
                  <Box key={`r1-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: 0, height: LAYOUT.headerRow1, borderLeft: `1px solid ${THEME.gridStrong}`, px: 0.5, display: "flex", alignItems: "center", fontSize: 13, fontWeight: 500, color: THEME.text, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}
                  </Box>
                ))}
                {scale.row2.map((c, i) => (
                  <Box key={`r2-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: LAYOUT.headerRow1, height: LAYOUT.headerRow2, borderLeft: `1px solid ${THEME.gridSoft}`, px: 0.5, display: "flex", alignItems: "center", gap: 0.4, fontSize: 12, color: THEME.muted, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}{c.sub && c.w > 30 ? <Box component="span" sx={{ fontSize: 9, opacity: 0.7 }}>{c.sub}</Box> : null}
                  </Box>
                ))}
              </Box>
            </Box>

            <Box ref={bodyRef} sx={{ position: "relative", minHeight: 160 }}>
              <Box sx={{ position: "absolute", left: LAYOUT.labelWidth, top: 0, width: scale.totalWidth, height: Math.max(bodyHeight, 160), zIndex: 0, pointerEvents: "none" }}>
                {scale.offDays.map((d, i) => <Box key={`off-${i}`} sx={{ position: "absolute", left: d.x, width: d.w, top: 0, bottom: 0, bgcolor: THEME.offDay }} />)}
                {scale.grid.map((g, i) => <Box key={`g-${i}`} sx={{ position: "absolute", left: g.x, top: 0, bottom: 0, width: "1px", bgcolor: g.strong ? THEME.gridStrong : THEME.gridSoft }} />)}
              </Box>
              {nowX !== null && (
                <Box sx={{ position: "absolute", left: LAYOUT.labelWidth + nowX, top: 0, height: Math.max(bodyHeight, 160), width: "2px", bgcolor: THEME.nowLine, zIndex: 2, pointerEvents: "none" }} />
              )}

              {rows.length === 0 && (
                <Typography sx={{ position: "sticky", left: LAYOUT.labelWidth, p: 3, color: THEME.muted, fontSize: 13 }}>No machines to display.</Typography>
              )}

              {rows.map((row) => (
                <Box key={row.machine.machine_id} sx={{ display: "flex", height: row.height, borderBottom: `1px solid ${THEME.gridSoft}` }}>
                  <Box title={machineLabel(row.machine)} sx={{
                    position: "sticky", left: 0, zIndex: 3, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff",
                    borderRight: `1px solid ${THEME.gridStrong}`, px: 1, pt: row.bars.length ? 0.6 : 0, display: "flex",
                    alignItems: row.bars.length ? "flex-start" : "center", fontSize: 11.5, color: THEME.text,
                    fontWeight: row.bars.length ? 600 : 400, fontStyle: row.machine.resource_type === "MANUAL" ? "italic" : "normal",
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  }}>
                    {machineLabel(row.machine)}{!row.bars.length && emptySuffix ? ` ${emptySuffix}` : ""}
                  </Box>
                  <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                    {row.bars.map((bar) => renderBar(bar, row))}
                  </Box>
                </Box>
              ))}

              {drag && (
                <Box sx={{
                  position: "absolute", left: LAYOUT.labelWidth + drag.ghost.x, top: drag.ghost.top, width: drag.ghost.w, height: drag.ghost.h,
                  bgcolor: colorMap[drag.op.production_order] || THEME.primary, opacity: 0.85, borderRadius: "3px", zIndex: 5,
                  outline: "2px dashed #f59e0b", pointerEvents: "none", color: "#fff", fontSize: 11, px: 0.5, display: "flex", alignItems: "center",
                  whiteSpace: "nowrap", overflow: "hidden",
                }}>
                  {drag.op.production_order} · {new Date(drag.start).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                </Box>
              )}
            </Box>
          </Box>
        </Box>
      </Box>
      {renderTip()}
    </Box>
  );
};

// ==========================================
// 6. TABS / SCREENS
// ==========================================
export const MachineSchedule = ({ data, loading, onRefresh, saveChanges }) => {
  const ctl = useGanttControls("weekly");
  const [machineSel, setMachineSel] = useState([]);
  const [partSel, setPartSel] = useState([]);
  const [poSel, setPoSel] = useState([]);
  const [infoAnchor, setInfoAnchor] = useState(null);
  const [edits, setEdits] = useState({});
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const machines = data?.machines || [];
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);

  const ops = useMemo(() => baseOps.map((o) => {
    const e = edits[o.op_id];
    return e ? { ...o, machine_id: e.machine_id, start: parseTime(e.start_time), end: parseTime(e.end_time) } : o;
  }), [baseOps, edits]);

  const filteredOps = useMemo(() => ops.filter((o) =>
    (!machineSel.length || machineSel.includes(o.machine_id)) &&
    (!partSel.length || partSel.includes(o.part_number)) &&
    (!poSel.length || poSel.includes(o.production_order)) &&
    overlapsRange(o, ctl.range)), [ops, machineSel, partSel, poSel, ctl.range]);

  const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);
  const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);
  const partOptions = useMemo(() => Array.from(new Set(baseOps.map((o) => o.part_number))).sort(), [baseOps]);
  const poOptions = useMemo(() => Object.keys(colorMap), [colorMap]);
  const pendingIds = useMemo(() => new Set(Object.keys(edits)), [edits]);

  const onChangeOp = useCallback((op, patch) => setEdits((prev) => ({ ...prev, [op.op_id]: patch })), []);

  const handleUpdate = async () => {
    setSaving(true);
    try {
      await saveChanges(Object.entries(edits).map(([op_id, p]) => ({ op_id, ...p })));
      setEdits({});
      await onRefresh();
      setToast({ severity: "success", msg: "Schedule updated." });
    } catch (e) {
      setToast({ severity: "error", msg: "Could not save the schedule changes." });
    } finally { setSaving(false); }
  };

  const pickOrders = (list) => {
    setPoSel(list);
    const mine = baseOps.filter((o) => list.includes(o.production_order));
    if (mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start)));
  };

  const handleRefresh = async () => { setEdits({}); await onRefresh(); };

  return (
    <Box>
      <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 1.25 }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <MultiSelect placeholder="Select Machines" options={machines.map((m) => m.machine_id)} value={machineSel}
          onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
        <MultiSelect placeholder="Select Part Number" options={partOptions} value={partSel} onChange={setPartSel} width={210} />
        <MultiSelect placeholder="Select Production Orders" options={poOptions} value={poSel} onChange={pickOrders} width={230} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen}
          toggleFullscreen={ctl.toggleFullscreen} onInfo={(e) => setInfoAnchor(e.currentTarget)} />
      </Stack>
      <Stack direction="row" spacing={1.25} sx={{ mb: 2 }}>
        <UpdateButton onClick={handleUpdate} count={pendingIds.size} saving={saving} />
        <RefreshButton onClick={handleRefresh} dark loading={loading} />
      </Stack>

      <GanttTimeline
        machines={rows} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
        calendar={data?.calendar} colorMap={colorMap} barLines={2} editable pendingIds={pendingIds}
        onChangeOp={onChangeOp} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
      />
      <ProductionOrdersLegend colorMap={colorMap} title="Production Orders" />

      <InfoPopover anchorEl={infoAnchor} onClose={() => setInfoAnchor(null)} editable />
      <Snackbar open={Boolean(toast)} autoHideDuration={3500} onClose={() => setToast(null)} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        {toast ? <Alert severity={toast.severity} variant="filled" onClose={() => setToast(null)}>{toast.msg}</Alert> : undefined}
      </Snackbar>
    </Box>
  );
};

const Stat = ({ value, label, color }) => (
  <Box sx={{ mr: 5 }}>
    <Typography sx={{ fontSize: 26, lineHeight: 1.1, fontWeight: 400, color }}>{value}</Typography>
    <Typography sx={{ fontSize: 12, color: "#6b7280", mt: 0.25 }}>{label}</Typography>
  </Box>
);

export const PlannedSchedule = ({ data, loading, onRefresh }) => {
  const ctl = useGanttControls("weekly");
  const [machineSel, setMachineSel] = useState([]);
  const [poSel, setPoSel] = useState(null);

  const machines = useMemo(
    () => (data?.machines || []).slice().sort((a, b) => a.work_centre.localeCompare(b.work_centre) || a.machine_name.localeCompare(b.machine_name)),
    [data]
  );
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "planned"), [data]);
  const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);

  const selectedOps = useMemo(() => baseOps.filter((o) =>
    (!machineSel.length || machineSel.includes(o.machine_id)) && (!poSel || o.production_order === poSel)), [baseOps, machineSel, poSel]);
  const shownOps = useMemo(() => selectedOps.filter((o) => overlapsRange(o, ctl.range)), [selectedOps, ctl.range]);

  const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);
  const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);

  const stats = useMemo(() => ({
    operations: selectedOps.length,
    machines: new Set(selectedOps.map((o) => o.machine_id)).size,
    orders: new Set(selectedOps.map((o) => o.production_order)).size,
    hours: selectedOps.reduce((s, o) => s + (o.duration_hours ?? (o.end - o.start) / 3600e3), 0),
  }), [selectedOps]);

  const pickOrder = (po) => {
    setPoSel(po);
    const mine = baseOps.filter((o) => o.production_order === po);
    if (po && mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start)));
  };
  const clearFilters = () => { setMachineSel([]); setPoSel(null); ctl.resetControls(); };

  return (
    <Box>
      <Box sx={{ display: "flex", bgcolor: "#f6f8fb", borderRadius: "8px", px: 2, py: 1.5, mb: 2 }}>
        <Stat value={stats.operations} label="Operations" color="#1f6fe5" />
        <Stat value={stats.machines} label="Machines" color="#16a34a" />
        <Stat value={stats.orders} label="Production Orders" color="#f59e0b" />
        <Stat value={fmtHours(stats.hours)} label="Total Duration" color="#7c3aed" />
      </Box>

      <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 2 }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <MultiSelect placeholder="Select Machines" options={machines.map((m) => m.machine_id)} value={machineSel}
          onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
        <SingleSelect placeholder="Select Production Order" options={Object.keys(colorMap)} value={poSel} onChange={pickOrder} width={210} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
        <ClearFiltersButton onClick={clearFilters} />
        <RefreshButton onClick={onRefresh} loading={loading} />
      </Stack>

      <GanttTimeline
        machines={rows} ops={shownOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
        calendar={data?.calendar} colorMap={colorMap} barLines={1} showStatus={false} emptySuffix="(No Operations)"
        onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
      />
      <ProductionOrdersLegend colorMap={poSel ? { [poSel]: colorMap[poSel] } : colorMap} title="Production Orders Legend" />
    </Box>
  );
};

export const MachineOnlySchedule = ({ data, loading, onRefresh }) => {
  const ctl = useGanttControls("weekly");
  const machines = useMemo(() => (data?.machines || []).filter((m) => m.resource_type !== "MANUAL"), [data]);
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const machineIds = useMemo(() => new Set(machines.map((m) => m.machine_id)), [machines]);
  const filteredOps = useMemo(() => baseOps.filter((o) => machineIds.has(o.machine_id) && overlapsRange(o, ctl.range)), [baseOps, machineIds, ctl.range]);
  const colorMap = useMemo(() => buildColorMap(filteredOps), [filteredOps]);

  return (
    <Box>
      <Box sx={{ display: "flex", gap: 1.25, mb: 2, flexWrap: "wrap", alignItems: "center" }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
        <RefreshButton onClick={onRefresh} loading={loading} />
      </Box>
      <GanttTimeline machines={machines} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom} calendar={data?.calendar} colorMap={colorMap} barLines={2} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen} />
      <ProductionOrdersLegend colorMap={colorMap} title="Production Orders (Machine Work Only)" />
    </Box>
  );
};

export const ManualOnlySchedule = ({ data, loading, onRefresh }) => {
  const ctl = useGanttControls("weekly");
  const machines = useMemo(() => (data?.machines || []).filter((m) => m.resource_type === "MANUAL"), [data]);
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const machineIds = useMemo(() => new Set(machines.map((m) => m.machine_id)), [machines]);
  const filteredOps = useMemo(() => baseOps.filter((o) => machineIds.has(o.machine_id) && overlapsRange(o, ctl.range)), [baseOps, machineIds, ctl.range]);
  const colorMap = useMemo(() => buildColorMap(filteredOps), [filteredOps]);

  return (
    <Box>
      <Box sx={{ display: "flex", gap: 1.25, mb: 2, flexWrap: "wrap", alignItems: "center" }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
        <RefreshButton onClick={onRefresh} loading={loading} />
      </Box>
      <GanttTimeline machines={machines} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom} calendar={data?.calendar} colorMap={colorMap} barLines={2} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen} />
      <ProductionOrdersLegend colorMap={colorMap} title="Production Orders (Manual Work Only)" />
    </Box>
  );
};

export const OperatorSchedule = ({ data }) => {
  const ops = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const operators = useMemo(() => Array.from(new Set(ops.map((o) => o.operator_name))).sort(), [ops]);
  const [selectedOp, setSelectedOp] = useState(operators[0] || "");

  const myOps = useMemo(() => {
    return ops
      .filter((o) => o.operator_name === selectedOp)
      .sort((a, b) => a.start - b.start);
  }, [ops, selectedOp]);

  return (
    <Box>
      <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 2 }}>
        <Typography sx={{ fontWeight: 600, fontSize: 14 }}>Select Operator:</Typography>
        <SingleSelect placeholder="Select Operator" options={operators} value={selectedOp} onChange={setSelectedOp} width={240} />
      </Box>

      <TableContainer component={Paper} sx={{ border: `1px solid ${THEME.border}`, boxShadow: "none", borderRadius: "8px" }}>
        <Table size="small">
          <TableHead sx={{ bgcolor: "#f6f8fb" }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 600 }}>Sequence / Job</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Production Order</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Part Number</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Operation</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Machine / Work Centre</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Start Time</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>End Time</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {myOps.map((op, idx) => (
              <TableRow key={op.op_id} sx={{ bgcolor: idx === 0 ? "#eff6ff" : "inherit" }}>
                <TableCell sx={{ fontWeight: idx === 0 ? 700 : 400 }}>#{idx + 1} {idx === 0 ? "(First Job)" : ""}</TableCell>
                <TableCell>{op.production_order}</TableCell>
                <TableCell>{op.part_number}</TableCell>
                <TableCell>{op.operation_no} - {op.operation_name}</TableCell>
                <TableCell>{op.machine_id}</TableCell>
                <TableCell>{fmtDateTime(op.start)}</TableCell>
                <TableCell>{fmtDateTime(op.end)}</TableCell>
                <TableCell sx={{ fontWeight: 600, color: op.status === "IN_PROGRESS" ? "#2563eb" : op.status === "COMPLETED" ? "#16a34a" : "#d97706" }}>
                  {op.status}
                </TableCell>
              </TableRow>
            ))}
            {!myOps.length && (
              <TableRow>
                <TableCell colSpan={8} align="center" sx={{ py: 4, color: THEME.muted }}>No operations assigned to this operator.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export const ScheduleConfigPage = ({ apiBase, onChanged }) => {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  const loadConfig = () => {
    if (!apiBase) return;
    setLoading(true);
    axios.get(apiBase + API_ROUTES.config, { headers: getAuthHeaders() })
      .then((res) => setRows(res.data || []))
      .catch((err) => {
        setRows([]);
        setMessage({ severity: "error", text: "Could not load the config: " + (err.response?.data?.detail || err.message) });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadConfig(); }, [apiBase]);

  const setField = (stageId, field, value) => {
    setRows(rows.map((r) => (r.stage_id === stageId ? { ...r, [field]: value, changed: true } : r)));
  };

  const saveRow = (row) => {
    const body = {
      stage_id: row.stage_id,
      batch_size: Number(row.batch_size),
      next_day_release: Boolean(row.next_day_release),
      cooldown_minutes: Number(row.cooldown_minutes),
      cooldown_working_time_only: Boolean(row.cooldown_working_time_only),
      setup_minutes: Number(row.setup_minutes),
    };
    if (!Number.isInteger(body.batch_size) || body.batch_size < 1) {
      setMessage({ severity: "warning", text: `${row.stage_name}: batch size must be a whole number of 1 or more.` });
      return;
    }
    if (!(body.cooldown_minutes >= 0) || !(body.setup_minutes >= 0)) {
      setMessage({ severity: "warning", text: `${row.stage_name}: minutes cannot be negative.` });
      return;
    }
    axios.post(apiBase + API_ROUTES.config, body, { headers: getAuthHeaders() })
      .then(() => {
        setMessage({ severity: "success", text: `${row.stage_name} saved. The schedule is recalculated.` });
        loadConfig();
        if (onChanged) onChanged();
      })
      .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
  };

  const resetRow = (row) => {
    axios.delete(`${apiBase}${API_ROUTES.config}/${row.stage_id}`, { headers: getAuthHeaders() })
      .then(() => {
        setMessage({ severity: "success", text: `${row.stage_name} is back to the default values.` });
        loadConfig();
        if (onChanged) onChanged();
      })
      .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
  };

  const numberField = (row, field, disabled) => (
    <TextField size="small" type="number" value={row[field]} disabled={disabled} sx={{ width: 95 }}
      inputProps={{ min: field === "batch_size" ? 1 : 0, step: field === "batch_size" ? 1 : "any" }}
      onChange={(e) => setField(row.stage_id, field, e.target.value)} />
  );

  return (
    <Box>
      <Typography sx={{ fontSize: 13, color: "#6b7280", mb: 1.5 }}>
        Batch size and next-day release are used only for BATCH stages (process_type). Cooldown is the wait after
        a step before the next step of the same order can start; the machine is free for other orders meanwhile.
      </Typography>

      {message && (
        <Alert severity={message.severity} sx={{ mb: 1.5 }} onClose={() => setMessage(null)}>{message.text}</Alert>
      )}
      {loading && <LinearProgress sx={{ mb: 1 }} />}

      <TableContainer sx={{ border: "1px solid #e3e7ee", borderRadius: "8px" }}>
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { fontWeight: 600, bgcolor: "#f7f8fb" } }}>
              <TableCell>Stage</TableCell>
              <TableCell>Mode</TableCell>
              <TableCell>Batch size</TableCell>
              <TableCell>Next-day release</TableCell>
              <TableCell>Cooldown (min)</TableCell>
              <TableCell>Cooldown in working time only</TableCell>
              <TableCell>Setup (min)</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && !loading && (
              <TableRow><TableCell colSpan={8} sx={{ color: "#6b7280" }}>No stages found.</TableCell></TableRow>
            )}
            {rows.map((row) => {
              const isBatch = row.process_mode === "BATCH";
              return (
                <TableRow key={row.stage_id} sx={{ bgcolor: row.changed ? "#fffbeb" : "inherit" }}>
                  <TableCell>
                    {row.stage_name}
                    {row.is_default && <Chip label="default" size="small" sx={{ ml: 1, height: 20, fontSize: 11 }} />}
                  </TableCell>
                  <TableCell>{row.process_mode}</TableCell>
                  <TableCell>{numberField(row, "batch_size", !isBatch)}</TableCell>
                  <TableCell>
                    <Switch size="small" checked={Boolean(row.next_day_release)} disabled={!isBatch}
                      onChange={(e) => setField(row.stage_id, "next_day_release", e.target.checked)} />
                  </TableCell>
                  <TableCell>{numberField(row, "cooldown_minutes", false)}</TableCell>
                  <TableCell>
                    <Switch size="small" checked={Boolean(row.cooldown_working_time_only)}
                      onChange={(e) => setField(row.stage_id, "cooldown_working_time_only", e.target.checked)} />
                  </TableCell>
                  <TableCell>{numberField(row, "setup_minutes", false)}</TableCell>
                  <TableCell align="right" sx={{ whiteSpace: "nowrap" }}>
                    <Button size="small" variant="contained" onClick={() => saveRow(row)} sx={{ textTransform: "none", mr: 1 }}>
                      Save
                    </Button>
                    <Button size="small" onClick={() => resetRow(row)} disabled={row.is_default} sx={{ textTransform: "none" }}>
                      Reset
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

// ==========================================
// 7. MAIN CONTAINER PAGE
// ==========================================
export default function SchedulingPage() {
  const { data, loading, error, refresh, saveChanges, apiBase } = useScheduleData();
  const [tab, setTab] = useState(0);
  const [showWarnings, setShowWarnings] = useState(false);

  return (
    <Box sx={{ p: 3, bgcolor: "#f7f8fb", minHeight: "100%", fontFamily: (theme) => theme.typography.fontFamily }}>
      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", px: 2.5, py: 2, mb: 2.5, display: "flex", alignItems: "center", gap: 1.25, border: `1px solid ${THEME.border}` }}>
        <ScheduleIcon />
        <Typography sx={{ fontSize: 19, fontWeight: 500 }}>Production Schedule</Typography>
        {data?.generated_at && (
          <Typography sx={{ fontSize: 12, color: THEME.muted, ml: "auto" }}>
            Calculated {new Date(data.generated_at).toLocaleString("en-IN")}
          </Typography>
        )}
      </Box>

      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", border: `1px solid ${THEME.border}`, px: 2.5, pt: 1, pb: 2.5 }}>
        <Tabs value={tab} onChange={(e, v) => setTab(v)} sx={{ borderBottom: `1px solid ${THEME.border}`, mb: 2, "& .MuiTab-root": { textTransform: "none", fontSize: 14, minHeight: 44 } }}>
          <Tab label="Machine Schedule" />
          <Tab label="Planned Schedule" />
          <Tab label="Operator Login View" />
          <Tab label="Machine-Only" />
          <Tab label="Manual-Only" />
          <Tab label="Process Config" />
        </Tabs>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {data?.warnings?.length > 0 && (
          <Alert severity="warning" sx={{ mb: 2 }}
            action={<Button color="inherit" size="small" onClick={() => setShowWarnings(!showWarnings)}>{showWarnings ? "Hide" : "Show"}</Button>}>
            {data.warnings.length} scheduling warning(s)
            <Collapse in={showWarnings}>
              <Box component="ul" sx={{ m: 0, mt: 1, pl: 2.5, maxHeight: 200, overflow: "auto" }}>
                {data.warnings.map((w, i) => <li key={i}>{w}</li>)}
              </Box>
            </Collapse>
          </Alert>
        )}

        {loading && <LinearProgress sx={{ mb: 2 }} />}

        {tab === 0 && <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} />}
        {tab === 1 && <PlannedSchedule data={data} loading={loading} onRefresh={refresh} />}
        {tab === 2 && <OperatorSchedule data={data} />}
        {tab === 3 && <MachineOnlySchedule data={data} loading={loading} onRefresh={refresh} />}
        {tab === 4 && <ManualOnlySchedule data={data} loading={loading} onRefresh={refresh} />}
        {tab === 5 && <ScheduleConfigPage apiBase={apiBase} onChanged={refresh} />}
      </Box>
    </Box>
  );
}
