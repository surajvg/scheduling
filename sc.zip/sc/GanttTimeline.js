import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Box, IconButton, Typography } from "@mui/material";
import { ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon } from "@mui/icons-material";
import { DEFAULT_CALENDAR, LAYOUT, THEME, SNAP_MINUTES } from "./scheduleConfig";
import { buildScale, layoutRows, machineLabel, fmtDateTime, toLocalIso, parseTime } from "./scheduleUtils";

const navBtnSx = {
  position: "absolute", top: 4, zIndex: 8, width: 26, height: 26, bgcolor: "#fff",
  border: `1px solid ${THEME.border}`, borderRadius: "6px", color: THEME.primary,
  "&:hover": { bgcolor: "#f3f7ff" },
};

const HATCH = "repeating-linear-gradient(135deg, rgba(220,38,38,0.28) 0 5px, rgba(220,38,38,0.08) 5px 10px)";
const STRIPES = "repeating-linear-gradient(135deg, rgba(255,255,255,0.4) 0 4px, transparent 4px 8px)";

const TooltipRow = ({ k, v, color }) => (
  <Box sx={{ display: "flex", gap: 0.5, lineHeight: 1.45 }}>
    <Box component="span" sx={{ color: THEME.muted, whiteSpace: "nowrap" }}>{k}:</Box>
    <Box component="span" sx={{ color: color || THEME.text, fontWeight: 500 }}>{v}</Box>
  </Box>
);

/**
 * Generic resource-row Gantt (machines AND operators of manual steps).
 *  machines : [{ machine_id, work_centre, machine_name, resource_type, interlock_status }]  one row each
 *  ops      : [{ op_id, machine_id, start, end (ms), segments [[ms, ms]], production_order, batch_no, batch_count, ... }]
 *             = one entry per series operation and one per batch of a batch operation
 *  blocks   : data.interlocks entries with severity BLOCK (drawn as red hatched time ranges on the resource row)
 *  barLines : 2 -> "PO / part - operation" (Machine Schedule), 1 -> "PO" (Planned Schedule)
 */
const GanttTimeline = ({
  machines, ops, view, range, zoom, calendar, colorMap, barLines = 2, blocks = [],
  emptySuffix = "", editable = false, showStatus = true, pendingIds, onChangeOp, onNavigate, fsRef, isFullscreen,
}) => {
  const scrollRef = useRef(null);
  const bodyRef = useRef(null);
  const [width, setWidth] = useState(0);
  const [tip, setTip] = useState(null);   // { x, y, op }
  const [drag, setDrag] = useState(null); // { op, ghost }
  const [now, setNow] = useState(Date.now());

  /* available width -> chart stretches to fill the card at zoom 1 */
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return undefined;
    const measure = () => setWidth(Math.max(0, el.clientWidth - LAYOUT.labelWidth));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);

  const scale = useMemo(
    () => buildScale({ view, range, zoom, calendar, availableWidth: width }),
    [view, range, zoom, calendar, width]
  );

  const visibleOps = useMemo(() => (drag ? ops.filter((o) => o.op_id !== drag.op.op_id) : ops), [ops, drag]);
  const rows = useMemo(() => layoutRows(machines, visibleOps, scale, barLines), [machines, visibleOps, scale, barLines]);
  const rowsRef = useRef(rows); rowsRef.current = rows;
  const scaleRef = useRef(scale); scaleRef.current = scale;

  /* interlock windows per resource row -> pixel rectangles */
  const blockRects = useMemo(() => {
    const out = {};
    (blocks || []).forEach((b) => {
      if (!b.start_time) return;
      const s = Math.max(parseTime(b.start_time), range.start);
      const e = Math.min(b.end_time ? parseTime(b.end_time) : range.end, range.end);
      if (!(e > s)) return;
      const x = scale.toX(s);
      (out[b.resource_id] = out[b.resource_id] || []).push({ x, w: Math.max(scale.toX(e) - x, 3), msg: b.message });
    });
    return out;
  }, [blocks, range, scale]);

  const bodyHeight = rows.reduce((s, r) => s + r.height, 0);
  // the red "now" line is hidden while "now" is outside the working window of a windowed (daily/weekly) view
  const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
  const nowD = new Date(now);
  const nowHour = nowD.getHours() + nowD.getMinutes() / 60;
  const nowVisible = now >= range.start && now < range.end && (!scale.windowed || (nowHour >= cal.shift_start && nowHour < cal.shift_end));
  const nowX = nowVisible ? scale.toX(now) : null;
  const headerH = LAYOUT.headerRow1 + LAYOUT.headerRow2;

  /* ---------- drag to re-schedule (Machine Schedule only) ---------- */
  const startDrag = useCallback((e, bar) => {
    if (!editable || e.button !== 0) return;
    e.preventDefault();
    setTip(null);
    const startX = e.clientX;
    const op = bar.op;
    const duration = op.end - op.start;
    const snap = SNAP_MINUTES * 60000;
    let moved = false;
    let last = null;

    const compute = (ev) => {
      const sc = scaleRef.current;
      const dx = ev.clientX - startX;
      const yRel = ev.clientY - bodyRef.current.getBoundingClientRect().top;
      const target = rowsRef.current.find((r) => yRel >= r.top && yRel < r.top + r.height)
        || rowsRef.current.find((r) => r.machine.machine_id === op.machine_id);
      const start = Math.round(sc.toTime(bar.x + dx) / snap) * snap;
      const end = start + duration;
      const x = sc.toX(start);
      return {
        op, start, end, machine_id: target.machine.machine_id,
        ghost: { x, w: Math.max(sc.toX(end) - x, 3), top: target.top + LAYOUT.barPad, h: bar.h },
      };
    };
    const onMove = (ev) => {
      if (Math.abs(ev.clientX - startX) > 3 || moved) moved = true;
      if (!moved) return;
      last = compute(ev);
      setDrag(last);
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      setDrag(null);
      if (moved && last && (last.start !== op.start || last.machine_id !== op.machine_id)) {
        onChangeOp?.(op, { machine_id: last.machine_id, start_time: toLocalIso(last.start), end_time: toLocalIso(last.end) });
      }
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }, [editable, onChangeOp]);

  /* ---------- tooltip ---------- */
  const showTip = (e, op) => { if (!drag) setTip({ x: e.clientX, y: e.clientY, op }); };
  const machineById = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, m])), [machines]);

  const renderTip = () => {
    if (!tip) return null;
    const { op } = tip;
    const m = machineById[op.machine_id];
    const qtyWord = op.status === "COMPLETED" ? "Completed" : op.status === "IN_PROGRESS" ? "Process" : "Scheduled";
    const isBatch = op.process_mode === "BATCH";
    const vw = typeof window !== "undefined" ? window.innerWidth : 1400;
    const left = tip.x + 320 > vw ? tip.x - 310 : tip.x + 14;
    const resKind = m?.resource_type === "MANUAL" ? "Manual" : m?.resource_type === "FALLBACK" ? "Unassigned" : "";
    return (
      <Box sx={{
        position: "fixed", left, top: tip.y + 14, zIndex: 3000, bgcolor: "#fff", border: `1px solid ${THEME.border}`,
        borderRadius: "6px", boxShadow: "0 4px 18px rgba(15,23,42,0.18)", px: 1.25, py: 0.75, fontSize: 12.5,
        pointerEvents: "none", minWidth: 250, maxWidth: 310,
      }}>
        <TooltipRow k="Part Number" v={op.part_number} />
        <TooltipRow k={m?.resource_type === "MANUAL" ? "Operator" : "Machine"} v={m ? machineLabel(m) : op.machine_id} />
        <TooltipRow k="Production Order" v={op.production_order} />
        <TooltipRow k="Operation" v={`${op.operation_no} - ${op.operation_name}`} />
        <TooltipRow k="Quantity" v={`${qtyWord}(${op.completed_qty}/${op.quantity}pcs)`} />
        {isBatch && op.batch_count > 0 && (
          <TooltipRow k="Batch" v={`${op.batch_no} of ${op.batch_count} - ${op.batch_qty} pcs (max ${op.batch_size})`} />
        )}
        <TooltipRow k="Mode" v={`${isBatch ? "Batch" : "Series"}${resKind ? ` (${resKind})` : ""}`} />
        <TooltipRow k="Operator" v={op.operator_name || "-"} />
        <TooltipRow k="Start" v={fmtDateTime(op.start)} />
        <TooltipRow k="End" v={fmtDateTime(op.end)} />
        <TooltipRow k="Working time" v={`${op.duration_hours} h${op.setup_minutes ? ` (incl. ${op.setup_minutes} min setup)` : ""}`} />
        <TooltipRow k="PDC of Operation" v={fmtDateTime(op.pdc)} />
        {op.waiting_reason ? <TooltipRow k="Waiting" v={op.waiting_reason} color="#b45309" /> : null}
        {op.interlock_blocked && (
          <Box sx={{ mt: 0.5, color: THEME.danger, fontWeight: 600 }}>
            Provisional - every resource is interlocked
            {(op.interlock_reasons || []).map((r, i) => <Box key={i} sx={{ fontWeight: 400 }}>• {r}</Box>)}
          </Box>
        )}
        {(op.conflicts || []).map((c, i) => <Box key={i} sx={{ mt: 0.25, color: THEME.danger }}>⚠ {c}</Box>)}
        {op.pinned && <Box sx={{ mt: 0.5, color: THEME.muted }}>Moved manually (other work is planned around it)</Box>}
        {pendingIds?.has(op.op_id) && <Box sx={{ mt: 0.5, color: "#b45309", fontWeight: 600 }}>Modified - press Update to save</Box>}
      </Box>
    );
  };

  const renderBar = (bar, row) => {
    const { op, x, w, lane, pieces } = bar;
    const color = colorMap[op.production_order] || THEME.primary;
    const h = row.laneH - 4;
    const top = LAYOUT.barPad + lane * row.laneH;
    const pending = pendingIds?.has(op.op_id);
    const fadedOut = showStatus && op.status === "COMPLETED";
    const hasConflict = (op.conflicts || []).length > 0;
    const widest = Math.max(...pieces.map((p) => p.w));
    let textDone = false;
    const label = `${op.production_order}${op.batch_count > 1 ? ` · B${op.batch_no}/${op.batch_count}` : ""}`;

    return (
      <React.Fragment key={op.op_id}>
        {/* thin dashed line joins the pieces of one task across breaks / nights / days off */}
        {pieces.length > 1 && (
          <Box sx={{ position: "absolute", left: x, width: w, top: top + h / 2, borderTop: `2px dashed ${color}`,
            opacity: 0.5, pointerEvents: "none", zIndex: 0 }} />
        )}
        {pieces.map((p, i) => {
          const showText = !textDone && p.w === widest;
          if (showText) textDone = true;
          return (
            <Box
              key={i}
              onPointerDown={(e) => startDrag(e, { ...bar, h })}
              onMouseEnter={(e) => showTip(e, op)}
              onMouseMove={(e) => showTip(e, op)}
              onMouseLeave={() => setTip(null)}
              sx={{
                position: "absolute", left: p.x, top, width: p.w, height: h, zIndex: 1,
                bgcolor: color, color: "#fff", borderRadius: "3px", px: p.w > 14 ? 0.5 : 0, overflow: "hidden",
                backgroundImage: op.interlock_blocked ? STRIPES : "none",
                fontSize: 11, lineHeight: 1.25, display: "flex", flexDirection: "column", justifyContent: "center",
                opacity: fadedOut ? 0.55 : 1, cursor: editable ? "grab" : "default", userSelect: "none",
                boxShadow: showStatus && op.status === "IN_PROGRESS" ? `inset 0 0 0 1.5px #fff, 0 0 0 1px ${color}` : "none",
                outline: pending ? "2px dashed #f59e0b" : (hasConflict || op.interlock_blocked) ? `2px solid ${THEME.danger}` : "none",
                outlineOffset: 1,
                borderRight: "1px solid rgba(255,255,255,0.55)",
                "&:hover": { filter: "brightness(1.08)" },
              }}
            >
              {showText && p.w > 18 && (
                <>
                  <Box sx={{ fontWeight: 600, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>{label}</Box>
                  {barLines === 2 && (
                    <Box sx={{ whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden", opacity: 0.95 }}>
                      {op.part_number} - {op.operation_name}
                    </Box>
                  )}
                </>
              )}
            </Box>
          );
        })}
      </React.Fragment>
    );
  };

  const cssFullscreen = isFullscreen && typeof document !== "undefined" && !document.fullscreenElement;
  const statusDot = (m) => m.interlock_status === "BLOCKED" ? THEME.danger : m.interlock_status === "WARN" ? THEME.warn : null;

  return (
    <Box
      ref={fsRef}
      sx={{
        position: cssFullscreen ? "fixed" : "relative", inset: cssFullscreen ? 0 : "auto", zIndex: cssFullscreen ? 1400 : "auto",
        bgcolor: "#fff", border: `1px solid ${THEME.border}`, borderRadius: "10px", p: isFullscreen ? 1.5 : 0.5,
        boxSizing: "border-box", height: isFullscreen ? "100%" : "auto",
      }}
    >
      <Box sx={{ position: "relative" }}>
        <IconButton aria-label="Previous period" onClick={() => onNavigate(-1)} sx={{ ...navBtnSx, left: 8 }}><ChevronLeftIcon fontSize="small" /></IconButton>
        <IconButton aria-label="Next period" onClick={() => onNavigate(1)} sx={{ ...navBtnSx, right: 10 }}><ChevronRightIcon fontSize="small" /></IconButton>

        <Box ref={scrollRef} sx={{ overflow: "auto", maxHeight: isFullscreen ? "calc(100vh - 36px)" : 560 }}>
          <Box sx={{ width: LAYOUT.labelWidth + scale.totalWidth, minWidth: "100%", position: "relative", isolation: "isolate" }}>

            {/* ---------- header ---------- */}
            <Box sx={{ position: "sticky", top: 0, zIndex: 6, display: "flex", bgcolor: "#fff", height: headerH, borderBottom: `1px solid ${THEME.gridStrong}` }}>
              <Box sx={{ position: "sticky", left: 0, zIndex: 7, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff", borderRight: `1px solid ${THEME.gridStrong}` }} />
              <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                {scale.row1.map((c, i) => (
                  <Box key={`r1-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: 0, height: LAYOUT.headerRow1, borderLeft: `1px solid ${THEME.gridStrong}`, px: 0.5, display: "flex", alignItems: "center", fontSize: 13, fontWeight: 500, color: THEME.text, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}
                  </Box>
                ))}
                {scale.row2.map((c, i) => (
                  <Box key={`r2-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: LAYOUT.headerRow1, height: LAYOUT.headerRow2, borderLeft: `1px solid ${THEME.gridSoft}`, px: 0.5, display: "flex", alignItems: "center", gap: 0.4, fontSize: 12, color: THEME.muted, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}{c.sub && c.w > 30 ? <Box component="span" sx={{ fontSize: 9, opacity: 0.7 }}>{c.sub}</Box> : null}
                  </Box>
                ))}
              </Box>
            </Box>

            {/* ---------- body ---------- */}
            <Box ref={bodyRef} sx={{ position: "relative", minHeight: 160 }}>
              {/* grid + non-working days / hours between shifts (under the bars) */}
              <Box sx={{ position: "absolute", left: LAYOUT.labelWidth, top: 0, width: scale.totalWidth, height: Math.max(bodyHeight, 160), zIndex: 0, pointerEvents: "none" }}>
                {scale.offDays.map((d, i) => <Box key={`off-${i}`} sx={{ position: "absolute", left: d.x, width: d.w, top: 0, bottom: 0, bgcolor: THEME.offDay }} />)}
                {(scale.offHours || []).map((d, i) => <Box key={`oh-${i}`} sx={{ position: "absolute", left: d.x, width: d.w, top: 0, bottom: 0, bgcolor: THEME.offHour }} />)}
                {scale.grid.map((g, i) => <Box key={`g-${i}`} sx={{ position: "absolute", left: g.x, top: 0, bottom: 0, width: "1px", bgcolor: g.strong ? THEME.gridStrong : THEME.gridSoft }} />)}
              </Box>
              {/* "now" line (over the bars) */}
              {nowX !== null && (
                <Box sx={{ position: "absolute", left: LAYOUT.labelWidth + nowX, top: 0, height: Math.max(bodyHeight, 160), width: "2px", bgcolor: THEME.nowLine, zIndex: 2, pointerEvents: "none" }} />
              )}

              {rows.length === 0 && (
                <Typography sx={{ position: "sticky", left: LAYOUT.labelWidth, p: 3, color: THEME.muted, fontSize: 13 }}>No machines to display.</Typography>
              )}

              {rows.map((row) => {
                const dot = statusDot(row.machine);
                return (
                  <Box key={row.machine.machine_id} sx={{ display: "flex", height: row.height, borderBottom: `1px solid ${THEME.gridSoft}` }}>
                    <Box title={`${machineLabel(row.machine)}${row.machine.interlock_status && row.machine.interlock_status !== "OK" ? ` - interlock: ${row.machine.interlock_status}` : ""}`} sx={{
                      position: "sticky", left: 0, zIndex: 3, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff",
                      borderRight: `1px solid ${THEME.gridStrong}`, px: 1, pt: row.bars.length ? 0.6 : 0, display: "flex",
                      alignItems: row.bars.length ? "flex-start" : "center", gap: 0.6, fontSize: 11.5, color: THEME.text,
                      fontWeight: row.bars.length ? 600 : 400, fontStyle: row.machine.resource_type === "MANUAL" ? "italic" : "normal",
                      whiteSpace: "nowrap", overflow: "hidden",
                    }}>
                      {dot && <Box component="span" sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: dot, flex: "none", mt: row.bars.length ? "4px" : 0 }} />}
                      <Box component="span" sx={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                        {machineLabel(row.machine)}{!row.bars.length && emptySuffix ? ` ${emptySuffix}` : ""}
                      </Box>
                    </Box>
                    <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                      {/* interlock windows (breakdown, maintenance, spare / consumable out of stock) */}
                      {(blockRects[row.machine.machine_id] || []).map((b, i) => (
                        <Box key={`blk-${i}`} title={`Interlock: ${b.msg}`} sx={{ position: "absolute", left: b.x, width: b.w, top: 0, bottom: 0, backgroundImage: HATCH, zIndex: 0 }} />
                      ))}
                      {row.bars.map((bar) => renderBar(bar, row))}
                    </Box>
                  </Box>
                );
              })}

              {/* ghost while dragging */}
              {drag && (
                <Box sx={{
                  position: "absolute", left: LAYOUT.labelWidth + drag.ghost.x, top: drag.ghost.top, width: drag.ghost.w, height: drag.ghost.h,
                  bgcolor: colorMap[drag.op.production_order] || THEME.primary, opacity: 0.85, borderRadius: "3px", zIndex: 5,
                  outline: "2px dashed #f59e0b", pointerEvents: "none", color: "#fff", fontSize: 11, px: 0.5, display: "flex", alignItems: "center",
                  whiteSpace: "nowrap", overflow: "hidden",
                }}>
                  {drag.op.production_order} · {new Date(drag.start).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                </Box>
              )}
            </Box>
          </Box>
        </Box>
      </Box>
      {renderTip()}
    </Box>
  );
};

export default GanttTimeline;
