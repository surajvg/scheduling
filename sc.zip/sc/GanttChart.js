import React, { useEffect, useRef, useState } from "react";
import { Box, IconButton, Tooltip, Typography } from "@mui/material";
import {
  ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon,
  ExpandMore as ExpandMoreIcon, ChevronRight as CollapsedIcon,
} from "@mui/icons-material";

const LABEL_WIDTH = 240;   // machine names column
const HEADER_HEIGHT = 30;
const LANE_HEIGHT = 34;    // one bar line inside a machine row
const GROUP_HEIGHT = 28;   // "Machines" / "Operators" header
const SUB_HEIGHT = 24;     // stage / station header inside a group
const COLLAPSE_KEY = "gantt.collapsedGroups";

// rows are grouped: Machines (per stage) -> Operators (per manual station) -> Unassigned.
// Uses machine.group / machine.subgroup from /schedule/data; falls back to resource_type / work_centre.
const GROUPS = {
  MACHINES: { order: 0, label: "Machines" },
  OPERATORS: { order: 1, label: "Operators (manual stations)" },
  UNASSIGNED: { order: 2, label: "No machine / operator" },
};
function groupOf(m) {
  if (m.group && GROUPS[m.group]) return m.group;
  if (m.resource_type === "MANUAL") return "OPERATORS";
  if (m.resource_type === "FALLBACK") return "UNASSIGNED";
  return "MACHINES";
}
function subgroupOf(m) {
  return m.subgroup || m.work_centre || "Other";
}
function loadCollapsed() {
  try { return JSON.parse(window.localStorage.getItem(COLLAPSE_KEY) || "{}") || {}; } catch (e) { return {}; }
}
function saveCollapsed(v) {
  try { window.localStorage.setItem(COLLAPSE_KEY, JSON.stringify(v)); } catch (e) { /* storage blocked: keep in memory */ }
}
const DAY = 86400000;

function fmt(d) {
  return d ? d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false }) : "-";
}

function machineLabel(m) {
  if (m.resource_type === "MANUAL") return m.machine_name || m.machine_id;    // operator: show the person
  return m.machine_name && m.machine_name !== m.machine_id ? `${m.machine_id} - ${m.machine_name}` : m.machine_id;
}

const ENTRY_TEXT = { HISTORY: "Done (logged serials)", REMAINING: "Remaining work", PLAN: "Planned" };

/**
 * Plain-div Gantt chart.
 *  machines : data.machines (one row each)
 *  bars     : [{ op, machine_id, start: Date, end: Date, segments: [{ start: Date, end: Date }] }]
 *             (op = one entry of data.operations, segments = its working pieces)
 *  holidays : data.calendar.holidays,  halfDays : data.calendar.half_days
 */
const GanttChart = ({ machines, bars, rangeStart, rangeEnd, zoom, holidays, halfDays, poColor, onBarClick, onPrev, onNext }) => {
  const boxRef = useRef(null);
  const [boxWidth, setBoxWidth] = useState(1000);
  const [now, setNow] = useState(new Date());
  const [collapsed, setCollapsed] = useState(loadCollapsed);
  const toggle = (key) => setCollapsed((c) => {
    const next = { ...c, [key]: !c[key] };
    if (!next[key]) delete next[key];
    saveCollapsed(next);
    return next;
  });

  // measure the available width once and on window resize; move the red "now" line every minute
  useEffect(() => {
    const measure = () => { if (boxRef.current) setBoxWidth(boxRef.current.clientWidth); };
    measure();
    window.addEventListener("resize", measure);
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => { window.removeEventListener("resize", measure); clearInterval(timer); };
  }, []);

  // x = (time - rangeStart) / (rangeEnd - rangeStart) * width
  const width = Math.max(300, (boxWidth - LABEL_WIDTH - 20) * zoom);
  const startMs = rangeStart.getTime();
  const endMs = rangeEnd.getTime();
  const xOf = (time) => ((new Date(time).getTime() - startMs) / (endMs - startMs)) * width;

  // ---- header: hours (range up to 2 days), days (up to 62 days) or months ----
  const span = endMs - startMs;
  const unit = span <= 2 * DAY ? "hour" : span <= 62 * DAY ? "day" : "month";
  const ticks = [];
  let t = new Date(rangeStart);
  while (t < rangeEnd) {
    const next = new Date(t);
    if (unit === "hour") next.setHours(next.getHours() + 1);
    if (unit === "day") next.setDate(next.getDate() + 1);
    if (unit === "month") next.setMonth(next.getMonth() + 1, 1);
    const x = xOf(t);
    const w = xOf(next < rangeEnd ? next : rangeEnd) - x;
    let label = "";
    if (unit === "hour") label = w > 22 ? String(t.getHours()).padStart(2, "0") : "";
    if (unit === "day") label = w > 70 ? t.toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short" }) : w > 18 ? String(t.getDate()) : "";
    if (unit === "month") label = w > 55 ? t.toLocaleDateString("en-IN", { month: "short", year: "numeric" }) : w > 25 ? t.toLocaleDateString("en-IN", { month: "short" }) : "";
    ticks.push({ x, w, label, key: t.getTime() });
    t = next;
  }

  // ---- shaded days: data.calendar.holidays (full) and data.calendar.half_days (light) ----
  const dayShades = [];
  holidays.forEach((h) => {
    const day = new Date(h.holiday_date + "T00:00:00");
    if (day.getTime() + DAY > startMs && day.getTime() < endMs) {
      dayShades.push({ key: "h" + h.holiday_date, x: xOf(day), w: xOf(day.getTime() + DAY) - xOf(day), title: h.name, color: "rgba(100,116,139,0.13)" });
    }
  });
  halfDays.forEach((d) => {
    const day = new Date(d + "T00:00:00");
    if (day.getTime() + DAY > startMs && day.getTime() < endMs) {
      dayShades.push({ key: "s" + d, x: xOf(day), w: xOf(day.getTime() + DAY) - xOf(day), title: "Half day", color: "rgba(245,158,11,0.08)" });
    }
  });

  // ---- rows: one per machine; bars that overlap on one machine are stacked in extra lanes ----
  const rows = machines.map((m) => {
    const mine = bars
      .filter((b) => b.machine_id === m.machine_id && b.end >= rangeStart && b.start < rangeEnd)
      .sort((a, b) => a.start - b.start);
    const laneEnds = [];                 // end time of the last bar in each lane
    const placed = mine.map((b) => {
      let lane = laneEnds.findIndex((end) => end <= b.start);
      if (lane === -1) {
        lane = laneEnds.length;
        laneEnds.push(b.end);
      } else {
        laneEnds[lane] = b.end;
      }
      return { ...b, lane };
    });
    return { machine: m, bars: placed, height: Math.max(1, laneEnds.length) * LANE_HEIGHT + 6 };
  });

  // ---- group the rows: group header -> subgroup header -> machine rows (server order kept inside a group) ----
  const grouped = [];
  rows
    .map((row, i) => ({ row, i, g: groupOf(row.machine), s: subgroupOf(row.machine) }))
    .sort((a, b) => GROUPS[a.g].order - GROUPS[b.g].order || a.i - b.i)
    .forEach((x) => {
      let g = grouped[grouped.length - 1];
      if (!g || g.key !== x.g) {
        g = { key: x.g, label: GROUPS[x.g].label, subs: [] };
        grouped.push(g);
      }
      let sub = g.subs.find((sg) => sg.label === x.s);
      if (!sub) {
        sub = { key: `${x.g}|${x.s}`, label: x.s, rows: [] };
        g.subs.push(sub);
      }
      sub.rows.push(x.row);
    });
  const busyCount = (rowsOf) => rowsOf.reduce((n, r) => n + r.bars.length, 0);

  const showNow = now >= rangeStart && now < rangeEnd;

  // tooltip content = fields of one data.operations entry
  const tooltip = (bar) => {
    const op = bar.op;
    const line = (k, v) => (
      <Box sx={{ display: "flex", gap: 0.5 }}>
        <span style={{ opacity: 0.75 }}>{k}:</span><b>{v === null || v === undefined || v === "" ? "-" : v}</b>
      </Box>
    );
    return (
      <Box sx={{ fontSize: 12, lineHeight: 1.5 }}>
        {line("Part Number", op.part_number)}
        {line("Machine", bar.machine_id)}
        {line("Production Order", op.production_order)}
        {line("Operation", `${op.operation_no} - ${op.step_name}`)}
        {line("Quantity", `${op.completed_qty}/${op.quantity} pcs done (${op.status})`)}
        {op.entry_type && line("Bar", `${ENTRY_TEXT[op.entry_type] || op.entry_type}${op.entry_type === "HISTORY" && op.serial_count ? ` - ${op.serial_count} serial(s)` : ""}${op.remaining_kind === "WAITING" ? " - waiting for PCBs" : ""}`)}
        {line("Mode", op.process_mode === "BATCH" ? `Batch (${op.batch_count} x ${op.batch_size})` : "Series")}
        {line("Operator", op.operator_name)}
        {line("Start", fmt(bar.start))}
        {line("End", fmt(bar.end))}
        {line("PDC", fmt(new Date(op.planned_end)))}
        {op.cooldown_until && line("Cooldown until", fmt(new Date(op.cooldown_until)))}
        {line("Waiting reason", op.waiting_reason)}
      </Box>
    );
  };

  return (
    <Box sx={{ fontFamily: (theme) => theme.typography.fontFamily }}>
      {/* prev / next period */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 0.5 }}>
        <IconButton size="small" onClick={onPrev}><ChevronLeftIcon /></IconButton>
        <Typography sx={{ fontSize: 13, fontWeight: 600 }}>
          {rangeStart.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
          {" – "}
          {new Date(endMs - 1).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
        </Typography>
        <IconButton size="small" onClick={onNext}><ChevronRightIcon /></IconButton>
      </Box>

      <Box ref={boxRef} sx={{ overflow: "auto", maxHeight: 620, border: "1px solid #e3e7ee", borderRadius: "8px" }}>
        <Box sx={{ width: LABEL_WIDTH + width, position: "relative" }}>

          {/* header row */}
          <Box sx={{ display: "flex", position: "sticky", top: 0, zIndex: 4, bgcolor: "#fff", height: HEADER_HEIGHT, borderBottom: "1px solid #c9d0da" }}>
            <Box sx={{ width: LABEL_WIDTH, boxSizing: "border-box", flex: "none", position: "sticky", left: 0, zIndex: 5, bgcolor: "#fff", borderRight: "1px solid #c9d0da", px: 1, display: "flex", alignItems: "center", fontSize: 12, fontWeight: 600 }}>
              Machine / Operator
            </Box>
            <Box sx={{ position: "relative", width, flex: "none" }}>
              {ticks.map((tk) => (
                <Box key={tk.key} sx={{ position: "absolute", left: tk.x, width: tk.w, top: 0, bottom: 0, borderLeft: "1px solid #eceff4", fontSize: 11, color: "#4b5563", display: "flex", alignItems: "center", pl: 0.5, overflow: "hidden", whiteSpace: "nowrap" }}>
                  {tk.label}
                </Box>
              ))}
            </Box>
          </Box>

          {/* body */}
          <Box sx={{ position: "relative" }}>
            {/* background: grid lines, shaded days and the red "now" line */}
            <Box sx={{ position: "absolute", left: LABEL_WIDTH, top: 0, bottom: 0, width, pointerEvents: "none" }}>
              {dayShades.map((s) => (
                <Box key={s.key} title={s.title} sx={{ position: "absolute", left: s.x, width: s.w, top: 0, bottom: 0, bgcolor: s.color }} />
              ))}
              {ticks.map((tk) => (
                <Box key={tk.key} sx={{ position: "absolute", left: tk.x, top: 0, bottom: 0, width: "1px", bgcolor: "#eceff4" }} />
              ))}
              {showNow && (
                <Box sx={{ position: "absolute", left: xOf(now), top: 0, bottom: 0, width: "2px", bgcolor: "#ef4444", zIndex: 2 }} />
              )}
            </Box>

            {rows.length === 0 && (
              <Typography sx={{ p: 3, color: "#6b7280", fontSize: 13 }}>No machines to display.</Typography>
            )}

            {grouped.map((g) => (
              <React.Fragment key={g.key}>
                {/* group header: Machines / Operators / Unassigned */}
                <Box onClick={() => toggle(`g:${g.key}`)} sx={{ display: "flex", height: GROUP_HEIGHT, cursor: "pointer",
                  bgcolor: "rgba(226,232,240,0.55)", borderBottom: "1px solid #c9d0da", position: "relative", zIndex: 3 }}>
                  <Box sx={{ width: LABEL_WIDTH, boxSizing: "border-box", flex: "none", position: "sticky", left: 0, bgcolor: "#eef2f7",
                    borderRight: "1px solid #c9d0da", px: 0.5, display: "flex", alignItems: "center", gap: 0.5,
                    fontSize: 12.5, fontWeight: 700, color: "#1f2937", whiteSpace: "nowrap", overflow: "hidden" }}>
                    {collapsed[`g:${g.key}`] ? <CollapsedIcon sx={{ fontSize: 18 }} /> : <ExpandMoreIcon sx={{ fontSize: 18 }} />}
                    <span>{g.label}</span>
                    <span style={{ color: "#6b7280", fontWeight: 500 }}>({g.subs.reduce((n, sg) => n + sg.rows.length, 0)})</span>
                  </Box>
                  <Box sx={{ width, flex: "none" }} />
                </Box>

                {!collapsed[`g:${g.key}`] && g.subs.map((sg) => (
                  <React.Fragment key={sg.key}>
                    {/* subgroup header: stage (machines) or station (operators) */}
                    <Box onClick={() => toggle(`s:${sg.key}`)} sx={{ display: "flex", height: SUB_HEIGHT, cursor: "pointer",
                      bgcolor: "rgba(241,245,249,0.5)", borderBottom: "1px solid #eceff4", position: "relative", zIndex: 3 }}>
                      <Box title={sg.label} sx={{ width: LABEL_WIDTH, boxSizing: "border-box", flex: "none", position: "sticky", left: 0,
                        bgcolor: "#f8fafc", borderRight: "1px solid #c9d0da", pl: 2, pr: 0.5, display: "flex", alignItems: "center",
                        gap: 0.5, fontSize: 11.5, fontWeight: 600, color: "#374151", whiteSpace: "nowrap", overflow: "hidden" }}>
                        {collapsed[`s:${sg.key}`] ? <CollapsedIcon sx={{ fontSize: 16 }} /> : <ExpandMoreIcon sx={{ fontSize: 16 }} />}
                        <Box component="span" sx={{ overflow: "hidden", textOverflow: "ellipsis" }}>{sg.label}</Box>
                        <span style={{ color: "#6b7280", fontWeight: 500, flex: "none" }}>
                          ({sg.rows.length}{collapsed[`s:${sg.key}`] ? ` · ${busyCount(sg.rows)} bars` : ""})
                        </span>
                      </Box>
                      <Box sx={{ width, flex: "none" }} />
                    </Box>

                    {!collapsed[`s:${sg.key}`] && sg.rows.map((row) => (
              <Box key={row.machine.machine_id} sx={{ display: "flex", height: row.height, borderBottom: "1px solid #eceff4" }}>
                <Box title={machineLabel(row.machine)} sx={{
                  width: LABEL_WIDTH, boxSizing: "border-box", flex: "none", position: "sticky", left: 0, zIndex: 3, bgcolor: "#fff",
                  borderRight: "1px solid #c9d0da", pl: 3.5, pr: 1, display: "flex", flexDirection: "column", justifyContent: "center",
                  fontSize: 12, overflow: "hidden", whiteSpace: "nowrap",
                  fontStyle: row.machine.resource_type === "MANUAL" ? "italic" : "normal",
                }}>
                  <Box sx={{ fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis" }}>{machineLabel(row.machine)}</Box>
                  <Box sx={{ color: "#6b7280", fontSize: 11, overflow: "hidden", textOverflow: "ellipsis" }}>
                    {row.machine.resource_type === "MANUAL"
                      ? `Operator · ${String(row.machine.machine_id).replace(/^OP-/, "")}`
                      : row.machine.work_centre !== subgroupOf(row.machine) ? row.machine.work_centre : ""}
                  </Box>
                </Box>

                <Box sx={{ position: "relative", width, flex: "none" }}>
                  {row.bars.map((bar) => {
                    const color = poColor[bar.op.production_order] || "#1f6fe5";
                    const top = 3 + bar.lane * LANE_HEIGHT;
                    // working pieces (bar.segments) - nothing is drawn over nights / Sundays / holidays
                    const pieces = bar.segments
                      .filter((sg) => sg.end > rangeStart && sg.start < rangeEnd)
                      .map((sg) => {
                        const x = Math.max(0, xOf(sg.start));
                        return { x, w: Math.max(3, Math.min(width, xOf(sg.end)) - x) };
                      });
                    const widest = Math.max(0, ...pieces.map((p) => p.w));
                    const lineX = Math.max(0, xOf(bar.start));
                    const lineW = Math.min(width, xOf(bar.end)) - lineX;
                    return (
                      <React.Fragment key={bar.op.op_id}>
                        {/* thin dashed line joins the pieces of one operation across days off */}
                        {pieces.length > 1 && (
                          <Box sx={{ position: "absolute", left: lineX, width: lineW, top: top + (LANE_HEIGHT - 4) / 2,
                            borderTop: `2px dashed ${color}`, opacity: 0.6, pointerEvents: "none" }} />
                        )}
                        {pieces.map((p, i) => (
                          <Tooltip key={i} title={tooltip(bar)} placement="top" arrow followCursor>
                            <Box
                              onClick={() => onBarClick && onBarClick(bar.op)}
                              sx={{
                                position: "absolute", left: p.x, width: p.w, boxSizing: "border-box", top, height: LANE_HEIGHT - 4,
                                bgcolor: color, color: "#fff", borderRadius: "3px", px: p.w > 14 ? 0.5 : 0, overflow: "hidden",
                                fontSize: 11, lineHeight: 1.25, display: "flex", flexDirection: "column", justifyContent: "center",
                                whiteSpace: "nowrap", zIndex: 1, cursor: onBarClick ? "pointer" : "default",
                                opacity: bar.op.status === "COMPLETED" ? 0.5 : 1,
                                boxShadow: bar.op.status === "IN_PROGRESS" ? `inset 0 0 0 2px #fff, 0 0 0 1px ${color}` : "none",
                                "&:hover": { filter: "brightness(1.1)" },
                              }}
                            >
                              {/* text only in the widest piece */}
                              {p.w === widest && p.w > 30 && <Box sx={{ fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis" }}>{bar.op.production_order}</Box>}
                              {p.w === widest && p.w > 60 && <Box sx={{ overflow: "hidden", textOverflow: "ellipsis" }}>{bar.op.operation_no} - {bar.op.step_name}</Box>}
                            </Box>
                          </Tooltip>
                        ))}
                      </React.Fragment>
                    );
                  })}
                </Box>
              </Box>
                    ))}
                  </React.Fragment>
                ))}
              </React.Fragment>
            ))}
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default GanttChart;
