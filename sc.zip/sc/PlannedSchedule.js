import React, { useMemo, useState } from "react";
import { Box, Stack, Typography } from "@mui/material";
import GanttTimeline from "./GanttTimeline";
import useGanttControls from "./useGanttControls";
import {
  ChartTools, ClearFiltersButton, DateRangeField, MultiSelect, ProductionOrdersLegend, RefreshButton, SingleSelect, ViewSelect,
} from "./ScheduleControls";
import { buildColorMap, fmtHours, machineLabel, normaliseOps, overlapsRange } from "./scheduleUtils";

const Stat = ({ value, label, color }) => (
  <Box sx={{ mr: 5 }}>
    <Typography sx={{ fontSize: 26, lineHeight: 1.1, fontWeight: 400, color }}>{value}</Typography>
    <Typography sx={{ fontSize: 12, color: "#6b7280", mt: 0.25 }}>{label}</Typography>
  </Box>
);

/** Baseline plan (read-only) with a summary band. resourceType: null | "MACHINE" | "MANUAL" */
const PlannedSchedule = ({ data, loading, onRefresh, resourceType = null }) => {
  const ctl = useGanttControls("weekly");
  const [machineSel, setMachineSel] = useState([]);
  const [poSel, setPoSel] = useState(null);

  const machines = useMemo(
    () => (data?.machines || [])
      .filter((m) => !resourceType || m.resource_type === resourceType)
      .slice().sort((a, b) => (a.work_centre || "").localeCompare(b.work_centre || "") || (a.machine_name || "").localeCompare(b.machine_name || "")),
    [data, resourceType]
  );
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "planned"), [data]);
  const colorMap = useMemo(() => buildColorMap(baseOps), [baseOps]);

  // filters that define "what is being planned" (these drive the summary numbers)
  const selectedOps = useMemo(() => baseOps.filter((o) =>
    (!machineSel.length || machineSel.includes(o.machine_id)) && (!poSel || o.production_order === poSel)), [baseOps, machineSel, poSel]);
  const shownOps = useMemo(() => selectedOps.filter((o) => overlapsRange(o, ctl.range)), [selectedOps, ctl.range]);

  const rows = useMemo(() => machines.filter((m) => !machineSel.length || machineSel.includes(m.machine_id)), [machines, machineSel]);
  const machineLabels = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, machineLabel(m)])), [machines]);

  // a batch operation is several tasks (one per batch) - count the operation once
  const stats = useMemo(() => ({
    operations: new Set(selectedOps.map((o) => o.parent_op_id || o.op_id)).size,
    batches: selectedOps.filter((o) => o.process_mode === "BATCH").length,
    machines: new Set(selectedOps.map((o) => o.machine_id)).size,
    orders: new Set(selectedOps.map((o) => o.production_order)).size,
    hours: selectedOps.reduce((s, o) => s + (o.duration_hours ?? (o.end - o.start) / 3600e3), 0),
  }), [selectedOps]);

  const pickOrder = (po) => {
    setPoSel(po);
    const mine = baseOps.filter((o) => o.production_order === po);
    if (po && mine.length) ctl.goTo(Math.min(...mine.map((o) => o.start))); // jump to where that order is planned
  };
  const clearFilters = () => { setMachineSel([]); setPoSel(null); ctl.resetControls(); };

  return (
    <Box>
      <Box sx={{ display: "flex", bgcolor: "#f6f8fb", borderRadius: "8px", px: 2, py: 1.5, mb: 2 }}>
        <Stat value={stats.operations} label="Operations" color="#1f6fe5" />
        <Stat value={stats.batches} label="Batches" color="#0ea5e9" />
        <Stat value={stats.machines} label={resourceType === "MANUAL" ? "Operators" : "Resources"} color="#16a34a" />
        <Stat value={stats.orders} label="Production Orders" color="#f59e0b" />
        <Stat value={fmtHours(stats.hours)} label="Total Working Time" color="#7c3aed" />
      </Box>

      <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ gap: 1.25, mb: 2 }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <MultiSelect placeholder={resourceType === "MANUAL" ? "Select Operators" : "Select Machines"}
          options={machines.map((m) => m.machine_id)} value={machineSel}
          onChange={setMachineSel} getLabel={(id) => machineLabels[id] || id} width={210} />
        <SingleSelect placeholder="Select Production Order" options={Object.keys(colorMap)} value={poSel} onChange={pickOrder} width={210} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
        <ClearFiltersButton onClick={clearFilters} />
        <RefreshButton onClick={onRefresh} loading={loading} />
      </Stack>

      <GanttTimeline
        machines={rows} ops={shownOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom}
        calendar={data?.calendar} colorMap={colorMap} barLines={1} showStatus={false} emptySuffix="(No Operations)"
        onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen}
      />
      <ProductionOrdersLegend colorMap={poSel ? { [poSel]: colorMap[poSel] } : colorMap} title="Production Orders Legend" />
    </Box>
  );
};

export default PlannedSchedule;
