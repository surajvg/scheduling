import { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { API_ROUTES, DEFAULT_API_BASE, POLL_MS } from "./scheduleConfig";

/**
 * Loads the schedule once for all tabs. The server address is read from the Redux config
 * exactly like RechartsGantt.js does (configDetails.project[0].ServerIP[0].PythonServerIP).
 * The server re-plans on every call, so polling (pollMs) makes runtime changes - a shift
 * added, a breakdown logged, a spare used up - appear on the Gantt by themselves.
 */
export default function useScheduleData({ pollMs = POLL_MS } = {}) {
  const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);
  const apiBase = useMemo(
    () => configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP || DEFAULT_API_BASE,
    [configDetails]
  );

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const res = await axios.get(apiBase + API_ROUTES.data);
      setData(res.data);
    } catch (e) {
      setError("Unable to load the production schedule: " + (e.response?.data?.detail || e.message));
    } finally {
      if (!silent) setLoading(false);
    }
  }, [apiBase]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!pollMs) return undefined;
    const t = setInterval(() => load(true), pollMs);
    return () => clearInterval(t);
  }, [load, pollMs]);

  const refresh = useCallback(() => load(false), [load]);

  // changes = [{ op_id, machine_id, start_time, end_time }]   (op_id = task id, e.g. "5001-40-B2")
  const saveChanges = useCallback(
    async (changes) => { await axios.post(apiBase + API_ROUTES.update, { changes }); },
    [apiBase]
  );

  // undo manual moves (all, or only the given task ids)
  const clearOverrides = useCallback(
    async (op_ids) => { await axios.post(apiBase + API_ROUTES.clearOverrides, { op_ids: op_ids || null }); },
    [apiBase]
  );

  return { data, loading, error, refresh, saveChanges, clearOverrides, apiBase };
}
