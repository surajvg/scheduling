import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const API = "http://localhost:8000/api";
function App() {
  const [meta, setMeta] = useState({operations: [], resources: []});
  const [jobs, setJobs] = useState([]);
  const [schedule, setSchedule] = useState([]);
  const [product, setProduct] = useState("Control Unit");
  const [quantity, setQuantity] = useState(1);
  const [selectedJob, setSelectedJob] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    const [m, j, s] = await Promise.all([
      fetch(`${API}/metadata`).then(r => r.json()),
      fetch(`${API}/jobs`).then(r => r.json()),
      fetch(`${API}/schedule`).then(r => r.json())
    ]);
    setMeta(m); setJobs(j); setSchedule(s);
    if (!selectedJob && j.length) setSelectedJob(j[0].id);
  }
  useEffect(() => { load().catch(e => setMessage(String(e))); }, []);

  async function createJob(e) {
    e.preventDefault(); setMessage("");
    const res = await fetch(`${API}/jobs`, {method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({product, quantity:Number(quantity)})});
    const data = await res.json();
    if (!res.ok) return setMessage(data.detail || "Could not create job");
    await load(); setSelectedJob(data.id); setMessage(`Job ${data.id} created`);
  }
  async function scheduleJob() {
    if (!selectedJob) return setMessage("Create or select a job first");
    const res = await fetch(`${API}/schedule/${selectedJob}`, {method:"POST"});
    const data = await res.json();
    if (!res.ok) return setMessage(data.detail || "Scheduling failed");
    setMessage(`Scheduled ${data.scheduled_operations.length} operations for ${selectedJob}`);
    await load();
  }
  async function setStatus(id, status) {
    await fetch(`${API}/schedule/${id}`, {method:"PATCH", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({status})});
    await load();
  }
  const visible = schedule.filter(s => !selectedJob || s.job_id === selectedJob);
  return <main>
    <header><div><div className="eyebrow">INDUSTRY 4.0 · MES</div><h1>Generic Production Scheduler</h1>
      <p>Metadata-driven routing · machine and manual resources · parallel operations</p></div>
      <button className="secondary" onClick={() => load()}>Refresh</button></header>
    {message && <div className="message">{message}</div>}
    <section className="panel">
      <h2>Create production job</h2>
      <form onSubmit={createJob} className="jobform">
        <label>Product / Assembly<input value={product} onChange={e=>setProduct(e.target.value)} required /></label>
        <label>Quantity<input type="number" min="1" value={quantity} onChange={e=>setQuantity(e.target.value)} required /></label>
        <button type="submit">Create Job</button>
      </form>
      <div className="schedule-controls">
        <label>Select job<select value={selectedJob} onChange={e=>setSelectedJob(e.target.value)}>
          <option value="">All jobs</option>{jobs.map(j=><option key={j.id} value={j.id}>{j.id} · {j.product} ({j.quantity})</option>)}
        </select></label>
        <button onClick={scheduleJob} disabled={!selectedJob}>Generate Schedule</button>
      </div>
    </section>
    <section className="panel">
      <h2>Process metadata</h2>
      <p className="hint">Edit operations in the backend API; predecessor IDs determine sequence and parallel branches.</p>
      <div className="tablewrap"><table><thead><tr><th>Operation</th><th>Duration</th><th>Resource type</th><th>Required resource</th><th>Predecessors</th><th>Parallel group</th></tr></thead>
      <tbody>{meta.operations.map(o=><tr key={o.id}><td><b>{o.name}</b><small>{o.id}</small></td><td>{o.duration_min} min</td><td>{o.resource_type}</td><td>{o.required_resource || "Any compatible"}</td><td>{o.predecessors.length ? o.predecessors.join(", ") : "—"}</td><td>{o.parallel_group || "—"}</td></tr>)}</tbody></table></div>
    </section>
    <section className="panel">
      <h2>Generated schedule</h2>
      <div className="tablewrap"><table><thead><tr><th>Job</th><th>Operation</th><th>Resource</th><th>Start</th><th>End</th><th>Status</th><th>Update</th></tr></thead>
      <tbody>{visible.map(s=><tr key={s.id}><td>{s.job_id}<small>{s.product} × {s.quantity}</small></td><td>{s.operation_name}</td><td>{s.resource_name || s.resource_id}</td><td>{new Date(s.start_at).toLocaleString()}</td><td>{new Date(s.end_at).toLocaleString()}</td><td><span className={`status ${s.status}`}>{s.status}</span></td><td><select value={s.status} onChange={e=>setStatus(s.id,e.target.value)}>
        {["planned","running","completed","blocked","cancelled"].map(x=><option key={x}>{x}</option>)}</select></td></tr>)}</tbody></table>
      {!visible.length && <p className="empty">No schedule yet. Create a job and generate its schedule.</p>}</div>
    </section>
    <section className="panel">
      <h2>Resource master</h2><div className="resource-grid">{meta.resources.map(r=><div className="resource" key={r.id}><b>{r.name}</b><span>{r.id}</span><span>{r.resource_type}</span></div>)}</div>
    </section>
    <footer>Starter template · Validate process rules, shifts, calendars and quality gates before production use.</footer>
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
