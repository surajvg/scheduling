from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import sqlite3, json, os, uuid

DB = os.getenv("SCHEDULER_DB", "scheduler.db")
app = FastAPI(title="Generic MES Scheduler", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS operations (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, duration_min INTEGER NOT NULL,
            resource_type TEXT NOT NULL, required_resource TEXT, predecessors TEXT NOT NULL,
            parallel_group TEXT, mandatory INTEGER NOT NULL DEFAULT 1, active INTEGER NOT NULL DEFAULT 1
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS resources (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, resource_type TEXT NOT NULL,
            available_from TEXT, available_until TEXT, active INTEGER NOT NULL DEFAULT 1
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, product TEXT NOT NULL, quantity INTEGER NOT NULL,
            due_at TEXT, created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued'
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS schedule (
            id TEXT PRIMARY KEY, job_id TEXT NOT NULL, operation_id TEXT NOT NULL,
            resource_id TEXT, start_at TEXT NOT NULL, end_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'planned', notes TEXT
        )""")
        count = c.execute("SELECT COUNT(*) n FROM operations").fetchone()["n"]
        if count == 0:
            seed(c)
        rcount = c.execute("SELECT COUNT(*) n FROM resources").fetchone()["n"]
        if rcount == 0:
            now = datetime.now().replace(second=0, microsecond=0)
            for rid, name, typ in [
                ("ASM-01", "Assembly Line 1", "machine"),
                ("AOI-01", "AOI Station 1", "machine"),
                ("AT-01", "Automatic Test Station", "machine"),
                ("MAN-01", "Manual Inspection Team", "manual"),
            ]:
                c.execute("INSERT INTO resources VALUES (?,?,?,?,?,1)",
                          (rid, name, typ, now.isoformat(), None))

def seed(c):
    # Dependencies are operation IDs. AOI, AT and manual inspection are parallel
    # children of assembly. FINAL_PACK waits for all three.
    rows = [
        ("ASSEMBLY", "Assembly Line", 90, "machine", "ASM-01", [], None, 1, 1),
        ("AOI", "Automated Optical Inspection", 20, "machine", "AOI-01", ["ASSEMBLY"], "TESTS", 1, 1),
        ("AT", "Automatic Test", 30, "machine", "AT-01", ["ASSEMBLY"], "TESTS", 1, 1),
        ("MANUAL", "Manual Inspection", 25, "manual", "MAN-01", ["ASSEMBLY"], "TESTS", 1, 1),
        ("FINAL_PACK", "Final Pack and Release", 15, "manual", "MAN-01", ["AOI", "AT", "MANUAL"], None, 1, 1),
    ]
    for row in rows:
        c.execute("INSERT INTO operations VALUES (?,?,?,?,?,?,?,?,?)",
                  (row[0], row[1], row[2], row[3], row[4], json.dumps(row[5]),
                   row[6], row[7], row[8]))

init_db()

class OperationIn(BaseModel):
    id: str
    name: str
    duration_min: int = Field(gt=0)
    resource_type: str = "machine"  # machine | manual | any
    required_resource: Optional[str] = None
    predecessors: List[str] = []
    parallel_group: Optional[str] = None
    mandatory: bool = True
    active: bool = True

class ResourceIn(BaseModel):
    id: str
    name: str
    resource_type: str = "machine"
    available_from: Optional[str] = None
    available_until: Optional[str] = None
    active: bool = True

class JobIn(BaseModel):
    product: str
    quantity: int = Field(gt=0)
    due_at: Optional[str] = None

class StatusIn(BaseModel):
    status: str
    notes: Optional[str] = None

def as_dict(row):
    return dict(row) if row else None

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/metadata")
def metadata():
    with conn() as c:
        ops = [dict(x) for x in c.execute("SELECT * FROM operations WHERE active=1 ORDER BY rowid")]
        resources = [dict(x) for x in c.execute("SELECT * FROM resources WHERE active=1 ORDER BY name")]
    for op in ops:
        op["predecessors"] = json.loads(op["predecessors"])
        op["mandatory"] = bool(op["mandatory"])
        op["active"] = bool(op["active"])
    for r in resources:
        r["active"] = bool(r["active"])
    return {"operations": ops, "resources": resources}

@app.post("/api/operations")
def save_operation(op: OperationIn):
    with conn() as c:
        c.execute("""INSERT INTO operations VALUES (?,?,?,?,?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET name=excluded.name, duration_min=excluded.duration_min,
          resource_type=excluded.resource_type, required_resource=excluded.required_resource,
          predecessors=excluded.predecessors, parallel_group=excluded.parallel_group,
          mandatory=excluded.mandatory, active=excluded.active""",
          (op.id, op.name, op.duration_min, op.resource_type, op.required_resource,
           json.dumps(op.predecessors), op.parallel_group, int(op.mandatory), int(op.active)))
    return {"saved": True, "operation_id": op.id}

@app.post("/api/resources")
def save_resource(r: ResourceIn):
    with conn() as c:
        c.execute("""INSERT INTO resources VALUES (?,?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET name=excluded.name, resource_type=excluded.resource_type,
          available_from=excluded.available_from, available_until=excluded.available_until,
          active=excluded.active""",
          (r.id, r.name, r.resource_type, r.available_from, r.available_until, int(r.active)))
    return {"saved": True, "resource_id": r.id}

@app.post("/api/jobs")
def create_job(job: JobIn):
    jid = str(uuid.uuid4())[:8].upper()
    with conn() as c:
        c.execute("INSERT INTO jobs VALUES (?,?,?,?,?,'queued')",
                  (jid, job.product, job.quantity, job.due_at, datetime.now().isoformat(timespec="minutes")))
    return {"id": jid, "product": job.product, "quantity": job.quantity, "status": "queued"}

def topological_order(ops: Dict[str, dict]):
    indeg = {oid: 0 for oid in ops}
    children = {oid: [] for oid in ops}
    for oid, op in ops.items():
        for p in op["predecessors"]:
            if p not in ops:
                raise ValueError(f"Operation {oid} has unknown predecessor {p}")
            indeg[oid] += 1
            children[p].append(oid)
    queue = [x for x in ops if indeg[x] == 0]
    result = []
    while queue:
        n = queue.pop(0)
        result.append(n)
        for child in children[n]:
            indeg[child] -= 1
            if indeg[child] == 0:
                queue.append(child)
    if len(result) != len(ops):
        raise ValueError("Dependency cycle detected in process metadata")
    return result

def parse_time(value, fallback):
    return datetime.fromisoformat(value) if value else fallback

@app.post("/api/schedule/{job_id}")
def schedule_job(job_id: str):
    with conn() as c:
        job = c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not job:
            raise HTTPException(404, "Job not found")
        op_rows = c.execute("SELECT * FROM operations WHERE active=1").fetchall()
        resource_rows = c.execute("SELECT * FROM resources WHERE active=1").fetchall()
        existing = c.execute("SELECT resource_id, start_at, end_at FROM schedule WHERE status NOT IN ('cancelled')").fetchall()

    ops = {}
    for row in op_rows:
        d = dict(row)
        d["predecessors"] = json.loads(d["predecessors"])
        ops[d["id"]] = d
    try:
        order = topological_order(ops)
    except ValueError as e:
        raise HTTPException(400, str(e))

    now = datetime.now().replace(second=0, microsecond=0)
    resource_by_id = {r["id"]: dict(r) for r in resource_rows}
    # Reservations includes already-planned jobs to prevent double-booking.
    busy = {}
    for r in resource_rows:
        busy[r["id"]] = []
    for row in existing:
        if row["resource_id"] in busy:
            busy[row["resource_id"]].append((datetime.fromisoformat(row["start_at"]),
                                             datetime.fromisoformat(row["end_at"])))

    job_ready = now
    end_by_op = {}
    planned = []

    for oid in order:
        op = ops[oid]
        predecessor_ends = [end_by_op[p] for p in op["predecessors"]]
        earliest = max([job_ready] + predecessor_ends) if predecessor_ends else job_ready
        candidates = []
        for rid, r in resource_by_id.items():
            if op["required_resource"] and rid != op["required_resource"]:
                continue
            if op["resource_type"] not in ("any", r["resource_type"]):
                continue
            available_from = parse_time(r["available_from"], now)
            if available_from > earliest:
                candidate_start = available_from
            else:
                candidate_start = earliest
            candidates.append((candidate_start, rid, r))
        if not candidates:
            raise HTTPException(400, f"No active resource matches operation {oid} ({op['resource_type']})")

        best = None
        duration = timedelta(minutes=int(op["duration_min"]))
        # Earliest-fit search, moving past conflicts on the selected resource.
        for candidate_start, rid, r in candidates:
            start = candidate_start
            intervals = sorted(busy.get(rid, []), key=lambda x: x[0])
            moved = True
            while moved:
                moved = False
                end = start + duration
                for bstart, bend in intervals:
                    if start < bend and end > bstart:
                        start = bend
                        moved = True
                        break
            end = start + duration
            if r.get("available_until"):
                until = datetime.fromisoformat(r["available_until"])
                if end > until:
                    continue
            if best is None or start < best[0]:
                best = (start, rid, end)
        if best is None:
            raise HTTPException(409, f"No feasible time window for operation {oid}")
        start, rid, end = best
        busy[rid].append((start, end))
        end_by_op[oid] = end
        planned.append({"id": str(uuid.uuid4())[:12], "job_id": job_id,
                        "operation_id": oid, "operation_name": op["name"],
                        "resource_id": rid, "resource_name": resource_by_id[rid]["name"],
                        "start_at": start.isoformat(timespec="minutes"),
                        "end_at": end.isoformat(timespec="minutes"), "status": "planned"})

    with conn() as c:
        # Replace this job's previous unstarted plan, retaining completed operations.
        c.execute("DELETE FROM schedule WHERE job_id=? AND status='planned'", (job_id,))
        for p in planned:
            c.execute("INSERT INTO schedule VALUES (?,?,?,?,?,?,?,?)",
                      (p["id"], p["job_id"], p["operation_id"], p["resource_id"],
                       p["start_at"], p["end_at"], p["status"], None))
        c.execute("UPDATE jobs SET status='scheduled' WHERE id=?", (job_id,))
    return {"job_id": job_id, "scheduled_operations": planned}

@app.get("/api/jobs")
def list_jobs():
    with conn() as c:
        return [dict(x) for x in c.execute("SELECT * FROM jobs ORDER BY created_at DESC")]

@app.get("/api/schedule")
def get_schedule(job_id: Optional[str] = None):
    sql = """SELECT s.*, j.product, j.quantity, o.name operation_name, r.name resource_name
             FROM schedule s JOIN jobs j ON j.id=s.job_id
             JOIN operations o ON o.id=s.operation_id
             LEFT JOIN resources r ON r.id=s.resource_id"""
    args = ()
    if job_id:
        sql += " WHERE s.job_id=?"
        args = (job_id,)
    sql += " ORDER BY s.start_at"
    with conn() as c:
        return [dict(x) for x in c.execute(sql, args)]

@app.patch("/api/schedule/{schedule_id}")
def update_schedule_status(schedule_id: str, data: StatusIn):
    allowed = {"planned", "running", "completed", "blocked", "cancelled"}
    if data.status not in allowed:
        raise HTTPException(400, f"status must be one of {sorted(allowed)}")
    with conn() as c:
        cur = c.execute("UPDATE schedule SET status=?, notes=? WHERE id=?",
                        (data.status, data.notes, schedule_id))
        if cur.rowcount == 0:
            raise HTTPException(404, "Schedule item not found")
    return {"updated": True}

@app.get("/api/jobs/{job_id}/readiness")
def readiness(job_id: str):
    with conn() as c:
        job = c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not job:
            raise HTTPException(404, "Job not found")
        rows = c.execute("""SELECT s.*, o.name operation_name, o.predecessors, o.mandatory
                            FROM schedule s JOIN operations o ON o.id=s.operation_id
                            WHERE s.job_id=?""", (job_id,)).fetchall()
    statuses = {r["operation_id"]: r["status"] for r in rows}
    pending = []
    for r in rows:
        if r["mandatory"] and statuses.get(r["operation_id"]) != "completed":
            pending.append(r["operation_name"])
    return {"job_id": job_id, "ready_for_release": len(pending) == 0,
            "mandatory_operations_pending": pending}
