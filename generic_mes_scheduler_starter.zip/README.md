# Generic MES Production Scheduler (Starter)

## Architecture
- FastAPI backend: metadata, resources, jobs, schedule generation and operation status.
- SQLite demo database: replace with PostgreSQL for production.
- React/Vite frontend: create jobs, inspect metadata, generate and update schedule.
- Process dependencies are metadata. `predecessors` enforce precedence; branches with the same predecessor may run in parallel on separate resources.
- A downstream operation waits for *all* its predecessor operations to complete in the planned dependency graph.

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Open http://localhost:8000/docs

## Run frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown (normally http://localhost:5173).

## Demo workflow
1. Create a job.
2. Select it and click Generate Schedule.
3. AOI, AT and Manual Inspection are eligible after Assembly in the dependency graph.
4. Final Pack is scheduled after all three branches.
5. Change statuses from planned to running/completed; check readiness at `/api/jobs/{job_id}/readiness`.

## Metadata examples
An operation contains:
```json
{
  "id": "AOI",
  "name": "AOI Inspection",
  "duration_min": 20,
  "resource_type": "machine",
  "required_resource": "AOI-01",
  "predecessors": ["ASSEMBLY"],
  "parallel_group": "TESTS",
  "mandatory": true,
  "active": true
}
```
`predecessors` is the important scheduling rule. `parallel_group` is for UI/reporting; it does not itself create parallelism. Parallelism comes from multiple operations depending on the same predecessor and being assigned to independent resources.

## Important limitations before production use
This is a starter heuristic, not a full industrial APS solver:
- Durations are fixed minutes and do not yet scale by quantity or batch size.
- Shift calendars, breaks, setup/changeover, tooling, skills, material availability, alternate routes, maintenance downtime, WIP limits and finite capacity across multiple jobs need to be added.
- It currently schedules a job using an earliest-fit resource heuristic; for complex multi-job optimization use OR-Tools CP-SAT or a commercial APS solver.
- Status changes are recorded, but the demo does not automatically reschedule downstream work when actual completion slips.
- Add authentication/authorization, audit trail, migrations, validation, tests, logging, backup and role permissions before deployment.
- Make sure actual MES execution checks predecessor completion and quality disposition, not only planned end times.
