import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Alert, Box, Button, Chip, LinearProgress, Switch, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Typography,
} from "@mui/material";

/**
 * Process Config tab: batch size, next-day release, cooldown and setup time per stage.
 *  GET    /schedule/config            -> [{ stage_id, stage_name, process_mode, batch_size, next_day_release,
 *                                           cooldown_minutes, cooldown_working_time_only, setup_minutes, is_default }]
 *  POST   /schedule/config            -> save one row
 *  DELETE /schedule/config/{stage_id} -> back to defaults
 */
const ScheduleConfigPage = ({ apiBase, onChanged }) => {
  const [rows, setRows] = useState([]);           // response of GET /schedule/config (+ local edits)
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);   // { severity, text }

  const loadConfig = () => {
    if (!apiBase) return;
    setLoading(true);
    axios.get(apiBase + "/schedule/config")
      .then((res) => setRows(res.data || []))
      .catch((err) => {
        setRows([]);
        setMessage({ severity: "error", text: "Could not load the config: " + (err.response?.data?.detail || err.message) });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadConfig();
  }, [apiBase]); // eslint-disable-line react-hooks/exhaustive-deps

  // change one field of one row in the table (saved only with the Save button)
  const setField = (stageId, field, value) => {
    setRows(rows.map((r) => (r.stage_id === stageId ? { ...r, [field]: value, changed: true } : r)));
  };

  const saveRow = (row) => {
    const body = {
      stage_id: row.stage_id,
      batch_size: Number(row.batch_size),
      next_day_release: Boolean(row.next_day_release),
      cooldown_minutes: Number(row.cooldown_minutes),
      cooldown_working_time_only: Boolean(row.cooldown_working_time_only),
      setup_minutes: Number(row.setup_minutes),
    };
    // same checks as the server, so the user sees the problem right away
    if (!Number.isInteger(body.batch_size) || body.batch_size < 1) {
      setMessage({ severity: "warning", text: `${row.stage_name}: batch size must be a whole number of 1 or more.` });
      return;
    }
    if (!(body.cooldown_minutes >= 0) || !(body.setup_minutes >= 0)) {
      setMessage({ severity: "warning", text: `${row.stage_name}: minutes cannot be negative.` });
      return;
    }
    axios.post(apiBase + "/schedule/config", body)
      .then(() => {
        setMessage({ severity: "success", text: `${row.stage_name} saved. The schedule is recalculated.` });
        loadConfig();
        if (onChanged) onChanged();
      })
      .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
  };

  const resetRow = (row) => {
    axios.delete(`${apiBase}/schedule/config/${row.stage_id}`)
      .then(() => {
        setMessage({ severity: "success", text: `${row.stage_name} is back to the default values.` });
        loadConfig();
        if (onChanged) onChanged();
      })
      .catch((err) => setMessage({ severity: "error", text: `${row.stage_name}: ` + (err.response?.data?.detail || err.message) }));
  };

  const numberField = (row, field, disabled) => (
    <TextField size="small" type="number" value={row[field]} disabled={disabled} sx={{ width: 95 }}
      inputProps={{ min: field === "batch_size" ? 1 : 0, step: field === "batch_size" ? 1 : "any" }}
      onChange={(e) => setField(row.stage_id, field, e.target.value)} />
  );

  return (
    <Box>
      <Typography sx={{ fontSize: 13, color: "#6b7280", mb: 1.5 }}>
        Batch size and next-day release are used only for BATCH stages (process_type). Cooldown is the wait after
        a step before the next step of the same order can start; the machine is free for other orders meanwhile.
      </Typography>

      {message && (
        <Alert severity={message.severity} sx={{ mb: 1.5 }} onClose={() => setMessage(null)}>{message.text}</Alert>
      )}
      {loading && <LinearProgress sx={{ mb: 1 }} />}

      <TableContainer sx={{ border: "1px solid #e3e7ee", borderRadius: "8px" }}>
        <Table size="small">
          <TableHead>
            <TableRow sx={{ "& th": { fontWeight: 600, bgcolor: "#f7f8fb" } }}>
              <TableCell>Stage</TableCell>
              <TableCell>Mode</TableCell>
              <TableCell>Batch size</TableCell>
              <TableCell>Next-day release</TableCell>
              <TableCell>Cooldown (min)</TableCell>
              <TableCell>Cooldown in working time only</TableCell>
              <TableCell>Setup (min)</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && !loading && (
              <TableRow><TableCell colSpan={8} sx={{ color: "#6b7280" }}>No stages found.</TableCell></TableRow>
            )}
            {/* one row per stage = response of GET /schedule/config */}
            {rows.map((row) => {
              const isBatch = row.process_mode === "BATCH";
              return (
                <TableRow key={row.stage_id} sx={{ bgcolor: row.changed ? "#fffbeb" : "inherit" }}>
                  <TableCell>
                    {row.stage_name}
                    {row.is_default && <Chip label="default" size="small" sx={{ ml: 1, height: 20, fontSize: 11 }} />}
                  </TableCell>
                  <TableCell>{row.process_mode}</TableCell>
                  <TableCell>{numberField(row, "batch_size", !isBatch)}</TableCell>
                  <TableCell>
                    <Switch size="small" checked={Boolean(row.next_day_release)} disabled={!isBatch}
                      onChange={(e) => setField(row.stage_id, "next_day_release", e.target.checked)} />
                  </TableCell>
                  <TableCell>{numberField(row, "cooldown_minutes", false)}</TableCell>
                  <TableCell>
                    <Switch size="small" checked={Boolean(row.cooldown_working_time_only)}
                      onChange={(e) => setField(row.stage_id, "cooldown_working_time_only", e.target.checked)} />
                  </TableCell>
                  <TableCell>{numberField(row, "setup_minutes", false)}</TableCell>
                  <TableCell align="right" sx={{ whiteSpace: "nowrap" }}>
                    <Button size="small" variant="contained" onClick={() => saveRow(row)} sx={{ textTransform: "none", mr: 1 }}>
                      Save
                    </Button>
                    <Button size="small" onClick={() => resetRow(row)} disabled={row.is_default} sx={{ textTransform: "none" }}>
                      Reset
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default ScheduleConfigPage;
