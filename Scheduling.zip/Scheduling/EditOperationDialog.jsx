import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem, Stack, TextField,
} from "@mui/material";

function fmt(text) {
  return text ? new Date(text).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: false }) : "-";
}

/**
 * Move one operation to another machine (same stage) and/or another start time.
 *  op       : one entry of data.operations
 *  machines : data.machines (only machines with the same stage_id are offered)
 * POST /schedule/update -> { updated, rejected: [{ op_id, reason }] }
 */
const EditOperationDialog = ({ open, op, machines, apiBase, onClose, onSaved }) => {
  const [machineId, setMachineId] = useState("");
  const [start, setStart] = useState("");        // "YYYY-MM-DDTHH:MM" for <input type="datetime-local">
  const [saving, setSaving] = useState(false);
  const [rejected, setRejected] = useState([]);  // response.rejected
  const [error, setError] = useState("");

  // fill the form every time another operation is opened
  useEffect(() => {
    if (op) {
      setMachineId(op.machine_id);
      setStart((op.start_time || "").slice(0, 16));
      setRejected([]);
      setError("");
    }
  }, [op]);

  if (!op) return null;

  // machines of the same stage (op.flow_step_id = machine.stage_id)
  const stageMachines = machines.filter((m) => m.stage_id === op.flow_step_id);
  const completed = op.status === "COMPLETED";

  const handleUpdate = () => {
    setSaving(true);
    setRejected([]);
    setError("");
    // end_time is not sent: the server calculates it from the working calendar
    const change = { op_id: op.op_id, machine_id: machineId, start_time: start + ":00" };
    axios.post(apiBase + "/schedule/update", { changes: [change] })
      .then((res) => {
        if (res.data.updated > 0) onSaved();
        else setRejected(res.data.rejected || []);
      })
      .catch((err) => setError("Could not save: " + (err.response?.data?.detail || err.message)))
      .finally(() => setSaving(false));
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontSize: 17 }}>
        {op.production_order} · {op.operation_no} - {op.step_name}
      </DialogTitle>
      <DialogContent>
        {/* read-only facts of the operation */}
        <Box sx={{ fontSize: 13, color: "#4b5563", mb: 2, lineHeight: 1.7, fontFamily: (theme) => theme.typography.fontFamily }}>
          <div>Part: <b>{op.part_number}</b> · {op.process_mode} · {op.completed_qty}/{op.quantity} pcs · {op.status}</div>
          <div>Scheduled: <b>{fmt(op.start_time)}</b> → <b>{fmt(op.end_time)}</b> on <b>{op.machine_id}</b></div>
          <div>PDC (planned end): <b>{fmt(op.planned_end)}</b></div>
          {op.waiting_reason && <div>Waiting for: <b>{op.waiting_reason}</b></div>}
        </Box>

        {completed && <Alert severity="info" sx={{ mb: 2 }}>This operation is completed and cannot be moved.</Alert>}

        <Stack spacing={2}>
          <TextField select size="small" label="Machine" value={machineId} disabled={completed}
            onChange={(e) => setMachineId(e.target.value)}>
            {stageMachines.map((m) => (
              <MenuItem key={m.machine_id} value={m.machine_id}>
                {m.machine_id}{m.machine_name && m.machine_name !== m.machine_id ? ` - ${m.machine_name}` : ""}
              </MenuItem>
            ))}
          </TextField>
          <TextField size="small" type="datetime-local" label="Start" value={start} disabled={completed}
            InputLabelProps={{ shrink: true }} onChange={(e) => setStart(e.target.value)} />
        </Stack>

        {/* reasons from response.rejected */}
        {rejected.map((r, i) => (
          <Alert key={i} severity="warning" sx={{ mt: 2 }}>Not saved: {r.reason}</Alert>
        ))}
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleUpdate} disabled={completed || saving || !machineId || !start}
          startIcon={saving ? <CircularProgress size={16} color="inherit" /> : null}>
          Update
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditOperationDialog;
