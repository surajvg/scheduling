import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";
const STATUSES = ["PLANNED", "RUNNING", "COMPLETED", "BLOCKED", "UNSCHEDULED", "ON_HOLD"];

function fmt(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString([], { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}
function durationMinutes(a, b) {
  return Math.max(0, (new Date(b) - new Date(a)) / 60000);
}

function App() {
  const [tasks, setTasks] = useState([]);
  const [resources, setResources] = useState([]);
  const [route, setRoute] = useState({ processes: [], dependencies: [] });
  const [batchId, setBatchId] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [hours, setHours] = useState(72);

  async function api(path, options = {}) {
    const res = await fetch(`${API}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.detail || `HTTP ${res.status}`);
    return body;
  }
  async function refresh() {
    try {
      const [t, r, rt] = await Promise.all([
        api(`/schedule${batchId ? `?batch_id=${batchId}` : ""}`),
        api("/resources"),
        api("/metadata/route")
      ]);
      setTasks(t); setResources(r); setRoute(rt);
      setMessage("");
    } catch (e) { setMessage(`API connection: ${e.message}. Start FastAPI and seed demo data.`); }
  }
  useEffect(() => { refresh(); }, [batchId]);

  async function action(label, path, body = {}) {
    setLoading(true);
    try {
      const result = await api(path, { method: "POST", body: JSON.stringify(body) });
      setMessage(`${label}: ${JSON.stringify(result)}`);
      await refresh();
    } catch (e) { setMessage(`${label} failed: ${e.message}`); }
    finally { setLoading(false); }
  }

  const visible = useMemo(() => filter === "ALL" ? tasks : tasks.filter(t => t.status === filter), [tasks, filter]);
  const dated = visible.filter(t => t.planned_start && t.planned_end);
  const anchor = dated.length ? Math.min(...dated.map(t => new Date(t.planned_start).getTime())) : Date.now();
  const windowStart = anchor;
  const windowEnd = windowStart + hours * 3600000;
  const pxPerHour = 28;
  const width = hours * pxPerHour;

  const lanes = useMemo(() => {
    const resourceLanes = resources.map(r => ({ key: `r${r.id}`, label: r.name, resource: r, tasks: dated.filter(t => t.resource_id === r.id) }));
    const unscheduled = visible.filter(t => !t.planned_start || !t.resource_id);
    return [...resourceLanes, ...(unscheduled.length ? [{ key: "unassigned", label: "Blocked / Unscheduled", tasks: unscheduled }] : [])];
  }, [resources, dated, visible]);

  const ticks = Array.from({ length: Math.floor(hours / 4) + 1 }, (_, i) => i * 4);
  const counts = Object.fromEntries(STATUSES.map(s => [s, tasks.filter(t => t.status === s).length]));
  const barColor = status => ({
    PLANNED: "#3b82f6", RUNNING: "#0f9f78", COMPLETED: "#64748b",
    BLOCKED: "#d97706", UNSCHEDULED: "#dc2626", ON_HOLD: "#9333ea"
  }[status] || "#64748b");

  return <div className="app">
    <header>
      <div>
        <div className="eyebrow">MANUFACTURING EXECUTION SYSTEM</div>
        <h1>Production Scheduler</h1>
        <p>Batch release gate · Unit-level parallel processing · Finite resource capacity</p>
      </div>
      <div className="header-actions">
        <button className="secondary" disabled={loading} onClick={() => action("Seed demo", "/demo/seed")}>Seed demo</button>
        <button disabled={loading} onClick={() => action("Plan generated", "/schedule/plan", { batch_id: batchId ? Number(batchId) : null, horizon_days: 14 })}>Generate plan</button>
        <button className="secondary" disabled={loading} onClick={() => action("Rescheduled", "/schedule/reschedule", { batch_id: batchId ? Number(batchId) : null, horizon_days: 14 })}>Reschedule</button>
        <button className="secondary" onClick={refresh}>Refresh</button>
      </div>
    </header>

    {message && <div className="message" role="status">{message}</div>}

    <section className="metrics">
      <div className="metric"><span>Total tasks</span><strong>{tasks.length}</strong></div>
      <div className="metric"><span>Planned</span><strong>{counts.PLANNED || 0}</strong></div>
      <div className="metric"><span>Running</span><strong>{counts.RUNNING || 0}</strong></div>
      <div className="metric warn"><span>Blocked</span><strong>{counts.BLOCKED || 0}</strong></div>
      <div className="metric danger"><span>Unscheduled</span><strong>{counts.UNSCHEDULED || 0}</strong></div>
    </section>

    <section className="panel">
      <div className="panel-heading">
        <div><h2>Schedule timeline</h2><p>Bars are planned resource allocations. Hover for task details.</p></div>
        <div className="controls">
          <label>Batch ID <input value={batchId} onChange={e => setBatchId(e.target.value)} placeholder="All batches" /></label>
          <label>Status <select value={filter} onChange={e => setFilter(e.target.value)}><option value="ALL">All statuses</option>{STATUSES.map(s => <option key={s}>{s}</option>)}</select></label>
          <label>Window <select value={hours} onChange={e => setHours(Number(e.target.value))}><option value={24}>24 hours</option><option value={72}>72 hours</option><option value={168}>7 days</option></select></label>
        </div>
      </div>
      <div className="legend">{STATUSES.map(s => <span key={s}><i style={{ background: barColor(s) }} />{s}</span>)}</div>
      <div className="gantt-scroll">
        <div className="gantt" style={{ minWidth: 240 + width }}>
          <div className="gantt-head">
            <div className="lane-name head-name">Resource / task</div>
            <div className="time-head" style={{ width }}>
              {ticks.map(h => <div key={h} className="tick" style={{ left: h * pxPerHour }}><span>{new Date(windowStart + h * 3600000).toLocaleString([], { weekday: "short", hour: "2-digit" })}</span></div>)}
            </div>
          </div>
          {lanes.map(lane => <div className="lane" key={lane.key}>
            <div className="lane-name">
              <strong>{lane.label}</strong>
              <small>{lane.tasks.length} task(s)</small>
            </div>
            <div className="lane-track" style={{ width }}>
              {ticks.map(h => <div key={h} className="gridline" style={{ left: h * pxPerHour }} />)}
              {lane.tasks.map(t => {
                if (!t.planned_start || !t.planned_end) return null;
                const start = new Date(t.planned_start).getTime();
                const end = new Date(t.planned_end).getTime();
                const left = ((start - windowStart) / 3600000) * pxPerHour;
                const barWidth = Math.max(5, ((end - start) / 3600000) * pxPerHour);
                if (left + barWidth < 0 || left > width) return null;
                return <div key={t.id} className="taskbar" title={`${t.process_name || "Process"} | ${t.batch_code || `Batch ${t.batch_id}`} | ${t.unit_serial || "Batch task"}\n${t.status}\n${fmt(t.planned_start)} – ${fmt(t.planned_end)}\n${t.resource_name || "No resource"}`}
                  style={{ left: Math.max(0, left), width: Math.min(barWidth, width - Math.max(0, left)), background: barColor(t.status) }}>
                  <span>{t.process_name} {t.unit_serial ? `· ${t.unit_serial}` : ""}</span>
                </div>;
              })}
            </div>
          </div>)}
        </div>
      </div>
      <p className="hint">The initial timeline shows planned allocations. Blocked tasks appear in the final lane without a time bar; inspect the task table for the blocking reason.</p>
    </section>

    <section className="panel">
      <div className="panel-heading"><div><h2>Task dispatch and blockers</h2><p>Review what is ready, planned, blocked, or awaiting a slot.</p></div></div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Batch / Unit</th><th>Process</th><th>Status</th><th>Resource</th><th>Planned start</th><th>Planned finish</th><th>Block reason</th><th>Action</th></tr></thead>
          <tbody>{visible.map(t => <tr key={t.id}>
            <td>{t.id}</td><td>{t.batch_code || t.batch_id}<small>{t.unit_serial || "Batch operation"}</small></td>
            <td>{t.process_name}</td><td><span className={`status ${t.status.toLowerCase()}`}>{t.status}</span></td>
            <td>{t.resource_name || "—"}</td><td>{fmt(t.planned_start)}</td><td>{fmt(t.planned_end)}</td><td className="reason">{t.blocked_reason || "—"}</td>
            <td className="actions">
              {t.status === "PLANNED" && <button className="small" onClick={() => action(`Start task ${t.id}`, `/tasks/${t.id}/start`, {})}>Start</button>}
              {t.status === "RUNNING" && <button className="small" onClick={() => action(`Complete task ${t.id}`, `/tasks/${t.id}/complete`, {})}>Complete</button>}
              {t.status !== "RUNNING" && t.status !== "COMPLETED" && t.status !== "ON_HOLD" && <button className="small secondary" onClick={() => action(`Hold task ${t.id}`, `/tasks/${t.id}/block`, { note: "Held from dispatch UI" })}>Hold</button>}
              {t.status === "ON_HOLD" && <button className="small secondary" onClick={() => action(`Unhold task ${t.id}`, `/tasks/${t.id}/unblock`, {})}>Unhold</button>}
            </td>
          </tr>)}</tbody>
        </table>
        {!visible.length && <div className="empty">No tasks found. Click “Seed demo”, then “Generate plan”.</div>}
      </div>
    </section>

    <section className="panel route-panel">
      <div className="panel-heading"><div><h2>Configured process route</h2><p>Process definitions and dependency edges loaded from metadata.</p></div></div>
      <div className="route-grid">{route.processes.map(p => <div className="process-card" key={p.id}>
        <strong>{p.name}</strong><span>{p.code} · {p.scope}</span><small>{p.duration_minutes} min · {p.resource_type}</small>
      </div>)}</div>
      <div className="dependency-list"><strong>Dependencies:</strong> {route.dependencies.map((d, i) => <span key={i}>{d.predecessor} → {d.successor}</span>)}</div>
    </section>
    <footer>MES Scheduler Starter · Validate calendar, locking, and route rules before production use.</footer>
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
