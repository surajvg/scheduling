from __future__ import annotations

import os
from datetime import date, datetime, time, timedelta, timezone
from typing import Optional, List, Dict, Tuple

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import (
    create_engine, text, select, and_, or_, update
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy.types import DateTime, Date, Time, Integer, String, Boolean, Text, ForeignKey

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg://mes:mes@localhost:5432/mes"
)
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

app = FastAPI(title="Generic MES Scheduler", version="0.1.0")


class Base(DeclarativeBase):
    pass


class ProcessDef(Base):
    __tablename__ = "process_def"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(50), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    scope: Mapped[str] = mapped_column(String(10))
    duration_minutes: Mapped[int] = mapped_column(Integer)
    required_resource_type: Mapped[str] = mapped_column(String(30))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    can_pause_between_shifts: Mapped[bool] = mapped_column(Boolean, default=True)


class Resource(Base):
    __tablename__ = "resource"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(50), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    resource_type: Mapped[str] = mapped_column(String(30))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)


class ProductionBatch(Base):
    __tablename__ = "production_batch"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_code: Mapped[str] = mapped_column(String(80), unique=True)
    product_code: Mapped[str] = mapped_column(String(80))
    quantity: Mapped[int] = mapped_column(Integer)
    priority: Mapped[int] = mapped_column(Integer, default=100)
    due_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="RELEASED")


class Unit(Base):
    __tablename__ = "unit"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("production_batch.id"))
    serial_no: Mapped[str] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20), default="OPEN")


class Task(Base):
    __tablename__ = "task"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("production_batch.id"))
    unit_id: Mapped[Optional[int]] = mapped_column(ForeignKey("unit.id"), nullable=True)
    process_id: Mapped[int] = mapped_column(ForeignKey("process_def.id"))
    status: Mapped[str] = mapped_column(String(20), default="BLOCKED")
    planned_start: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    planned_end: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_start: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_end: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    resource_id: Mapped[Optional[int]] = mapped_column(ForeignKey("resource.id"), nullable=True)
    duration_minutes: Mapped[int] = mapped_column(Integer)
    blocked_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)


class PlanRequest(BaseModel):
    batch_id: Optional[int] = None
    horizon_days: int = Field(default=14, ge=1, le=90)
    start_at: Optional[datetime] = None


class TaskAction(BaseModel):
    resource_id: Optional[int] = None
    note: Optional[str] = None


def utcnow():
    return datetime.now(timezone.utc)


def row_dict_task(t, process_name=None, resource_name=None, batch_code=None, unit_serial=None):
    return {
        "id": t.id, "batch_id": t.batch_id, "batch_code": batch_code,
        "unit_id": t.unit_id, "unit_serial": unit_serial,
        "process_id": t.process_id, "process_name": process_name,
        "status": t.status, "planned_start": t.planned_start,
        "planned_end": t.planned_end, "actual_start": t.actual_start,
        "actual_end": t.actual_end, "resource_id": t.resource_id,
        "resource_name": resource_name, "duration_minutes": t.duration_minutes,
        "blocked_reason": t.blocked_reason, "version": t.version
    }


def load_calendar(session, resource_id: int):
    """Return working windows for this resource. Weekdays use resource_shift + shift_pattern."""
    rows = session.execute(text("""
        SELECT rs.day_of_week, sp.start_time, sp.end_time,
               sb.start_offset_minutes, sb.duration_minutes
        FROM resource_shift rs
        JOIN shift_pattern sp ON sp.id=rs.shift_pattern_id
        LEFT JOIN shift_break sb ON sb.shift_pattern_id=sp.id
        WHERE rs.resource_id=:rid
        ORDER BY rs.day_of_week, sp.start_time, sb.start_offset_minutes
    """), {"rid": resource_id}).mappings().all()
    by_day: Dict[int, list] = {}
    for r in rows:
        by_day.setdefault(r["day_of_week"], [])
        item = (r["start_time"], r["end_time"], r["start_offset_minutes"], r["duration_minutes"])
        if item not in by_day[r["day_of_week"]]:
            by_day[r["day_of_week"]].append(item)
    holidays = {r[0] for r in session.execute(text("SELECT holiday_date FROM holiday")).all()}
    return by_day, holidays


def resource_work_windows(session, resource_id: int, start: datetime, end: datetime):
    """Build working intervals in local-naive timestamps. Configure server/site timezone consistently."""
    by_day, holidays = load_calendar(session, resource_id)
    if not by_day:
        return []
    windows = []
    current = start.date()
    while current <= end.date():
        if current not in holidays:
            for dow, entries in by_day.items():
                if current.weekday() != dow:
                    continue
                for st, et, break_offset, break_duration in entries:
                    a = datetime.combine(current, st).replace(tzinfo=start.tzinfo)
                    b_date = current if et > st else current + timedelta(days=1)
                    b = datetime.combine(b_date, et).replace(tzinfo=start.tzinfo)
                    # Collect unique shift records. Break rows are repeated per break; if no break, NULL.
                    if break_offset is None:
                        windows.append((a, b))
                    else:
                        ba = a + timedelta(minutes=break_offset)
                        bb = ba + timedelta(minutes=break_duration)
                        if a < ba:
                            windows.append((a, ba))
                        if bb < b:
                            windows.append((bb, b))
        current += timedelta(days=1)
    # Merge overlapping/adjacent intervals (duplicate shift-break rows may create fragments).
    windows.sort(key=lambda x: x[0])
    merged = []
    for a, b in windows:
        if not merged or a > merged[-1][1]:
            merged.append([a, b])
        elif b > merged[-1][1]:
            merged[-1][1] = b
    return [(a, b) for a, b in merged]


def task_dependencies(session, process_id: int):
    return session.execute(text("""
        SELECT predecessor_process_id
        FROM process_dependency WHERE successor_process_id=:pid
    """), {"pid": process_id}).scalars().all()


def dependencies_satisfied(session, task: Task):
    predecessors = task_dependencies(session, task.process_id)
    if not predecessors:
        return True, None
    if task.unit_id is None:
        # Batch-scope successor: all predecessor tasks in this batch must complete.
        rows = session.query(Task).filter(
            Task.batch_id == task.batch_id,
            Task.process_id.in_(predecessors)
        ).all()
    else:
        # Unit-level successor: predecessor may be batch-scope or same-unit scope.
        rows = session.query(Task).filter(
            Task.batch_id == task.batch_id,
            Task.process_id.in_(predecessors),
            or_(Task.unit_id == task.unit_id, Task.unit_id.is_(None))
        ).all()
        # Batch-release gate: batch-level predecessors must all be complete.
        batch_pred_ids = session.execute(text("""
            SELECT id FROM process_def WHERE id = ANY(:ids) AND scope='BATCH'
        """), {"ids": predecessors}).scalars().all()
        if batch_pred_ids:
            rows += session.query(Task).filter(
                Task.batch_id == task.batch_id,
                Task.process_id.in_(batch_pred_ids),
                Task.unit_id.is_(None)
            ).all()
    if not rows:
        return False, "Predecessor task instances have not been generated"
    incomplete = [r.id for r in rows if r.status != "COMPLETED"]
    if incomplete:
        return False, f"Waiting for predecessor task(s): {incomplete[:8]}"
    return True, None


def find_slot(session, resource: Resource, earliest: datetime, duration: int, horizon_end: datetime,
              fixed_allocations: List[Tuple[datetime, datetime]]):
    windows = resource_work_windows(session, resource.id, earliest, horizon_end)
    occupied = list(fixed_allocations)
    occupied += session.query(Task.planned_start, Task.planned_end).filter(
        Task.resource_id == resource.id,
        Task.status.in_(["PLANNED", "RUNNING"]),
        Task.planned_start.is_not(None),
        Task.planned_end.is_not(None)
    ).all()
    occupied = sorted([(x[0], x[1]) for x in occupied if x[0] and x[1]], key=lambda x: x[0])

    for wa, wb in windows:
        candidate = max(wa, earliest)
        if candidate + timedelta(minutes=duration) > wb:
            continue
        # Non-preemptive operation: must fit completely in one continuous working interval.
        moved = True
        while moved:
            moved = False
            finish = candidate + timedelta(minutes=duration)
            for oa, ob in occupied:
                if candidate < ob and finish > oa:
                    candidate = ob
                    moved = True
                    break
            if candidate + timedelta(minutes=duration) > wb:
                break
        if candidate + timedelta(minutes=duration) <= wb:
            return candidate, candidate + timedelta(minutes=duration)
    return None


def get_candidate_resources(session, process: ProcessDef):
    return session.query(Resource).filter(
        Resource.enabled.is_(True),
        Resource.resource_type == process.required_resource_type
    ).order_by(Resource.id).all()


def topological_process_order(session):
    processes = session.query(ProcessDef).filter(ProcessDef.enabled.is_(True)).all()
    ids = {p.id for p in processes}
    edges = session.execute(text("SELECT predecessor_process_id, successor_process_id FROM process_dependency")).all()
    indegree = {pid: 0 for pid in ids}
    adj = {pid: [] for pid in ids}
    for a, b in edges:
        if a in ids and b in ids:
            adj[a].append(b)
            indegree[b] += 1
    queue = sorted([pid for pid, deg in indegree.items() if deg == 0])
    order = []
    while queue:
        n = queue.pop(0)
        order.append(n)
        for nxt in adj[n]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
                queue.sort()
    if len(order) != len(ids):
        raise HTTPException(400, "Route metadata contains a dependency cycle")
    by_id = {p.id: p for p in processes}
    return [by_id[i] for i in order]


def ensure_tasks_for_batch(session, batch: ProductionBatch):
    processes = topological_process_order(session)
    units = session.query(Unit).filter(Unit.batch_id == batch.id).order_by(Unit.id).all()
    existing = {(t.process_id, t.unit_id) for t in session.query(Task).filter(Task.batch_id == batch.id).all()}
    for process in processes:
        if process.scope == "BATCH":
            key = (process.id, None)
            if key not in existing:
                session.add(Task(batch_id=batch.id, unit_id=None, process_id=process.id,
                                 status="BLOCKED", duration_minutes=process.duration_minutes,
                                 blocked_reason="Awaiting predecessor completion"))
        else:
            for unit in units:
                key = (process.id, unit.id)
                if key not in existing:
                    session.add(Task(batch_id=batch.id, unit_id=unit.id, process_id=process.id,
                                     status="BLOCKED", duration_minutes=process.duration_minutes,
                                     blocked_reason="Awaiting predecessor completion"))
    session.flush()


@app.get("/health")
def health():
    return {"status": "ok", "service": "generic-mes-scheduler"}


@app.get("/metadata/route")
def route_metadata():
    with SessionLocal() as s:
        processes = s.query(ProcessDef).filter(ProcessDef.enabled.is_(True)).order_by(ProcessDef.id).all()
        edges = s.execute(text("""
          SELECT p1.code AS predecessor, p2.code AS successor
          FROM process_dependency d
          JOIN process_def p1 ON p1.id=d.predecessor_process_id
          JOIN process_def p2 ON p2.id=d.successor_process_id
        """)).mappings().all()
        return {"processes": [
            {"id": p.id, "code": p.code, "name": p.name, "scope": p.scope,
             "duration_minutes": p.duration_minutes, "resource_type": p.required_resource_type}
            for p in processes
        ], "dependencies": list(edges)}


@app.get("/resources")
def resources():
    with SessionLocal() as s:
        return [{"id": r.id, "code": r.code, "name": r.name, "resource_type": r.resource_type}
                for r in s.query(Resource).filter(Resource.enabled.is_(True)).all()]


@app.get("/schedule")
def get_schedule(batch_id: Optional[int] = None):
    with SessionLocal() as s:
        q = s.query(Task, ProcessDef.name, Resource.name, ProductionBatch.batch_code, Unit.serial_no).join(
            ProcessDef, Task.process_id == ProcessDef.id
        ).join(ProductionBatch, Task.batch_id == ProductionBatch.id).outerjoin(
            Resource, Task.resource_id == Resource.id
        ).outerjoin(Unit, Task.unit_id == Unit.id)
        if batch_id:
            q = q.filter(Task.batch_id == batch_id)
        rows = q.order_by(Task.planned_start.nulls_last(), Task.id).all()
        return [row_dict_task(*row) for row in rows]


@app.post("/schedule/plan")
def plan_schedule(req: PlanRequest):
    with SessionLocal() as s:
        start = req.start_at or utcnow()
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        horizon_end = start + timedelta(days=req.horizon_days)
        batch_q = s.query(ProductionBatch).filter(ProductionBatch.status.in_(["RELEASED", "IN_PROGRESS"]))
        if req.batch_id:
            batch_q = batch_q.filter(ProductionBatch.id == req.batch_id)
        batches = batch_q.order_by(ProductionBatch.priority, ProductionBatch.due_at.nulls_last(), ProductionBatch.id).all()
        result = {"planned": 0, "blocked": 0, "unscheduled": 0, "tasks": []}

        for batch in batches:
            ensure_tasks_for_batch(s, batch)
            tasks = s.query(Task).filter(Task.batch_id == batch.id).all()
            process_by_id = {p.id: p for p in s.query(ProcessDef).all()}
            order_ids = [p.id for p in topological_process_order(s)]
            task_by_process = {}
            for t in tasks:
                task_by_process.setdefault(t.process_id, []).append(t)

            # Preserve completed and running tasks; release gate checks their actual state.
            for pid in order_ids:
                process = process_by_id[pid]
                candidates = task_by_process.get(pid, [])
                for task in candidates:
                    if task.status in ("COMPLETED", "RUNNING"):
                        continue
                    ok, reason = dependencies_satisfied(s, task)
                    if not ok:
                        task.status = "BLOCKED"
                        task.blocked_reason = reason or "Dependency not satisfied"
                        task.planned_start = None
                        task.planned_end = None
                        task.resource_id = None
                        result["blocked"] += 1
                        continue

                    earliest = start
                    pred_ids = task_dependencies(s, task.process_id)
                    if pred_ids:
                        if task.unit_id is None:
                            preds = s.query(Task).filter(Task.batch_id == batch.id, Task.process_id.in_(pred_ids)).all()
                        else:
                            preds = s.query(Task).filter(
                                Task.batch_id == batch.id,
                                Task.process_id.in_(pred_ids),
                                or_(Task.unit_id == task.unit_id, Task.unit_id.is_(None))
                            ).all()
                        pred_ends = [p.actual_end or p.planned_end for p in preds
                                     if p.status in ("COMPLETED", "PLANNED", "RUNNING") and (p.actual_end or p.planned_end)]
                        if pred_ends:
                            earliest = max(earliest, max(pred_ends))

                    best = None
                    for resource in get_candidate_resources(s, process):
                        slot = find_slot(s, resource, earliest, task.duration_minutes, horizon_end, [])
                        if slot and (best is None or slot[1] < best[1]):
                            best = (resource, slot[0], slot[1])
                    if best:
                        resource, ps, pe = best
                        task.resource_id = resource.id
                        task.planned_start = ps
                        task.planned_end = pe
                        task.status = "PLANNED"
                        task.blocked_reason = None
                        task.version += 1
                        result["planned"] += 1
                        result["tasks"].append({"task_id": task.id, "resource": resource.code,
                                                "start": ps, "end": pe})
                    else:
                        task.status = "UNSCHEDULED"
                        task.blocked_reason = "No suitable resource/calendar slot within planning horizon"
                        task.planned_start = None
                        task.planned_end = None
                        task.resource_id = None
                        result["unscheduled"] += 1
            batch.status = "IN_PROGRESS"
        s.commit()
        return result


@app.post("/tasks/{task_id}/start")
def start_task(task_id: int, action: TaskAction = TaskAction()):
    with SessionLocal() as s:
        task = s.get(Task, task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task.status not in ("PLANNED", "READY"):
            raise HTTPException(409, f"Cannot start task in status {task.status}")
        ok, reason = dependencies_satisfied(s, task)
        if not ok:
            raise HTTPException(409, reason or "Dependencies are not complete")
        rid = action.resource_id or task.resource_id
        if not rid:
            raise HTTPException(409, "Assign a resource before starting")
        resource = s.get(Resource, rid)
        process = s.get(ProcessDef, task.process_id)
        if not resource or not resource.enabled or resource.resource_type != process.required_resource_type:
            raise HTTPException(409, "Resource is unavailable or incompatible")
        now = utcnow()
        # Basic overlap guard; DB exclusion constraint is the final concurrency guard.
        overlap = s.query(Task).filter(
            Task.resource_id == rid, Task.id != task.id,
            Task.status.in_(["PLANNED", "RUNNING"]),
            Task.planned_start < now + timedelta(minutes=task.duration_minutes),
            Task.planned_end > now
        ).first()
        if overlap:
            raise HTTPException(409, f"Resource conflicts with task {overlap.id}")
        task.resource_id = rid
        task.actual_start = now
        task.status = "RUNNING"
        task.blocked_reason = None
        task.version += 1
        s.commit()
        return {"task_id": task.id, "status": task.status, "actual_start": task.actual_start}


@app.post("/tasks/{task_id}/complete")
def complete_task(task_id: int, action: TaskAction = TaskAction()):
    with SessionLocal() as s:
        task = s.get(Task, task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task.status != "RUNNING":
            raise HTTPException(409, "Only a running task can be completed")
        task.status = "COMPLETED"
        task.actual_end = utcnow()
        task.planned_end = task.actual_end
        task.blocked_reason = None
        task.version += 1
        s.commit()
        return {"task_id": task.id, "status": task.status, "actual_end": task.actual_end}


@app.post("/tasks/{task_id}/block")
def block_task(task_id: int, action: TaskAction):
    with SessionLocal() as s:
        task = s.get(Task, task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task.status in ("COMPLETED", "RUNNING"):
            raise HTTPException(409, "Completed/running task cannot be manually blocked")
        task.status = "ON_HOLD"
        task.blocked_reason = action.note or "Manually placed on hold"
        task.version += 1
        s.commit()
        return {"task_id": task.id, "status": task.status, "blocked_reason": task.blocked_reason}


@app.post("/tasks/{task_id}/unblock")
def unblock_task(task_id: int):
    with SessionLocal() as s:
        task = s.get(Task, task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task.status != "ON_HOLD":
            raise HTTPException(409, "Task is not on hold")
        task.status = "BLOCKED"
        task.blocked_reason = "Awaiting dependency/resource evaluation"
        task.version += 1
        s.commit()
    return {"task_id": task_id, "status": "BLOCKED"}


@app.post("/schedule/reschedule")
def reschedule(req: PlanRequest):
    # Replanning keeps RUNNING/COMPLETED tasks; clears only future plans in selected batch(es).
    with SessionLocal() as s:
        q = s.query(Task).filter(Task.status == "PLANNED")
        if req.batch_id:
            q = q.filter(Task.batch_id == req.batch_id)
        for task in q.all():
            task.status = "BLOCKED"
            task.planned_start = None
            task.planned_end = None
            task.resource_id = None
            task.blocked_reason = "Cleared for rescheduling"
        s.commit()
    return plan_schedule(req)


@app.post("/demo/seed")
def seed_demo():
    """Seed an illustrative route and one 8-unit batch. Safe to call repeatedly."""
    with SessionLocal() as s:
        if s.query(ProcessDef).count() == 0:
            assembly = ProcessDef(code="ASSY", name="Assembly Line", scope="BATCH",
                                  duration_minutes=240, required_resource_type="LINE")
            aoi = ProcessDef(code="AOI", name="AOI Inspection", scope="UNIT",
                             duration_minutes=20, required_resource_type="AOI")
            manual = ProcessDef(code="MANUAL", name="Manual Inspection", scope="UNIT",
                                duration_minutes=15, required_resource_type="OPERATOR")
            test = ProcessDef(code="TEST", name="Automatic Test", scope="UNIT",
                              duration_minutes=25, required_resource_type="TESTER")
            qa = ProcessDef(code="QA", name="Final QA", scope="UNIT",
                            duration_minutes=10, required_resource_type="OPERATOR")
            s.add_all([assembly, aoi, manual, test, qa])
            s.flush()
            s.execute(text("""
              INSERT INTO process_dependency(predecessor_process_id, successor_process_id)
              VALUES (:a,:b),(:a,:c),(:a,:d),(:b,:e),(:c,:e),(:d,:e)
            """), {"a": assembly.id, "b": aoi.id, "c": manual.id, "d": test.id, "e": qa.id})
            resources = [
                Resource(code="LINE-01", name="Assembly Line 01", resource_type="LINE"),
                Resource(code="AOI-01", name="AOI Machine 01", resource_type="AOI"),
                Resource(code="OP-01", name="Operator 01", resource_type="OPERATOR"),
                Resource(code="OP-02", name="Operator 02", resource_type="OPERATOR"),
                Resource(code="TEST-01", name="Test Station 01", resource_type="TESTER"),
            ]
            s.add_all(resources)
            s.flush()
            # One day shift, weekdays; break starts 4 hours after shift start for 30 minutes.
            shift = s.execute(text("""
              INSERT INTO shift_pattern(code,name,start_time,end_time)
              VALUES ('DAY','Day Shift','08:00','17:00') RETURNING id
            """)).scalar_one()
            s.execute(text("""
              INSERT INTO shift_break(shift_pattern_id,start_offset_minutes,duration_minutes)
              VALUES (:sid,240,30)
            """), {"sid": shift})
            for r in resources:
                s.execute(text("""
                  INSERT INTO resource_shift(resource_id,shift_pattern_id,day_of_week)
                  SELECT :rid,:sid,d FROM generate_series(0,4) AS d
                """), {"rid": r.id, "sid": shift})
        batch = s.query(ProductionBatch).filter_by(batch_code="DEMO-B001").first()
        if not batch:
            batch = ProductionBatch(batch_code="DEMO-B001", product_code="DEMO-CTRL",
                                   quantity=8, priority=10, status="RELEASED")
            s.add(batch)
            s.flush()
            s.add_all([Unit(batch_id=batch.id, serial_no=f"DEMO-{i:03d}") for i in range(1, 9)])
        s.commit()
        return {"message": "Demo metadata and batch ready", "batch_id": batch.id, "batch_code": batch.batch_code}
