CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE IF NOT EXISTS process_def (
  id SERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(150) NOT NULL,
  scope VARCHAR(10) NOT NULL CHECK (scope IN ('BATCH','UNIT')),
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
  required_resource_type VARCHAR(30) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  can_pause_between_shifts BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS process_dependency (
  predecessor_process_id INTEGER NOT NULL REFERENCES process_def(id) ON DELETE CASCADE,
  successor_process_id INTEGER NOT NULL REFERENCES process_def(id) ON DELETE CASCADE,
  release_mode VARCHAR(20) NOT NULL DEFAULT 'ALL_PREDECESSORS'
    CHECK (release_mode IN ('ALL_PREDECESSORS')),
  PRIMARY KEY (predecessor_process_id, successor_process_id),
  CHECK (predecessor_process_id <> successor_process_id)
);

CREATE TABLE IF NOT EXISTS resource (
  id SERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(150) NOT NULL,
  resource_type VARCHAR(30) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS resource_skill (
  resource_id INTEGER NOT NULL REFERENCES resource(id) ON DELETE CASCADE,
  skill_code VARCHAR(60) NOT NULL,
  PRIMARY KEY (resource_id, skill_code)
);

CREATE TABLE IF NOT EXISTS shift_pattern (
  id SERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  CHECK (start_time <> end_time)
);

CREATE TABLE IF NOT EXISTS shift_break (
  id SERIAL PRIMARY KEY,
  shift_pattern_id INTEGER NOT NULL REFERENCES shift_pattern(id) ON DELETE CASCADE,
  start_offset_minutes INTEGER NOT NULL CHECK (start_offset_minutes >= 0),
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0)
);

CREATE TABLE IF NOT EXISTS resource_shift (
  resource_id INTEGER NOT NULL REFERENCES resource(id) ON DELETE CASCADE,
  shift_pattern_id INTEGER NOT NULL REFERENCES shift_pattern(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  PRIMARY KEY (resource_id, shift_pattern_id, day_of_week)
);

CREATE TABLE IF NOT EXISTS holiday (
  holiday_date DATE PRIMARY KEY,
  name VARCHAR(150) NOT NULL
);

CREATE TABLE IF NOT EXISTS production_batch (
  id SERIAL PRIMARY KEY,
  batch_code VARCHAR(80) UNIQUE NOT NULL,
  product_code VARCHAR(80) NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  priority INTEGER NOT NULL DEFAULT 100,
  due_at TIMESTAMPTZ,
  status VARCHAR(20) NOT NULL DEFAULT 'RELEASED'
    CHECK (status IN ('DRAFT','RELEASED','IN_PROGRESS','COMPLETED','ON_HOLD')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS unit (
  id SERIAL PRIMARY KEY,
  batch_id INTEGER NOT NULL REFERENCES production_batch(id) ON DELETE CASCADE,
  serial_no VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
  UNIQUE(batch_id, serial_no)
);

CREATE TABLE IF NOT EXISTS task (
  id BIGSERIAL PRIMARY KEY,
  batch_id INTEGER NOT NULL REFERENCES production_batch(id) ON DELETE CASCADE,
  unit_id INTEGER REFERENCES unit(id) ON DELETE CASCADE,
  process_id INTEGER NOT NULL REFERENCES process_def(id),
  status VARCHAR(20) NOT NULL DEFAULT 'BLOCKED'
    CHECK (status IN ('BLOCKED','READY','PLANNED','RUNNING','COMPLETED','FAILED','ON_HOLD','UNSCHEDULED')),
  planned_start TIMESTAMPTZ,
  planned_end TIMESTAMPTZ,
  actual_start TIMESTAMPTZ,
  actual_end TIMESTAMPTZ,
  resource_id INTEGER REFERENCES resource(id),
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
  blocked_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((unit_id IS NULL) OR (unit_id IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS idx_task_batch_process ON task(batch_id, process_id);
CREATE INDEX IF NOT EXISTS idx_task_status_start ON task(status, planned_start);
CREATE INDEX IF NOT EXISTS idx_task_resource_time ON task(resource_id, planned_start, planned_end);

-- Prevent overlapping planned/running allocations for a resource.
-- Uses half-open ranges [start, end), so adjacent operations are allowed.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'task_resource_no_overlap'
  ) THEN
    ALTER TABLE task ADD CONSTRAINT task_resource_no_overlap
    EXCLUDE USING gist (
      resource_id WITH =,
      tstzrange(planned_start, planned_end, '[)') WITH &&
    )
    WHERE (
      resource_id IS NOT NULL
      AND planned_start IS NOT NULL
      AND planned_end IS NOT NULL
      AND status IN ('PLANNED','RUNNING')
    );
  END IF;
END $$;
