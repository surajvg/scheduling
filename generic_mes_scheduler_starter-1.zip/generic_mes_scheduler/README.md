# Generic MES Scheduler (Starter Project)

A metadata-driven MES scheduling starter for:
- Whole-batch release after assembly completion
- Unit-level parallel downstream operations
- Dependency gates / AND-joins
- Machine and operator capacity conflict prevention
- Shift calendars, breaks, holidays, next-day scheduling
- Rescheduling and a React Gantt-style timeline

## Stack
- FastAPI + SQLAlchemy 2.x + PostgreSQL
- React + Vite
- Scheduling engine uses dependency graph + earliest-feasible-slot search

## Important implementation note
This is a runnable starter/reference implementation, not a validated production MES. Before plant deployment, add authentication/RBAC, audit trails, migrations, transaction isolation/locking, PLC/SAP integration, robust timezone/site calendars, and tests against actual routes. The scheduler currently creates plans from configured route metadata and sample/demo data.

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux: source .venv/bin/activate
pip install -r requirements.txt
# Set DATABASE_URL, or use the default local PostgreSQL URL
uvicorn app:app --reload
```

Default database URL:
`postgresql+psycopg://mes:mes@localhost:5432/mes`

Create database/user first, then execute `schema.sql` using psql. The API also has a `POST /demo/seed` endpoint that seeds metadata and a demo batch.

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
The UI expects the API at `http://localhost:8000`. Set `VITE_API_URL` to override.

## Main endpoints
- `GET /health`
- `GET /metadata/route`
- `GET /resources`
- `GET /schedule`
- `POST /schedule/plan` — calculate / replace planned slots for open tasks
- `POST /tasks/{task_id}/start`
- `POST /tasks/{task_id}/complete`
- `POST /tasks/{task_id}/block`
- `POST /tasks/{task_id}/unblock`
- `POST /schedule/reschedule`
- `POST /demo/seed`

## Scheduling semantics
1. Assembly operations are batch-level and must complete before the batch-release gate opens.
2. A downstream unit-level operation becomes eligible only after its configured predecessors for that unit are complete.
3. AND-join dependencies require all predecessor tasks to complete.
4. A task is scheduled only inside a resource's working intervals, excluding breaks and holidays.
5. Resource overlap is prevented by the planner and by a database exclusion constraint in the supplied PostgreSQL schema.
6. A task that has unmet dependencies is `BLOCKED`; if dependencies are satisfied but no slot is found within the planning horizon, it is `UNSCHEDULED`.
7. Replanning preserves running/completed work and recalculates eligible planned tasks.

## Route metadata model
- `process_def`: process master, duration, scope (`BATCH` or `UNIT`), required resource type
- `process_dependency`: directed edge from predecessor process to successor process
- `resource`: machine/operator resource
- `resource_skill`: optional skills a resource possesses
- `shift_pattern`, `shift_break`, `resource_shift`, `holiday`: working calendar metadata
- `production_batch`, `unit`: batch and its individual serialised units
- `task`: execution instance for a process and batch or unit

Configure your own route in `schema.sql` or via the metadata API you add for your environment.
