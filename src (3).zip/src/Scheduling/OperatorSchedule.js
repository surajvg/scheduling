import React, { useMemo, useState } from "react";
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { SingleSelect } from "./ScheduleControls";
import { fmtDateTime, normaliseOps } from "./scheduleUtils";
import { THEME } from "./scheduleConfig";

const OperatorSchedule = ({ data }) => {
  const ops = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const operators = useMemo(() => Array.from(new Set(ops.map((o) => o.operator_name))).sort(), [ops]);
  const [selectedOp, setSelectedOp] = useState(operators[0] || "");

  const myOps = useMemo(() => {
    return ops
      .filter((o) => o.operator_name === selectedOp)
      .sort((a, b) => a.start - b.start);
  }, [ops, selectedOp]);

  return (
    <Box>
      <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 2 }}>
        <Typography sx={{ fontWeight: 600, fontSize: 14 }}>Select Operator:</Typography>
        <SingleSelect placeholder="Select Operator" options={operators} value={selectedOp} onChange={setSelectedOp} width={240} />
      </Box>

      <TableContainer component={Paper} sx={{ border: `1px solid ${THEME.border}`, boxShadow: "none", borderRadius: "8px" }}>
        <Table size="small">
          <TableHead sx={{ bgcolor: "#f6f8fb" }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 600 }}>Sequence / Job</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Production Order</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Part Number</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Operation</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Machine / Work Centre</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Start Time</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>End Time</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {myOps.map((op, idx) => (
              <TableRow key={op.op_id} sx={{ bgcolor: idx === 0 ? "#eff6ff" : "inherit" }}>
                <TableCell sx={{ fontWeight: idx === 0 ? 700 : 400 }}>#{idx + 1} {idx === 0 ? "(First Job)" : ""}</TableCell>
                <TableCell>{op.production_order}</TableCell>
                <TableCell>{op.part_number}</TableCell>
                <TableCell>{op.operation_no} - {op.operation_name}</TableCell>
                <TableCell>{op.machine_id}</TableCell>
                <TableCell>{fmtDateTime(op.start)}</TableCell>
                <TableCell>{fmtDateTime(op.end)}</TableCell>
                <TableCell sx={{ fontWeight: 600, color: op.status === "IN_PROGRESS" ? "#2563eb" : op.status === "COMPLETED" ? "#16a34a" : "#d97706" }}>
                  {op.status}
                </TableCell>
              </TableRow>
            ))}
            {!myOps.length && (
              <TableRow>
                <TableCell colSpan={8} align="center" sx={{ py: 4, color: THEME.muted }}>No operations assigned to this operator.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default OperatorSchedule;