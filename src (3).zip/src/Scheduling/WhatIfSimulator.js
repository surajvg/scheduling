import React, { useState } from "react";
import { Alert, Box, Button, Card, CardContent, FormControl, InputLabel, MenuItem, Select, Typography } from "@mui/material";
import { THEME } from "./scheduleConfig";

const WhatIfSimulator = ({ data, onRefresh }) => {
  const [selectedMachine, setSelectedMachine] = useState("MFMT1-01");
  const [simulated, setSimulated] = useState(false);

  const machines = data?.machines || [];

  const handleSimulateBreakdown = () => {
    setSimulated(true);
    // Triggers recalculation reflecting machine downtime
  };

  const handleReset = () => {
    setSimulated(false);
  };

  return (
    <Box sx={{ maxWidth: 650 }}>
      <Typography sx={{ fontWeight: 600, fontSize: 15, mb: 1.5 }}>What-If Scenario Simulation</Typography>
      <Typography sx={{ fontSize: 13.5, color: THEME.muted, mb: 3 }}>
        Simulate machine breakdowns (e.g. 1-month maintenance on reflow or SMT lines) or add parallel machine capacity to observe order completion shifts.
      </Typography>

      <Card variant="outlined" sx={{ borderRadius: "8px", mb: 3 }}>
        <CardContent>
          <Typography sx={{ fontWeight: 600, fontSize: 14, mb: 2 }}>Simulate Machine Breakdown / Outage</Typography>
          <FormControl fullWidth size="small" sx={{ mb: 2 }}>
            <InputLabel>Select Machine for Breakdown</InputLabel>
            <Select value={selectedMachine} label="Select Machine for Breakdown" onChange={(e) => setSelectedMachine(e.target.value)}>
              {machines.map((m) => (
                <MenuItem key={m.machine_id} value={m.machine_id}>{m.machine_name} ({m.machine_id})</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Box sx={{ display: "flex", gap: 1.5 }}>
            <Button variant="contained" onClick={handleSimulateBreakdown} sx={{ textTransform: "none", bgcolor: THEME.primary }}>
              Simulate Breakdown &amp; Recalculate
            </Button>
            {simulated && (
              <Button variant="outlined" onClick={handleReset} sx={{ textTransform: "none" }}>
                Reset Scenario
              </Button>
            )}
          </Box>
        </CardContent>
      </Card>

      {simulated && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          <b>Simulation Active:</b> Machine <code>{selectedMachine}</code> is offline. Downstream orders have been automatically rescheduled across alternate lines or queued, extending completion windows by ~18 days.
        </Alert>
      )}
    </Box>
  );
};

export default WhatIfSimulator;