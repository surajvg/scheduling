import React, { useMemo } from "react";
import { Box } from "@mui/material";
import GanttTimeline from "./GanttTimeline";
import useGanttControls from "./useGanttControls";
import { ChartTools, DateRangeField, ProductionOrdersLegend, RefreshButton, ViewSelect } from "./ScheduleControls";
import { buildColorMap, normaliseOps, overlapsRange } from "./scheduleUtils";

export const ManualOnlySchedule = ({ data, loading, onRefresh }) => {
  const ctl = useGanttControls("weekly");
  const machines = useMemo(() => (data?.machines || []).filter((m) => m.resource_type === "MANUAL"), [data]);
  const baseOps = useMemo(() => normaliseOps(data?.operations || [], "current"), [data]);
  const machineIds = useMemo(() => new Set(machines.map((m) => m.machine_id)), [machines]);
  const filteredOps = useMemo(() => baseOps.filter((o) => machineIds.has(o.machine_id) && overlapsRange(o, ctl.range)), [baseOps, machineIds, ctl.range]);
  const colorMap = useMemo(() => buildColorMap(filteredOps), [filteredOps]);

  return (
    <Box>
      <Box sx={{ display: "flex", gap: 1.25, mb: 2, flexWrap: "wrap", alignItems: "center" }}>
        <ViewSelect value={ctl.view} onChange={ctl.changeView} />
        <DateRangeField start={ctl.customStart} end={ctl.customEnd} onChange={ctl.setDateRange} />
        <ChartTools zoomIn={ctl.zoomIn} zoomOut={ctl.zoomOut} isFullscreen={ctl.isFullscreen} toggleFullscreen={ctl.toggleFullscreen} />
        <RefreshButton onClick={onRefresh} loading={loading} />
      </Box>
      <GanttTimeline machines={machines} ops={filteredOps} view={ctl.view} range={ctl.range} zoom={ctl.zoom} calendar={data?.calendar} colorMap={colorMap} barLines={2} onNavigate={ctl.navigate} fsRef={ctl.fsRef} isFullscreen={ctl.isFullscreen} />
      <ProductionOrdersLegend colorMap={colorMap} title="Production Orders (Manual Work Only)" />
    </Box>
  );
};
export default ManualOnlySchedule;