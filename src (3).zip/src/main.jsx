import React from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { combineReducers, createStore } from "redux";
import App from "./App";

// Minimal stand-in for your real Redux store. The schedule screens only read
// state.MROTDataSavingReducer.configDetails.project[0].ServerIP[0].PythonServerIP
const initialConfig = {
  configDetails: {
    project: [{ ServerIP: [{ PythonServerIP: import.meta.env.VITE_API_BASE || "http://127.0.0.1:2000" }] }],
  },
};
const MROTDataSavingReducer = (state = initialConfig) => state;
const store = createStore(combineReducers({ MROTDataSavingReducer }));

createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <App />
  </Provider>
);
