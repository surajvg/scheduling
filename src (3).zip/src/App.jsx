import React from "react";
import { CssBaseline, ThemeProvider, createTheme } from "@mui/material";
import SchedulingPage from "./Scheduling/SchedulingPage";

const theme = createTheme({
  palette: { primary: { main: "#1f6fe5" } },
  typography: { fontFamily: "Roboto, Arial, sans-serif" },
});

// In your real app, replace <SchedulingPage /> with a route:
//   <Route path="/scheduling" element={<SchedulingPage />} />
export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <SchedulingPage />
    </ThemeProvider>
  );
}
