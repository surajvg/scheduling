import { configureStore } from '@reduxjs/toolkit';
// Import your reducers (slices) here
import salesReducer from './features/salesSlice'; 

const store = configureStore({
  reducer: {
    // This defines the structure of your state object
    sales: salesReducer, 
    // user: userReducer, (add more as your app grows)
  },
});

export default store;