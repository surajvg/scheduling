import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  data: [],
  target: 0,
  isLoading: false,
};

const salesSlice = createSlice({
  name: 'sales',
  initialState,
  reducers: {
    // Actions to update your state
    setSalesData: (state, action) => {
      state.data = action.payload;
    },
    setSalesTarget: (state, action) => {
      state.target = action.payload;
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    }
  },
});

// Export the actions so you can dispatch them from your components
export const { setSalesData, setSalesTarget, setLoading } = salesSlice.actions;

// Export the reducer to be included in the store
export default salesSlice.reducer;