// import React from "react";
// import ReactDOM from "react-dom/client";
// import App from "./App";
// import SalesPlan from "./SalesPlan";

// import "./index.css";

// ReactDOM.createRoot(document.getElementById("root")).render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );


import React from "react";
import ReactDOM from "react-dom/client";
import { Provider } from "react-redux"; // 1. Import Provider from react-redux
import store from "./store"; // 2. Import your configured Redux store (adjust the path as needed)

import App from "./App";
// import SalesPlan from "./SalesPlan";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    {/* 3. Wrap your component in the Provider and pass the store prop */}
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);