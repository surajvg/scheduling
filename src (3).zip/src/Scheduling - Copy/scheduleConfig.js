// Central place for every constant used by the scheduling screens.

export const DEFAULT_API_BASE = "http://127.0.0.1:2000";
export const API_ROUTES = {
  data: "/schedule/data",     // GET  -> machines, production_orders, operations, calendar
  update: "/schedule/update", // POST -> { changes: [{ op_id, machine_id, start_time, end_time }] }
};

export const VIEW_MODES = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "yearly", label: "Yearly" },
];

// first colour = SAMARTH blue (used when a single production order is shown)
export const PO_PALETTE = [
  "#1e88e5", "#f59e0b", "#10b981", "#e11d48", "#8b5cf6", "#14b8a6",
  "#f97316", "#84cc16", "#ec4899", "#0ea5e9", "#a16207", "#6366f1",
];

export const STATUS_META = {
  COMPLETED: { label: "Completed", note: "faded bar" },
  IN_PROGRESS: { label: "In progress", note: "bar with white outline" },
  SCHEDULED: { label: "Scheduled", note: "solid bar" },
};

export const THEME = {
  primary: "#1f6fe5",
  info: "#1b9ae1",
  dark: "#5b6573",
  border: "#e3e7ee",
  gridStrong: "#c9d0da",
  gridSoft: "#eceff4",
  text: "#1f2937",
  muted: "#6b7280",
  nowLine: "#ef4444",
  offDay: "rgba(100,116,139,0.08)",
};

export const LAYOUT = {
  labelWidth: 270,
  headerRow1: 30,
  headerRow2: 28,
  rowMin: 26,
  barPad: 4,
  laneHeight2Line: 34, // bar with 2 text lines (Machine Schedule)
  laneHeight1Line: 26, // bar with 1 text line  (Planned Schedule)
};

// pixels per working day at zoom = 1 (the chart is stretched to fill the screen if wider)
export const BASE_DAY_WIDTH = { daily: 900, weekly: 156, monthly: 46, yearly: 3.2 };
export const ZOOM = { min: 0.5, max: 6, step: 0.5 };
export const MAX_CUSTOM_RANGE_DAYS = 400;
export const SNAP_MINUTES = 15;

export const DEFAULT_CALENDAR = {
  shift_start: 6,
  shift_end: 20,
  shifts: [],
  week_off: [0],
  holidays: [],
};
