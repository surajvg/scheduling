import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ZOOM } from "./scheduleConfig";
import { getRange, shiftAnchor } from "./scheduleUtils";

/** View / date-range / zoom / fullscreen state shared by both tabs. */
export default function useGanttControls(initialView = "weekly") {
  const [view, setView] = useState(initialView);
  const [anchor, setAnchor] = useState(() => Date.now());
  const [customStart, setCustomStart] = useState(null);
  const [customEnd, setCustomEnd] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const fsRef = useRef(null);

  const range = useMemo(() => getRange(view, anchor, customStart, customEnd), [view, anchor, customStart, customEnd]);

  const changeView = useCallback((v) => { setView(v); setCustomStart(null); setCustomEnd(null); setZoom(1); }, []);
  const navigate = useCallback((dir) => setAnchor((a) => shiftAnchor(view, a, dir, range)), [view, range]);
  const setDateRange = useCallback((s, e) => { setCustomStart(s); setCustomEnd(e); }, []);
  const goTo = useCallback((ts) => setAnchor(ts), []);
  const zoomIn = useCallback(() => setZoom((z) => Math.min(ZOOM.max, z + ZOOM.step)), []);
  const zoomOut = useCallback(() => setZoom((z) => Math.max(ZOOM.min, z - ZOOM.step)), []);
  const resetControls = useCallback(() => { setCustomStart(null); setCustomEnd(null); setZoom(1); setAnchor(Date.now()); }, []);

  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === fsRef.current);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = fsRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen?.();
    else if (el.requestFullscreen) el.requestFullscreen().catch(() => setIsFullscreen((f) => !f));
    else setIsFullscreen((f) => !f); // CSS fallback (see GanttTimeline)
  }, []);

  return {
    view, changeView, range, navigate, goTo, customStart, customEnd, setDateRange,
    zoom, zoomIn, zoomOut, resetControls, fsRef, isFullscreen, toggleFullscreen,
  };
}
