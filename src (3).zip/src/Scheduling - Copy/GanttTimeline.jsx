import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Box, IconButton, Typography } from "@mui/material";
import { ChevronLeft as ChevronLeftIcon, ChevronRight as ChevronRightIcon } from "@mui/icons-material";
import { DEFAULT_CALENDAR, LAYOUT, THEME, SNAP_MINUTES } from "./scheduleConfig";
import { buildScale, layoutRows, machineLabel, fmtDateTime, toLocalIso } from "./scheduleUtils";

const navBtnSx = {
  position: "absolute", top: 4, zIndex: 8, width: 26, height: 26, bgcolor: "#fff",
  border: `1px solid ${THEME.border}`, borderRadius: "6px", color: THEME.primary,
  "&:hover": { bgcolor: "#f3f7ff" },
};

const TooltipRow = ({ k, v }) => (
  <Box sx={{ display: "flex", gap: 0.5, lineHeight: 1.45 }}>
    <Box component="span" sx={{ color: THEME.muted, whiteSpace: "nowrap" }}>{k}:</Box>
    <Box component="span" sx={{ color: THEME.text, fontWeight: 500 }}>{v}</Box>
  </Box>
);

/**
 * Generic machine-row Gantt.
 *  machines : [{ machine_id, work_centre, machine_name, ... }]  (one row each)
 *  ops      : [{ op_id, machine_id, start, end (ms), production_order, ... }]
 *  barLines : 2 -> "PO / part - operation" (Machine Schedule), 1 -> "PO" (Planned Schedule)
 */
const GanttTimeline = ({
  machines, ops, view, range, zoom, calendar, colorMap, barLines = 2,
  emptySuffix = "", editable = false, showStatus = true, pendingIds, onChangeOp, onNavigate, fsRef, isFullscreen,
}) => {
  const scrollRef = useRef(null);
  const bodyRef = useRef(null);
  const [width, setWidth] = useState(0);
  const [tip, setTip] = useState(null);   // { x, y, op }
  const [drag, setDrag] = useState(null); // { op, ghost }
  const [now, setNow] = useState(Date.now());

  /* available width -> chart stretches to fill the card at zoom 1 */
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return undefined;
    const measure = () => setWidth(Math.max(0, el.clientWidth - LAYOUT.labelWidth));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);

  const scale = useMemo(
    () => buildScale({ view, range, zoom, calendar, availableWidth: width }),
    [view, range, zoom, calendar, width]
  );

  const visibleOps = useMemo(() => (drag ? ops.filter((o) => o.op_id !== drag.op.op_id) : ops), [ops, drag]);
  const rows = useMemo(() => layoutRows(machines, visibleOps, scale, barLines), [machines, visibleOps, scale, barLines]);
  const rowsRef = useRef(rows); rowsRef.current = rows;
  const scaleRef = useRef(scale); scaleRef.current = scale;

  const bodyHeight = rows.reduce((s, r) => s + r.height, 0);
  // the red "now" line is hidden while "now" is outside the working window of a windowed (daily/weekly) view
  const cal = { ...DEFAULT_CALENDAR, ...(calendar || {}) };
  const nowD = new Date(now);
  const nowHour = nowD.getHours() + nowD.getMinutes() / 60;
  const nowVisible = now >= range.start && now < range.end && (!scale.windowed || (nowHour >= cal.shift_start && nowHour < cal.shift_end));
  const nowX = nowVisible ? scale.toX(now) : null;
  const headerH = LAYOUT.headerRow1 + LAYOUT.headerRow2;

  /* ---------- drag to re-schedule (Machine Schedule only) ---------- */
  const startDrag = useCallback((e, bar) => {
    if (!editable || e.button !== 0) return;
    e.preventDefault();
    setTip(null);
    const startX = e.clientX;
    const op = bar.op;
    const duration = op.end - op.start;
    const snap = SNAP_MINUTES * 60000;
    let moved = false;
    let last = null;

    const compute = (ev) => {
      const sc = scaleRef.current;
      const dx = ev.clientX - startX;
      const yRel = ev.clientY - bodyRef.current.getBoundingClientRect().top;
      const target = rowsRef.current.find((r) => yRel >= r.top && yRel < r.top + r.height)
        || rowsRef.current.find((r) => r.machine.machine_id === op.machine_id);
      const start = Math.round(sc.toTime(bar.x + dx) / snap) * snap;
      const end = start + duration;
      const x = sc.toX(start);
      return {
        op, start, end, machine_id: target.machine.machine_id,
        ghost: { x, w: Math.max(sc.toX(end) - x, 3), top: target.top + LAYOUT.barPad, h: bar.h },
      };
    };
    const onMove = (ev) => {
      if (Math.abs(ev.clientX - startX) > 3 || moved) moved = true;
      if (!moved) return;
      last = compute(ev);
      setDrag(last);
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      setDrag(null);
      if (moved && last && (last.start !== op.start || last.machine_id !== op.machine_id)) {
        onChangeOp?.(op, { machine_id: last.machine_id, start_time: toLocalIso(last.start), end_time: toLocalIso(last.end) });
      }
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }, [editable, onChangeOp]);

  /* ---------- tooltip ---------- */
  const showTip = (e, op) => { if (!drag) setTip({ x: e.clientX, y: e.clientY, op }); };
  const machineById = useMemo(() => Object.fromEntries(machines.map((m) => [m.machine_id, m])), [machines]);

  const renderTip = () => {
    if (!tip) return null;
    const { op } = tip;
    const m = machineById[op.machine_id];
    const qtyWord = op.status === "COMPLETED" ? "Completed" : op.status === "IN_PROGRESS" ? "Process" : "Scheduled";
    const vw = typeof window !== "undefined" ? window.innerWidth : 1400;
    const left = tip.x + 300 > vw ? tip.x - 290 : tip.x + 14;
    return (
      <Box sx={{
        position: "fixed", left, top: tip.y + 14, zIndex: 3000, bgcolor: "#fff", border: `1px solid ${THEME.border}`,
        borderRadius: "6px", boxShadow: "0 4px 18px rgba(15,23,42,0.18)", px: 1.25, py: 0.75, fontSize: 12.5,
        pointerEvents: "none", minWidth: 250,
      }}>
        <TooltipRow k="Part Number" v={op.part_number} />
        <TooltipRow k="Machine" v={m ? machineLabel(m) : op.machine_id} />
        <TooltipRow k="Production Order" v={op.production_order} />
        <TooltipRow k="Operation" v={`${op.operation_no} - ${op.operation_name}`} />
        <TooltipRow k="Quantity" v={`${qtyWord}(${op.completed_qty}/${op.quantity}pcs)`} />
        <TooltipRow k="Mode" v={`${op.process_mode === "BATCH" ? "Batch" : "Series"}${m?.resource_type === "MANUAL" ? " (Manual)" : ""}`} />
        <TooltipRow k="Operator" v={op.operator_name} />
        <TooltipRow k="Start" v={fmtDateTime(op.start)} />
        <TooltipRow k="End" v={fmtDateTime(op.end)} />
        <TooltipRow k="PDC of Operation" v={fmtDateTime(op.pdc)} />
        {pendingIds?.has(op.op_id) && <Box sx={{ mt: 0.5, color: "#b45309", fontWeight: 600 }}>Modified - press Update to save</Box>}
      </Box>
    );
  };

  const renderBar = (bar, row) => {
    const { op, x, w, lane } = bar;
    const color = colorMap[op.production_order] || THEME.primary;
    const h = row.laneH - 4;
    const pending = pendingIds?.has(op.op_id);
    const fadedOut = showStatus && op.status === "COMPLETED";
    return (
      <Box
        key={op.op_id}
        onPointerDown={(e) => startDrag(e, { ...bar, h })}
        onMouseEnter={(e) => showTip(e, op)}
        onMouseMove={(e) => showTip(e, op)}
        onMouseLeave={() => setTip(null)}
        sx={{
          position: "absolute", left: x, top: LAYOUT.barPad + lane * row.laneH, width: w, height: h, zIndex: 1,
          bgcolor: color, color: "#fff", borderRadius: "3px", px: w > 14 ? 0.5 : 0, overflow: "hidden",
          fontSize: 11, lineHeight: 1.25, display: "flex", flexDirection: "column", justifyContent: "center",
          opacity: fadedOut ? 0.55 : 1, cursor: editable ? "grab" : "default", userSelect: "none",
          boxShadow: showStatus && op.status === "IN_PROGRESS" ? `inset 0 0 0 1.5px #fff, 0 0 0 1px ${color}` : "none",
          outline: pending ? "2px dashed #f59e0b" : "none", outlineOffset: 1,
          borderRight: "1px solid rgba(255,255,255,0.55)",
          "&:hover": { filter: "brightness(1.08)" },
        }}
      >
        {w > 18 && (
          <>
            <Box sx={{ fontWeight: 600, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>{op.production_order}</Box>
            {barLines === 2 && (
              <Box sx={{ whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden", opacity: 0.95 }}>
                {op.part_number} - {op.operation_name}
              </Box>
            )}
          </>
        )}
      </Box>
    );
  };

  const cssFullscreen = isFullscreen && typeof document !== "undefined" && !document.fullscreenElement;

  return (
    <Box
      ref={fsRef}
      sx={{
        position: cssFullscreen ? "fixed" : "relative", inset: cssFullscreen ? 0 : "auto", zIndex: cssFullscreen ? 1400 : "auto",
        bgcolor: "#fff", border: `1px solid ${THEME.border}`, borderRadius: "10px", p: isFullscreen ? 1.5 : 0.5,
        boxSizing: "border-box", height: isFullscreen ? "100%" : "auto",
      }}
    >
      <Box sx={{ position: "relative" }}>
        <IconButton aria-label="Previous period" onClick={() => onNavigate(-1)} sx={{ ...navBtnSx, left: 8 }}><ChevronLeftIcon fontSize="small" /></IconButton>
        <IconButton aria-label="Next period" onClick={() => onNavigate(1)} sx={{ ...navBtnSx, right: 10 }}><ChevronRightIcon fontSize="small" /></IconButton>

        <Box ref={scrollRef} sx={{ overflow: "auto", maxHeight: isFullscreen ? "calc(100vh - 36px)" : 560 }}>
          <Box sx={{ width: LAYOUT.labelWidth + scale.totalWidth, minWidth: "100%", position: "relative", isolation: "isolate" }}>

            {/* ---------- header ---------- */}
            <Box sx={{ position: "sticky", top: 0, zIndex: 6, display: "flex", bgcolor: "#fff", height: headerH, borderBottom: `1px solid ${THEME.gridStrong}` }}>
              <Box sx={{ position: "sticky", left: 0, zIndex: 7, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff", borderRight: `1px solid ${THEME.gridStrong}` }} />
              <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                {scale.row1.map((c, i) => (
                  <Box key={`r1-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: 0, height: LAYOUT.headerRow1, borderLeft: `1px solid ${THEME.gridStrong}`, px: 0.5, display: "flex", alignItems: "center", fontSize: 13, fontWeight: 500, color: THEME.text, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}
                  </Box>
                ))}
                {scale.row2.map((c, i) => (
                  <Box key={`r2-${i}`} sx={{ position: "absolute", left: c.x, width: c.w, top: LAYOUT.headerRow1, height: LAYOUT.headerRow2, borderLeft: `1px solid ${THEME.gridSoft}`, px: 0.5, display: "flex", alignItems: "center", gap: 0.4, fontSize: 12, color: THEME.muted, whiteSpace: "nowrap", overflow: "hidden" }}>
                    {c.label}{c.sub && c.w > 30 ? <Box component="span" sx={{ fontSize: 9, opacity: 0.7 }}>{c.sub}</Box> : null}
                  </Box>
                ))}
              </Box>
            </Box>

            {/* ---------- body ---------- */}
            <Box ref={bodyRef} sx={{ position: "relative", minHeight: 160 }}>
              {/* grid + non-working days (under the bars) */}
              <Box sx={{ position: "absolute", left: LAYOUT.labelWidth, top: 0, width: scale.totalWidth, height: Math.max(bodyHeight, 160), zIndex: 0, pointerEvents: "none" }}>
                {scale.offDays.map((d, i) => <Box key={`off-${i}`} sx={{ position: "absolute", left: d.x, width: d.w, top: 0, bottom: 0, bgcolor: THEME.offDay }} />)}
                {scale.grid.map((g, i) => <Box key={`g-${i}`} sx={{ position: "absolute", left: g.x, top: 0, bottom: 0, width: "1px", bgcolor: g.strong ? THEME.gridStrong : THEME.gridSoft }} />)}
              </Box>
              {/* "now" line (over the bars) */}
              {nowX !== null && (
                <Box sx={{ position: "absolute", left: LAYOUT.labelWidth + nowX, top: 0, height: Math.max(bodyHeight, 160), width: "2px", bgcolor: THEME.nowLine, zIndex: 2, pointerEvents: "none" }} />
              )}

              {rows.length === 0 && (
                <Typography sx={{ position: "sticky", left: LAYOUT.labelWidth, p: 3, color: THEME.muted, fontSize: 13 }}>No machines to display.</Typography>
              )}

              {rows.map((row) => (
                <Box key={row.machine.machine_id} sx={{ display: "flex", height: row.height, borderBottom: `1px solid ${THEME.gridSoft}` }}>
                  <Box title={machineLabel(row.machine)} sx={{
                    position: "sticky", left: 0, zIndex: 3, width: LAYOUT.labelWidth, flex: "none", boxSizing: "border-box", bgcolor: "#fff",
                    borderRight: `1px solid ${THEME.gridStrong}`, px: 1, pt: row.bars.length ? 0.6 : 0, display: "flex",
                    alignItems: row.bars.length ? "flex-start" : "center", fontSize: 11.5, color: THEME.text,
                    fontWeight: row.bars.length ? 600 : 400, fontStyle: row.machine.resource_type === "MANUAL" ? "italic" : "normal",
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  }}>
                    {machineLabel(row.machine)}{!row.bars.length && emptySuffix ? ` ${emptySuffix}` : ""}
                  </Box>
                  <Box sx={{ position: "relative", width: scale.totalWidth, flex: "none" }}>
                    {row.bars.map((bar) => renderBar(bar, row))}
                  </Box>
                </Box>
              ))}

              {/* ghost while dragging */}
              {drag && (
                <Box sx={{
                  position: "absolute", left: LAYOUT.labelWidth + drag.ghost.x, top: drag.ghost.top, width: drag.ghost.w, height: drag.ghost.h,
                  bgcolor: colorMap[drag.op.production_order] || THEME.primary, opacity: 0.85, borderRadius: "3px", zIndex: 5,
                  outline: "2px dashed #f59e0b", pointerEvents: "none", color: "#fff", fontSize: 11, px: 0.5, display: "flex", alignItems: "center",
                  whiteSpace: "nowrap", overflow: "hidden",
                }}>
                  {drag.op.production_order} · {new Date(drag.start).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                </Box>
              )}
            </Box>
          </Box>
        </Box>
      </Box>
      {renderTip()}
    </Box>
  );
};

export default GanttTimeline;
