import React, { useState } from "react";
import { Alert, Box, Button, CircularProgress, Tab, Tabs, Typography } from "@mui/material";
import { EventNote as ScheduleIcon } from "@mui/icons-material";
import MachineSchedule from "./MachineSchedule";
import PlannedSchedule from "./PlannedSchedule";
import useScheduleData from "./useScheduleData";
import { THEME } from "./scheduleConfig";

/**
 * Entry point - mount this in your router, e.g.
 *   <Route path="/scheduling" element={<SchedulingPage />} />
 */
const SchedulingPage = () => {
  const [tab, setTab] = useState(0);
  const { data, loading, error, refresh, saveChanges } = useScheduleData();

  return (
    <Box sx={{ p: 3, bgcolor: "#f7f8fb", minHeight: "100%" }}>
      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", px: 2.5, py: 2, mb: 2.5, display: "flex", alignItems: "center", gap: 1.25, border: `1px solid ${THEME.border}` }}>
        <ScheduleIcon sx={{ color: THEME.text }} />
        <Typography sx={{ fontSize: 19, fontWeight: 500, color: THEME.text }}>Production Schedule</Typography>
      </Box>

      <Box sx={{ bgcolor: "#fff", borderRadius: "10px", border: `1px solid ${THEME.border}`, px: 2.5, pt: 1, pb: 2.5 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ borderBottom: `1px solid ${THEME.border}`, mb: 2.5, minHeight: 44 }}>
          <Tab label="Machine Schedule" sx={{ textTransform: "none", fontSize: 14, minHeight: 44 }} />
          <Tab label="Planned Schedule" sx={{ textTransform: "none", fontSize: 14, minHeight: 44 }} />
        </Tabs>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} action={<Button color="inherit" size="small" onClick={refresh}>Retry</Button>}>{error}</Alert>
        )}
        {loading && !data && <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}><CircularProgress /></Box>}


        <Box sx={{ display: tab === 0 ? "block" : "none" }}>
          <MachineSchedule data={data} loading={loading} onRefresh={refresh} saveChanges={saveChanges} />
        </Box>
        <Box sx={{ display: tab === 1 ? "block" : "none" }}>
          <PlannedSchedule data={data} loading={loading} onRefresh={refresh} />
        </Box>
      </Box>
    </Box>
  );
};

export default SchedulingPage;
