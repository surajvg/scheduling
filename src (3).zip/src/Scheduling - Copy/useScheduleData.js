// import { useCallback, useEffect, useMemo, useState } from "react";
// import axios from "axios";
// import { useSelector } from "react-redux";
// import { API_ROUTES, DEFAULT_API_BASE } from "./scheduleConfig";

// /**
//  * Loads the schedule once for both tabs. The server address is read from the Redux config
//  * exactly like RechartsGantt.js does (configDetails.project[0].ServerIP[0].PythonServerIP).
//  */
// export default function useScheduleData() {
//   const configDetails = useSelector((state) => state.MROTDataSavingReducer.configDetails);
//   const apiBase = useMemo(
//     () => configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP || DEFAULT_API_BASE,
//     [configDetails]
//   );

//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   const load = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const res = await axios.get(apiBase + API_ROUTES.data);
//       setData(res.data);
//     } catch (e) {
//       setError("Unable to load the production schedule. Check the server connection.");
//     } finally {
//       setLoading(false);
//     }
//   }, [apiBase]);

//   useEffect(() => { load(); }, [load]);

//   // changes = [{ op_id, machine_id, start_time, end_time }]
//   const saveChanges = useCallback(
//     async (changes) => { await axios.post(apiBase + API_ROUTES.update, { changes }); },
//     [apiBase]
//   );

//   return { data, loading, error, refresh: load, saveChanges };
// }

import { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { API_ROUTES, DEFAULT_API_BASE } from "./scheduleConfig";

/**
 * Loads the schedule once for both tabs. The server address is read from the Redux config
 * exactly like RechartsGantt.js does (configDetails.project[0].ServerIP[0].PythonServerIP).
 */
export default function useScheduleData() {
  const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);
  const apiBase = useMemo(
    () => configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP || DEFAULT_API_BASE,
    [configDetails]
  );

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get(apiBase + API_ROUTES.data);
      setData(res.data);
    } catch (e) {
      setError("Unable to load the production schedule. Check the server connection.");
    } finally {
      setLoading(false);
    }
  }, [apiBase]);

  useEffect(() => { load(); }, [load]);

  // changes = [{ op_id, machine_id, start_time, end_time }]
  const saveChanges = useCallback(
    async (changes) => { await axios.post(apiBase + API_ROUTES.update, { changes }); },
    [apiBase]
  );

  return { data, loading, error, refresh: load, saveChanges };
}
