import React, { useState } from "react";
import {
  Autocomplete, Box, Button, IconButton, MenuItem, Popover, Select, Stack, TextField, Tooltip, Typography,
} from "@mui/material";
import {
  CalendarMonth as CalendarIcon, ZoomIn as ZoomInIcon, ZoomOut as ZoomOutIcon, OpenInFull as FullscreenIcon,
  FullscreenExit as FullscreenExitIcon, InfoOutlined as InfoIcon, Refresh as RefreshIcon, Autorenew as UpdateIcon,
} from "@mui/icons-material";
import { STATUS_META, THEME, VIEW_MODES } from "./scheduleConfig";
import { fmtShortDate, fromDateInput, toDateInput } from "./scheduleUtils";

const fieldSx = {
  "& .MuiOutlinedInput-root": { borderRadius: "6px", fontSize: 13.5, bgcolor: "#fff", minHeight: 36 },
  "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border },
};

/* ---------- Weekly / Daily / Monthly / Yearly ---------- */
export const ViewSelect = ({ value, onChange }) => (
  <Select size="small" value={value} onChange={(e) => onChange(e.target.value)}
    sx={{ width: 118, height: 36, fontSize: 13.5, borderRadius: "6px", bgcolor: "#fff", "& .MuiOutlinedInput-notchedOutline": { borderColor: THEME.border } }}>
    {VIEW_MODES.map((v) => <MenuItem key={v.value} value={v.value} sx={{ fontSize: 13.5 }}>{v.label}</MenuItem>)}
  </Select>
);

/* ---------- "Start Date - End Date" with calendar button ---------- */
export const DateRangeField = ({ start, end, onChange }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [s, setS] = useState("");
  const [e, setE] = useState("");
  const open = (ev) => { setS(toDateInput(start)); setE(toDateInput(end)); setAnchorEl(ev.currentTarget.closest("[data-daterange]")); };
  const text = start && end ? `${fmtShortDate(start)} – ${fmtShortDate(end)}` : "";

  return (
    <>
      <Box data-daterange sx={{ display: "flex", width: 262 }}>
        <TextField size="small" placeholder="Start Date – End Date" value={text} onClick={open} fullWidth
          InputProps={{ readOnly: true, sx: { cursor: "pointer", borderTopRightRadius: 0, borderBottomRightRadius: 0 } }}
          sx={{ ...fieldSx, "& input": { cursor: "pointer" } }} />
        <IconButton aria-label="Pick dates" onClick={open}
          sx={{ width: 38, height: 36, borderRadius: "0 6px 6px 0", bgcolor: THEME.primary, color: "#fff", "&:hover": { bgcolor: "#1a5fc7" } }}>
          <CalendarIcon fontSize="small" />
        </IconButton>
      </Box>
      <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}>
        <Stack spacing={1.5} sx={{ p: 2, width: 260 }}>
          <TextField size="small" type="date" label="Start Date" value={s} onChange={(ev) => setS(ev.target.value)} InputLabelProps={{ shrink: true }} />
          <TextField size="small" type="date" label="End Date" value={e} onChange={(ev) => setE(ev.target.value)} InputLabelProps={{ shrink: true }} />
          <Stack direction="row" spacing={1} justifyContent="flex-end">
            <Button size="small" onClick={() => { onChange(null, null); setAnchorEl(null); }}>Clear</Button>
            <Button size="small" variant="contained" disabled={!s || !e}
              onClick={() => { onChange(fromDateInput(s), fromDateInput(e)); setAnchorEl(null); }}>Apply</Button>
          </Stack>
        </Stack>
      </Popover>
    </>
  );
};

/* ---------- multi / single select (Autocomplete) ---------- */
export const MultiSelect = ({ placeholder, options, value, onChange, width = 200, getLabel = (o) => o }) => (
  <Autocomplete multiple size="small" limitTags={1} disableCloseOnSelect options={options} value={value}
    getOptionLabel={getLabel} onChange={(_, v) => onChange(v)} sx={{ width, ...fieldSx }}
    ChipProps={{ size: "small", sx: { maxWidth: 96, fontSize: 12 } }}
    renderInput={(params) => <TextField {...params} placeholder={value.length ? "" : placeholder} />} />
);

export const SingleSelect = ({ placeholder, options, value, onChange, width = 200 }) => (
  <Autocomplete size="small" options={options} value={value} onChange={(_, v) => onChange(v)}
    sx={{ width, ...fieldSx }} renderInput={(params) => <TextField {...params} placeholder={placeholder} />} />
);

/* ---------- zoom / fullscreen / info ---------- */
const toolSx = { width: 34, height: 34, color: THEME.primary, "&:hover": { bgcolor: "#eef3fb" } };

export const ChartTools = ({ zoomIn, zoomOut, isFullscreen, toggleFullscreen, onInfo }) => (
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Tooltip title="Zoom in"><IconButton aria-label="Zoom in" onClick={zoomIn} sx={toolSx}><ZoomInIcon fontSize="small" /></IconButton></Tooltip>
    <Tooltip title="Zoom out"><IconButton aria-label="Zoom out" onClick={zoomOut} sx={toolSx}><ZoomOutIcon fontSize="small" /></IconButton></Tooltip>
    <Tooltip title={isFullscreen ? "Exit full screen" : "Full screen"}>
      <IconButton aria-label="Full screen" onClick={toggleFullscreen} sx={toolSx}>
        {isFullscreen ? <FullscreenExitIcon fontSize="small" /> : <FullscreenIcon fontSize="small" />}
      </IconButton>
    </Tooltip>
    {onInfo && (
      <Tooltip title="How to use">
        <IconButton aria-label="Info" onClick={onInfo} sx={{ width: 36, height: 36, borderRadius: "6px", bgcolor: THEME.info, color: "#fff", "&:hover": { bgcolor: "#1488c9" } }}>
          <InfoIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    )}
  </Stack>
);

export const InfoPopover = ({ anchorEl, onClose, editable }) => (
  <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={onClose} anchorOrigin={{ vertical: "bottom", horizontal: "right" }} transformOrigin={{ vertical: "top", horizontal: "right" }}>
    <Box sx={{ p: 2, width: 330, fontSize: 13, color: THEME.text }}>
      <Typography fontWeight={700} fontSize={14} mb={1}>How to read this chart</Typography>
      <Box component="ul" sx={{ m: 0, pl: 2.25, "& li": { mb: 0.5 } }}>
        <li>Each row is a machine / manual work centre; each bar is one operation of a production order.</li>
        <li>Hover a bar for part number, quantity, start, end and the PDC (planned date of completion).</li>
        <li>The red line is the current time. Shaded columns are Sundays / public holidays.</li>
        <li>Daily &amp; Weekly views show only the working hours of each shift; Monthly &amp; Yearly show full days.</li>
        <li>Use the &lt; &gt; arrows to move period, and the zoom buttons to stretch the timeline.</li>
        {editable && <li><b>Drag a bar</b> to a new time or machine row to re-schedule it, then press <b>Update</b> to save.</li>}
      </Box>
      <Typography fontWeight={700} fontSize={13} mt={1.5} mb={0.75}>Bar status</Typography>
      {Object.entries(STATUS_META).map(([k, v]) => (
        <Box key={k} sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
          <Box sx={{ width: 26, height: 12, borderRadius: "2px", bgcolor: THEME.primary, opacity: k === "COMPLETED" ? 0.55 : 1, boxShadow: k === "IN_PROGRESS" ? "inset 0 0 0 1.5px #fff, 0 0 0 1px " + THEME.primary : "none" }} />
          <span>{v.label} <Box component="span" sx={{ color: THEME.muted }}>({v.note})</Box></span>
        </Box>
      ))}
    </Box>
  </Popover>
);

/* ---------- buttons ---------- */
export const RefreshButton = ({ onClick, dark, loading }) => (
  <Button variant="contained" startIcon={<RefreshIcon />} onClick={onClick} disabled={loading}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: dark ? THEME.dark : THEME.primary, "&:hover": { bgcolor: dark ? "#4a5361" : "#1a5fc7", boxShadow: "none" } }}>
    Refresh
  </Button>
);

export const UpdateButton = ({ onClick, count, saving }) => (
  <Button variant="contained" startIcon={<UpdateIcon />} onClick={onClick} disabled={saving || !count}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.primary }}>
    Update{count ? ` (${count})` : ""}
  </Button>
);

export const ClearFiltersButton = ({ onClick }) => (
  <Button variant="contained" onClick={onClick}
    sx={{ height: 36, textTransform: "none", fontWeight: 600, fontSize: 13.5, boxShadow: "none", bgcolor: THEME.dark, "&:hover": { bgcolor: "#4a5361", boxShadow: "none" } }}>
    Clear Filters
  </Button>
);

/* ---------- legend ---------- */
export const ProductionOrdersLegend = ({ colorMap, title = "Production Orders" }) => (
  <Box sx={{ mt: 2.5, pt: 1.5, borderTop: `1px solid ${THEME.border}` }}>
    <Typography sx={{ fontSize: 13, fontWeight: 600, mb: 1, color: THEME.text }}>{title}</Typography>
    <Box sx={{ display: "flex", flexWrap: "wrap", gap: "6px 18px" }}>
      {Object.entries(colorMap).map(([po, color]) => (
        <Box key={po} sx={{ display: "flex", alignItems: "center", gap: 0.75, fontSize: 12, color: THEME.muted }}>
          <Box sx={{ width: 13, height: 13, borderRadius: "3px", bgcolor: color }} />{po}
        </Box>
      ))}
    </Box>
  </Box>
);
